
  # AuRA AI website

  This is a code bundle for AuRA AI website. The original project is available at https://www.figma.com/design/DORk3eFSRu20GF6MT5LgM6/AuRA-AI-website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  