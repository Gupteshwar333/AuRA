import { motion } from 'motion/react';
import { ReactNode } from 'react';

interface RoundButtonProps {
  onClick?: () => void;
  children: ReactNode;
  variant?: 'primary' | 'secondary' | 'outline';
  type?: 'button' | 'submit' | 'reset';
  className?: string;
  disabled?: boolean;
}

export function RoundButton({ 
  onClick, 
  children, 
  variant = 'primary',
  type = 'button',
  className = '',
  disabled = false 
}: RoundButtonProps) {
  const baseClasses = 'px-8 py-3 rounded-full transition-all duration-300 inline-flex items-center justify-center gap-2';
  
  const variantClasses = {
    primary: 'bg-white text-[#000080] border border-[#000080] hover:bg-[#000080] hover:text-white',
    secondary: 'bg-[#000080] text-white border border-[#000080] hover:bg-white hover:text-[#000080]',
    outline: 'bg-transparent text-[#000080] border border-[#000080] hover:bg-[#000080] hover:text-white'
  };

  return (
    <motion.button
      onClick={onClick}
      type={type}
      disabled={disabled}
      className={`${baseClasses} ${variantClasses[variant]} ${className} ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
      whileHover={!disabled ? { scale: 1.05 } : {}}
      whileTap={!disabled ? { scale: 0.95 } : {}}
    >
      {children}
    </motion.button>
  );
}