import { useState, useEffect, useRef } from 'react';
import { Menu, X, Bell, ChevronDown, Home, Cpu, Lightbulb, HelpCircle, LayoutGrid, MessageCircle, UserCircle, LogOut } from 'lucide-react';
import { RoundButton as Button } from './RoundButton';

interface NavItem {
  name: string;
  icon: React.FC<React.SVGProps<SVGSVGElement>>;
  page: string;
  hasSubmenu?: boolean;
  submenu?: { name: string; page: string }[];
}

export function Navbar({ onLogout, onNavigate, currentPage }: { onLogout: () => void; onNavigate: (page: string) => void; currentPage: string }) {
  const [isPlatformOpen, setIsPlatformOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isNotificationOpen, setIsNotificationOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const notificationRef = useRef<HTMLDivElement>(null);

  const navItems: NavItem[] = [
    { name: 'Home', icon: Home, page: 'Home' },
    { name: 'Platform', icon: Cpu, page: 'Platform', hasSubmenu: true, submenu: [
      { name: 'AI Agent', page: 'AI Agent' },
      { name: 'AI Analytics', page: 'AI Analytics' },
      { name: 'Conversation AI', page: 'Conversation AI' },
    ] },
    { name: 'Solutions', icon: Lightbulb, page: 'Solutions' },
    { name: 'Support', icon: HelpCircle, page: 'Support' },
    { name: 'Catalogue', icon: LayoutGrid, page: 'Catalogue' },
  ];

  const notifications = [
    {
      id: 1,
      title: 'New AI Agent Available',
      description: 'Check out our latest Workflow Builder agent',
      timestamp: '2 hours ago',
      unread: true,
    },
    {
      id: 2,
      title: 'System Update Complete',
      description: 'AuRA platform updated with new features',
      timestamp: '5 hours ago',
      unread: true,
    },
    {
      id: 3,
      title: 'Analytics Report Ready',
      description: 'Your monthly analytics report is ready to view',
      timestamp: '1 day ago',
      unread: false,
    },
    {
      id: 4,
      title: 'Welcome to AuRA AI',
      description: 'Get started with our quick tour',
      timestamp: '3 days ago',
      unread: false,
    },
  ];

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsPlatformOpen(false);
      }
      if (notificationRef.current && !notificationRef.current.contains(event.target as Node)) {
        setIsNotificationOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handlePlatformClick = () => {
    if (!isPlatformOpen) {
      setIsPlatformOpen(true);
    } else {
      onNavigate('Platform');
      setIsPlatformOpen(false);
    }
  };

  const handleSubmenuClick = (page: string) => {
    onNavigate(page);
    setIsPlatformOpen(false);
    setIsMobileMenuOpen(false);
  };

  const handleNavClick = (page: string) => {
    onNavigate(page);
    setIsMobileMenuOpen(false);
  };

  const handleNotificationClick = () => {
    setIsNotificationOpen(!isNotificationOpen);
  };

  return (
    <nav className="bg-[#000080] border-b border-white/10 shadow-lg sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-3 sm:px-5 lg:px-7">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center flex-shrink-0 gap-2">
            {/* AuRA Logo Icon */}
            <div className="relative w-9 h-9 flex items-center justify-center">
              <svg width="36" height="36" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
                {/* Outer Circle - Autonomous System */}
                <circle cx="18" cy="18" r="16" stroke="url(#gradient1)" strokeWidth="1.5" opacity="0.6"/>
                
                {/* Middle Hexagon - Intelligence Core */}
                <path d="M18 6 L27 11.5 L27 22.5 L18 28 L9 22.5 L9 11.5 Z" 
                      stroke="url(#gradient2)" 
                      strokeWidth="1.5" 
                      fill="none"
                      opacity="0.8"/>
                
                {/* Inner Neural Network Nodes */}
                <circle cx="18" cy="13" r="2" fill="#87CEEB"/>
                <circle cx="13" cy="18" r="2" fill="#87CEEB"/>
                <circle cx="23" cy="18" r="2" fill="#87CEEB"/>
                <circle cx="18" cy="23" r="2" fill="#87CEEB"/>
                
                {/* Connection Lines - Reasoning & Planning */}
                <line x1="18" y1="13" x2="13" y2="18" stroke="#87CEEB" strokeWidth="1" opacity="0.6"/>
                <line x1="18" y1="13" x2="23" y2="18" stroke="#87CEEB" strokeWidth="1" opacity="0.6"/>
                <line x1="13" y1="18" x2="18" y2="23" stroke="#87CEEB" strokeWidth="1" opacity="0.6"/>
                <line x1="23" y1="18" x2="18" y2="23" stroke="#87CEEB" strokeWidth="1" opacity="0.6"/>
                
                {/* Central Core - AI Brain */}
                <circle cx="18" cy="18" r="3.5" fill="url(#gradient3)" opacity="0.9"/>
                <circle cx="18" cy="18" r="2" fill="white" opacity="0.9"/>
                
                {/* Gradients */}
                <defs>
                  <linearGradient id="gradient1" x1="18" y1="2" x2="18" y2="34" gradientUnits="userSpaceOnUse">
                    <stop offset="0%" stopColor="#87CEEB"/>
                    <stop offset="100%" stopColor="#4A90E2"/>
                  </linearGradient>
                  <linearGradient id="gradient2" x1="18" y1="6" x2="18" y2="28" gradientUnits="userSpaceOnUse">
                    <stop offset="0%" stopColor="#87CEEB"/>
                    <stop offset="100%" stopColor="#ffffff"/>
                  </linearGradient>
                  <linearGradient id="gradient3" x1="18" y1="14.5" x2="18" y2="21.5" gradientUnits="userSpaceOnUse">
                    <stop offset="0%" stopColor="#87CEEB"/>
                    <stop offset="100%" stopColor="#4A90E2"/>
                  </linearGradient>
                </defs>
              </svg>
              
              {/* Pulse Animation for Autonomous Activity */}
              <div className="absolute inset-0 rounded-full bg-sky-400/20 animate-ping"></div>
            </div>
            
            <span className="text-white font-semibold text-lg">TCS AuRA</span>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-0">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentPage === item.page || 
                (item.name === 'Platform' && ['AI Agent', 'AI Analytics', 'Conversation AI'].includes(currentPage));
              
              if (item.hasSubmenu) {
                return (
                  <div key={item.name} className="relative" ref={dropdownRef}>
                    <Button
                      onClick={handlePlatformClick}
                      variant="ghost"
                      className={`text-white hover:bg-white/10 flex items-center gap-1.5 text-sm px-3 py-2 rounded-md transition-colors ${
                        isActive ? 'bg-white/10' : ''
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                      <span>{item.name}</span>
                      <ChevronDown className={`w-4 h-4 transition-transform ${isPlatformOpen ? 'rotate-180' : ''}`} />
                    </Button>
                    
                    {isPlatformOpen && (
                      <div className="absolute top-full left-0 mt-1 w-48 bg-white rounded-lg shadow-xl py-2 border border-gray-200">
                        {item.submenu?.map((subItem) => (
                          <button
                            key={subItem.page}
                            onClick={() => handleSubmenuClick(subItem.page)}
                            className={`w-full text-left px-4 py-2 text-gray-700 hover:bg-sky-50 hover:text-sky-500 transition-colors ${
                              currentPage === subItem.page ? 'bg-sky-50 text-sky-500' : ''
                            }`}
                          >
                            {subItem.name}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                );
              }
              
              return (
                <Button
                  key={item.name}
                  onClick={() => handleNavClick(item.name)}
                  variant="ghost"
                  className={`text-white hover:bg-white/10 flex items-center gap-1.5 text-sm px-3 py-2 rounded-md transition-colors ${
                    isActive ? 'bg-white/10' : ''
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.name}</span>
                </Button>
              );
            })}
          </div>

          {/* Right Icons */}
          <div className="hidden md:flex items-center gap-0 flex-shrink-0">
            <Button
              onClick={() => handleNavClick('Ella Bot')}
              variant="ghost"
              className={`text-white hover:bg-white/10 flex items-center gap-1.5 text-sm px-3 py-2 rounded-md transition-colors ${
                currentPage === 'Ella Bot' ? 'bg-white/10' : ''
              }`}
              title="Ella Bot - AI Assistant"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Ella Bot</span>
            </Button>
            <div className="relative" ref={notificationRef}>
              <Button
                onClick={handleNotificationClick}
                variant="ghost"
                className="text-white hover:bg-white/10 rounded-md transition-colors"
                title="Notifications"
              >
                <Bell className="w-5 h-5" />
              </Button>
              
              {/* Notification Dropdown */}
              {isNotificationOpen && (
                <div className="absolute right-0 top-full mt-1 bg-white rounded-xl shadow-xl border border-gray-200 w-80 max-h-96 overflow-y-auto z-50">
                  <div className="px-4 py-3 bg-gray-50 text-gray-700 font-semibold border-b border-gray-200 rounded-t-xl">
                    Notifications
                  </div>
                  <div className="divide-y divide-gray-100">
                    {notifications.map((notification) => (
                      <div 
                        key={notification.id} 
                        className="px-4 py-3 hover:bg-gray-50 cursor-pointer transition-colors"
                      >
                        <div className="flex items-start justify-between gap-2 mb-1">
                          <div className="text-sm font-semibold text-gray-800">
                            {notification.title}
                          </div>
                          {notification.unread && (
                            <div className="w-2 h-2 bg-sky-500 rounded-full flex-shrink-0 mt-1"></div>
                          )}
                        </div>
                        <div className="text-xs text-gray-600 mb-1">
                          {notification.description}
                        </div>
                        <div className="text-xs text-gray-400">
                          {notification.timestamp}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
            
            {/* User Profile & Logout */}
            <div className="flex items-center gap-2">
              <div className="relative">
                <div className="w-9 h-9 rounded-full bg-gradient-to-br from-sky-400 to-sky-600 flex items-center justify-center shadow-lg border-2 border-sky-300">
                  <UserCircle className="w-6 h-6 text-white" />
                </div>
                <div className="absolute -top-0.5 -right-0.5 w-3 h-3 bg-green-400 rounded-full border-2 border-[#000080]"></div>
              </div>
              <Button
                onClick={onLogout}
                variant="ghost"
                className="text-red-400 hover:bg-red-500/10"
                title="Logout"
              >
                <LogOut className="w-5 h-5" />
              </Button>
            </div>
          </div>

          {/* Mobile Hamburger Menu */}
          <div className="md:hidden flex items-center gap-2">
            <Button
              onClick={() => handleNavClick('Ella Bot')}
              variant="ghost"
              size="sm"
              className={`text-white hover:bg-white/10 ${
                currentPage === 'Ella Bot' ? 'bg-white/10' : ''
              }`}
            >
              <MessageCircle className="w-5 h-5" />
            </Button>
            <Button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              variant="ghost"
              size="sm"
              className="text-white hover:bg-white/10"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </Button>
          </div>
        </div>

        {/* Mobile Menu Dropdown */}
        {isMobileMenuOpen && (
          <div className="md:hidden pb-4 pt-2 border-t border-white/10">
            <div className="flex flex-col gap-1">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = currentPage === item.page || 
                  (item.name === 'Platform' && ['AI Agent', 'AI Analytics', 'Conversation AI'].includes(currentPage));
                
                if (item.hasSubmenu) {
                  return (
                    <div key={item.name} className="space-y-1">
                      <Button
                        onClick={() => setIsPlatformOpen(!isPlatformOpen)}
                        variant="ghost"
                        className={`w-full justify-start text-white hover:bg-white/10 ${isActive ? 'bg-white/10' : ''}`}
                      >
                        <Icon className="w-4 h-4 mr-2" />
                        {item.name}
                        <ChevronDown className={`w-4 h-4 ml-auto transition-transform ${isPlatformOpen ? 'rotate-180' : ''}`} />
                      </Button>
                      {isPlatformOpen && (
                        <div className="pl-4 space-y-1">
                          {item.submenu?.map((subItem) => (
                            <Button
                              key={subItem.page}
                              onClick={() => handleSubmenuClick(subItem.page)}
                              variant="ghost"
                              className={`w-full justify-start text-white/70 hover:bg-white/10 hover:text-white text-sm ${
                                currentPage === subItem.page ? 'bg-white/10 text-white' : ''
                              }`}
                            >
                              {subItem.name}
                            </Button>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                }
                
                return (
                  <Button
                    key={item.name}
                    onClick={() => handleNavClick(item.name)}
                    variant="ghost"
                    className={`w-full justify-start text-white hover:bg-white/10 ${isActive ? 'bg-white/10' : ''}`}
                  >
                    <Icon className="w-4 h-4 mr-2" />
                    {item.name}
                  </Button>
                );
              })}
              <div className="pt-2 border-t border-white/10 mt-2 space-y-1">
                <Button
                  variant="ghost"
                  className="w-full justify-start text-white hover:bg-white/10"
                >
                  <Bell className="w-4 h-4 mr-2" />
                  Notifications
                </Button>
                <Button
                  onClick={onLogout}
                  variant="ghost"
                  className="w-full justify-start text-red-400 hover:bg-red-500/10"
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Logout
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}