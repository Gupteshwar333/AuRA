import { Youtube, Instagram, Linkedin, Globe } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-[#000080] text-white border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Logo Section */}
        <div className="flex items-center gap-3 mb-4">
          <span className="text-white text-xl">TCS AuRA</span>
        </div>

        {/* Footer Bottom Section */}
        <div className="border-t border-white/10 pt-6">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
            {/* Copyright & Links */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 text-sm text-gray-400">
              <span>©2025 TATA Consultancy Services Limited</span>
              <div className="flex flex-wrap gap-4">
                <a href="#" className="hover:text-white transition-colors">Privacy Notice</a>
                <a href="#" className="hover:text-white transition-colors">Cookie Policy</a>
                <a href="#" className="hover:text-white transition-colors">Accessibility Declaration</a>
                <a href="#" className="hover:text-white transition-colors">Disclaimer</a>
                <a href="#" className="hover:text-white transition-colors">Security Policy</a>
                <a href="#" className="hover:text-white transition-colors">California Notice at Collection</a>
              </div>
            </div>

            {/* Social Media Icons */}
            <div className="flex items-center gap-4">
              <a 
                href="#" 
                className="text-white hover:text-sky-500 transition-colors"
                aria-label="Facebook"
              >
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                </svg>
              </a>
              <a 
                href="#" 
                className="text-white hover:text-sky-500 transition-colors"
                aria-label="YouTube"
              >
                <Youtube className="w-5 h-5" />
              </a>
              <a 
                href="#" 
                className="text-white hover:text-sky-500 transition-colors"
                aria-label="X (Twitter)"
              >
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                </svg>
              </a>
              <a 
                href="#" 
                className="text-white hover:text-sky-500 transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="w-5 h-5" />
              </a>
              <a 
                href="#" 
                className="text-white hover:text-sky-500 transition-colors"
                aria-label="LinkedIn"
              >
                <Linkedin className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Additional Links */}
          <div className="mt-4 pt-4 border-t border-white/10">
            <div className="flex items-center gap-2 text-sm text-gray-400">
              <Globe className="w-4 h-4" />
              <a href="#" className="hover:text-white transition-colors">Global (En)</a>
              <span className="mx-2">|</span>
              <a href="#" className="hover:text-white transition-colors">Customize cookies</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}