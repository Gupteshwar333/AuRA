import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Footer } from '../Footer';
import { motion } from 'motion/react';
import { 
  BookOpen, Video, FileText, Download, 
  GraduationCap, Lightbulb, MessageSquare, PlayCircle, Brain 
} from 'lucide-react';

interface LearnMorePageProps {
  onNavigate: (page: string) => void;
}

export function LearnMorePage({ onNavigate }: LearnMorePageProps) {
  const resources = [
    {
      icon: BookOpen,
      title: 'Documentation',
      description: 'Comprehensive guides on autonomous AI systems, agent deployment, and integration.',
      items: ['Quick Start Guide', 'Agent Configuration', 'Best Practices', 'API Reference'],
      gradient: 'from-blue-500 to-cyan-500',
      cta: 'View Docs'
    },
    {
      icon: Video,
      title: 'Video Tutorials',
      description: 'Learn how to deploy and manage autonomous AI agents through step-by-step videos.',
      items: ['Platform Overview', 'Agent Deployment', 'Workflow Automation', 'Use Cases'],
      gradient: 'from-purple-500 to-pink-500',
      cta: 'Watch Videos'
    },
    {
      icon: GraduationCap,
      title: 'Training Programs',
      description: 'Structured courses to master autonomous AI and agentic systems.',
      items: ['AI Fundamentals', 'Agent Architecture', 'Advanced Deployment', 'Certification'],
      gradient: 'from-green-500 to-emerald-500',
      cta: 'Enroll Now'
    },
    {
      icon: FileText,
      title: 'Case Studies',
      description: 'Real-world examples of organizations leveraging autonomous AI agents.',
      items: ['Enterprise Automation', 'Decision Enhancement', 'Efficiency Gains', 'ROI Analysis'],
      gradient: 'from-orange-500 to-red-500',
      cta: 'Read Stories'
    },
  ];

  const webinars = [
    {
      title: 'Understanding Autonomous AI Agents',
      date: 'Dec 15, 2024',
      duration: '45 min',
      speaker: 'Dr. Emily Watson',
      description: 'Deep dive into how autonomous agents understand, reason, plan, and execute tasks with minimal human intervention.'
    },
    {
      title: 'Building Goal-Oriented AI Systems',
      date: 'Dec 20, 2024',
      duration: '60 min',
      speaker: 'Michael Rodriguez',
      description: 'Learn how to design AI agents that break down objectives into sub-tasks and adapt to changing conditions.'
    },
    {
      title: 'Multi-Agent Collaboration Strategies',
      date: 'Jan 5, 2025',
      duration: '50 min',
      speaker: 'Sarah Chen',
      description: 'Discover how to orchestrate multiple AI agents working together to solve complex challenges.'
    },
  ];

  const faqs = [
    {
      question: 'What is AuRA AI Platform?',
      answer: 'AuRA AI Platform represents the next evolution in artificial intelligence - autonomous systems that understand, reason, plan, and execute complex tasks with minimal human intervention. Our agents are goal-oriented, adaptive, and capable of collaborating with other AI systems and humans.'
    },
    {
      question: 'How are autonomous agents different from traditional AI?',
      answer: 'Unlike reactive AI tools, autonomous agents proactively make independent decisions, adapt to changing conditions, learn from experiences, and execute multi-step tasks. They break down high-level objectives into actionable sub-tasks without constant human guidance.'
    },
    {
      question: 'What can I automate with AuRA AI?',
      answer: 'You can automate end-to-end workflows across various domains - from data processing and analysis to decision-making, customer service, and complex business processes. Our agents handle exceptions, adapt to changes, and continuously improve their performance.'
    },
    {
      question: 'How do AI agents collaborate?',
      answer: 'Our multi-agent system allows different AI agents to communicate, share knowledge, and coordinate actions. They can work together on complex tasks, distributing work based on their specializations while maintaining alignment toward common goals.'
    },
    {
      question: 'Is my data secure with autonomous agents?',
      answer: 'Absolutely. We use enterprise-grade encryption, comply with SOC 2 and GDPR standards, and maintain strict data governance. Agents operate within defined security boundaries and all actions are logged and auditable.'
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-indigo-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <motion.div
            className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-r from-indigo-600 to-purple-600 mb-6"
            animate={{
              rotate: [0, 360],
            }}
            transition={{
              duration: 20,
              repeat: Infinity,
              ease: "linear"
            }}
          >
            <Brain className="w-10 h-10 text-white" />
          </motion.div>
          <h1 className="text-4xl sm:text-5xl mb-4 text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600">
            Learn About Autonomous AI
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Master the fundamentals of autonomous AI agents and discover how they can transform your organization's 
            efficiency, decision-making, and innovation capabilities
          </p>
        </motion.div>

        {/* Tabs Section */}
        <Tabs defaultValue="resources" className="mb-16">
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="resources">Resources</TabsTrigger>
            <TabsTrigger value="webinars">Webinars</TabsTrigger>
            <TabsTrigger value="faq">FAQ</TabsTrigger>
          </TabsList>

          {/* Resources Tab */}
          <TabsContent value="resources">
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 gap-8"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5 }}
            >
              {resources.map((resource) => {
                const Icon = resource.icon;
                return (
                  <Card key={resource.title} className="hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
                    <CardHeader>
                      <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${resource.gradient} flex items-center justify-center mb-4`}>
                        <Icon className="w-7 h-7 text-white" />
                      </div>
                      <CardTitle className="text-xl">{resource.title}</CardTitle>
                      <CardDescription>{resource.description}</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <ul className="space-y-2">
                        {resource.items.map((item) => (
                          <li key={item} className="flex items-center gap-2 text-sm text-gray-700">
                            <div className={`w-1.5 h-1.5 rounded-full bg-gradient-to-r ${resource.gradient}`} />
                            {item}
                          </li>
                        ))}
                      </ul>
                      <Button className={`w-full bg-gradient-to-r ${resource.gradient} hover:opacity-90`}>
                        {resource.cta}
                      </Button>
                    </CardContent>
                  </Card>
                );
              })}
            </motion.div>
          </TabsContent>

          {/* Webinars Tab */}
          <TabsContent value="webinars">
            <motion.div 
              className="space-y-6"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5 }}
            >
              {webinars.map((webinar) => (
                <Card key={webinar.title} className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <PlayCircle className="w-6 h-6 text-indigo-600" />
                          <h3 className="text-xl">{webinar.title}</h3>
                        </div>
                        <p className="text-gray-600 mb-3">{webinar.description}</p>
                        <div className="flex flex-wrap gap-4 text-sm text-gray-500">
                          <span>📅 {webinar.date}</span>
                          <span>⏱️ {webinar.duration}</span>
                          <span>👤 {webinar.speaker}</span>
                        </div>
                      </div>
                      <Button className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 whitespace-nowrap">
                        Register Now
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}

              <Card className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white border-0">
                <CardContent className="p-8 text-center">
                  <Video className="w-12 h-12 mx-auto mb-4" />
                  <h3 className="text-2xl mb-2">Can't Attend Live?</h3>
                  <p className="text-indigo-100 mb-4">
                    All webinars are recorded and available on-demand for registered users
                  </p>
                  <Button className="bg-white text-indigo-600 hover:bg-indigo-50">
                    View Past Webinars
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>

          {/* FAQ Tab */}
          <TabsContent value="faq">
            <motion.div 
              className="space-y-4"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5 }}
            >
              {faqs.map((faq, index) => (
                <motion.div
                  key={faq.question}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <CardTitle className="text-lg flex items-start gap-3">
                        <MessageSquare className="w-5 h-5 text-indigo-600 mt-1 flex-shrink-0" />
                        {faq.question}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-600 pl-8">{faq.answer}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}

              <Card className="bg-gradient-to-r from-indigo-50 to-purple-50 border-indigo-200">
                <CardContent className="p-8 text-center">
                  <h3 className="text-2xl mb-2">Still Have Questions?</h3>
                  <p className="text-gray-600 mb-4">
                    Our team of AI experts is here to help you understand autonomous agents
                  </p>
                  <div className="flex flex-wrap justify-center gap-4">
                    <Button className="bg-gradient-to-r from-indigo-600 to-purple-600">
                      Contact Our Experts
                    </Button>
                    <Button variant="outline">
                      <Download className="w-4 h-4 mr-2" />
                      Download AI Guide
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>
        </Tabs>
      </div>
      
      <Footer />
    </div>
  );
}
