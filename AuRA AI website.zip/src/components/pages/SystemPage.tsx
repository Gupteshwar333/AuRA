import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { Activity, Cpu, HardDrive, MemoryStick, Network, Server, AlertCircle, CheckCircle } from 'lucide-react';

export function SystemPage() {
  const systemStats = [
    { label: 'CPU Usage', value: 45, icon: Cpu, color: 'text-blue-600' },
    { label: 'Memory Usage', value: 62, icon: MemoryStick, color: 'text-purple-600' },
    { label: 'Storage', value: 38, icon: HardDrive, color: 'text-green-600' },
    { label: 'Network', value: 73, icon: Network, color: 'text-orange-600' },
  ];

  const services = [
    { name: 'API Gateway', status: 'running', uptime: '99.9%', requests: '2.5M/day' },
    { name: 'Database Cluster', status: 'running', uptime: '99.8%', requests: '1.2M/day' },
    { name: 'Cache Server', status: 'running', uptime: '99.9%', requests: '8.3M/day' },
    { name: 'Load Balancer', status: 'running', uptime: '100%', requests: '5.1M/day' },
    { name: 'Message Queue', status: 'warning', uptime: '98.5%', requests: '3.4M/day' },
    { name: 'Storage Service', status: 'running', uptime: '99.7%', requests: '1.8M/day' },
  ];

  const recentActivity = [
    { action: 'System backup completed', time: '2 minutes ago', type: 'success' },
    { action: 'Security patch deployed', time: '1 hour ago', type: 'success' },
    { action: 'High memory usage detected', time: '3 hours ago', type: 'warning' },
    { action: 'Database optimization completed', time: '5 hours ago', type: 'success' },
    { action: 'New server added to cluster', time: '1 day ago', type: 'success' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl sm:text-5xl mb-4 text-transparent bg-clip-text bg-gradient-to-r from-slate-700 to-slate-900">
            System Dashboard
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Monitor and manage your infrastructure in real-time
          </p>
        </div>

        {/* System Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {systemStats.map((stat) => {
            const Icon = stat.icon;
            return (
              <Card key={stat.label} className="hover:shadow-lg transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardDescription>{stat.label}</CardDescription>
                    <Icon className={`w-5 h-5 ${stat.color}`} />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl mb-2">{stat.value}%</div>
                  <Progress value={stat.value} className="h-2" />
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Services Status */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Server className="w-5 h-5 text-slate-700" />
                <CardTitle>Services Status</CardTitle>
              </div>
              <CardDescription>All running services and their health status</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {services.map((service) => (
                <div key={service.name} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    {service.status === 'running' ? (
                      <CheckCircle className="w-5 h-5 text-green-600" />
                    ) : (
                      <AlertCircle className="w-5 h-5 text-yellow-600" />
                    )}
                    <div>
                      <div>{service.name}</div>
                      <div className="text-sm text-gray-500">Uptime: {service.uptime}</div>
                    </div>
                  </div>
                  <Badge variant={service.status === 'running' ? 'default' : 'secondary'}>
                    {service.status}
                  </Badge>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-slate-700" />
                <CardTitle>Recent Activity</CardTitle>
              </div>
              <CardDescription>Latest system events and notifications</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {recentActivity.map((activity, index) => (
                <div key={index} className="flex items-start gap-3 p-3 bg-slate-50 rounded-lg">
                  <div className={`w-2 h-2 rounded-full mt-2 ${
                    activity.type === 'success' ? 'bg-green-500' : 'bg-yellow-500'
                  }`} />
                  <div className="flex-1">
                    <div className="text-sm">{activity.action}</div>
                    <div className="text-xs text-gray-500">{activity.time}</div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>Common system management tasks</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Button variant="outline" className="h-auto py-4 flex-col gap-2">
                <Server className="w-6 h-6" />
                <span>Restart Services</span>
              </Button>
              <Button variant="outline" className="h-auto py-4 flex-col gap-2">
                <HardDrive className="w-6 h-6" />
                <span>Backup Now</span>
              </Button>
              <Button variant="outline" className="h-auto py-4 flex-col gap-2">
                <Activity className="w-6 h-6" />
                <span>View Logs</span>
              </Button>
              <Button variant="outline" className="h-auto py-4 flex-col gap-2">
                <Network className="w-6 h-6" />
                <span>Network Config</span>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
