import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Footer } from '../Footer';
import { motion } from 'motion/react';
import { Bot, GitBranch, MessageSquare, Database, Workflow, Server, BarChart3, Sparkles } from 'lucide-react';

interface PlatformPageProps {
  onNavigate: (page: string) => void;
}

export function PlatformPage({ onNavigate }: PlatformPageProps) {
  const agents = [
    {
      icon: GitBranch,
      name: 'Transition Agent',
      description: 'Intelligently manages complex state transitions and orchestrates multi-step processes. Adapts to changing conditions and ensures smooth workflow progression across systems.',
      gradient: 'from-[#0066CC] to-[#0091D5]',
      badge: 'Popular',
      badgeColor: 'bg-[#00A651]'
    },
    {
      icon: FileDocument,
      name: 'SOP Agent',
      description: 'Automates standard operating procedures with context-aware execution. Learns from variations and exceptions to continuously improve process adherence and efficiency.',
      gradient: 'from-[#0066CC] to-[#003D79]',
      badge: 'New',
      badgeColor: 'bg-[#FFC72C]'
    },
    {
      icon: MessageSquare,
      name: 'Conversational Agent',
      description: 'Engages in natural, context-rich dialogues with users. Understands intent, maintains conversation history, and provides intelligent, goal-oriented responses.',
      gradient: 'from-[#00A651] to-[#0066CC]',
      badge: null,
      badgeColor: ''
    },
    {
      icon: Database,
      name: 'RAG Agent',
      description: 'Retrieval-Augmented Generation agent that combines your knowledge base with generative AI. Delivers accurate, contextual answers grounded in your organization\'s data.',
      gradient: 'from-[#FF6B35] to-[#E31E24]',
      badge: 'Hot',
      badgeColor: 'bg-[#E31E24]'
    },
    {
      icon: Workflow,
      name: 'Workflow Builder',
      description: 'Autonomously designs and optimizes workflows based on objectives. Breaks down complex goals into executable tasks and adapts workflows based on real-time feedback.',
      gradient: 'from-[#FFC72C] to-[#FF6B35]',
      badge: null,
      badgeColor: ''
    },
    {
      icon: Server,
      name: 'DevOps Agent',
      description: 'Manages deployment pipelines, infrastructure provisioning, and system monitoring. Makes intelligent decisions about scaling, optimization, and incident response.',
      gradient: 'from-[#0066CC] to-[#003D79]',
      badge: null,
      badgeColor: ''
    },
    {
      icon: BarChart3,
      name: 'Analytics Agent',
      description: 'Autonomously analyzes data patterns, generates insights, and recommends actions. Continuously learns which metrics matter most and adapts reporting accordingly.',
      gradient: 'from-[#0091D5] to-[#0066CC]',
      badge: 'New',
      badgeColor: 'bg-[#FFC72C]'
    },
  ];

  const businessBenefits = [
    {
      icon: '⚡',
      title: 'Efficiency',
      description: 'Automate end-to-end workflows and eliminate manual intervention',
    },
    {
      icon: '🎯',
      title: 'Decision-Making',
      description: 'Enhanced decision quality through data-driven, autonomous analysis',
    },
    {
      icon: '📈',
      title: 'Scalability',
      description: 'Scale operations without proportional increase in resources',
    },
    {
      icon: '💡',
      title: 'Innovation',
      description: 'Unlock new possibilities with AI-driven insights and automation',
    },
    {
      icon: '💰',
      title: 'Cost Reduction',
      description: 'Reduce operational costs through intelligent automation',
    },
    {
      icon: '🚀',
      title: 'Speed',
      description: 'Accelerate processes with 24/7 autonomous operations',
    },
    {
      icon: '🎨',
      title: 'Flexibility',
      description: 'Adapt quickly to market changes and new opportunities',
    },
    {
      icon: '🛡️',
      title: 'Reliability',
      description: 'Consistent performance with continuous learning and improvement',
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.12,
        delayChildren: 0.3
      }
    }
  };

  const cardVariants = {
    hidden: { 
      opacity: 0, 
      scale: 0.8,
      y: 50 
    },
    visible: {
      opacity: 1,
      scale: 1,
      y: 0,
      transition: {
        type: "spring",
        damping: 15,
        stiffness: 100
      }
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header with Animation */}
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        >
          <motion.div
            className="inline-flex items-center justify-center mb-6"
            animate={{
              scale: [1, 1.05, 1],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            <div className="w-20 h-20 rounded-full bg-sky-500 flex items-center justify-center shadow-2xl shadow-sky-500/30">
              <Bot className="w-10 h-10 text-white" />
            </div>
          </motion.div>

          <h1 className="text-4xl sm:text-5xl md:text-6xl mb-4 text-[#000080]">
            AuRA AI <span className="text-sky-500">Agent Hub</span>
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Autonomous agents that understand context, reason through problems, and execute complex tasks. 
            Each agent is goal-oriented, adaptive, and capable of collaborating with humans and other AI systems.
          </p>
        </motion.div>

        {/* Agents Grid */}
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {agents.map((agent, index) => {
            const Icon = agent.icon;
            return (
              <motion.div 
                key={agent.name} 
                variants={cardVariants}
                whileHover={{ y: -10 }}
                transition={{ duration: 0.3 }}
              >
                <Card className="h-full hover:shadow-2xl transition-all duration-300 border border-gray-200 hover:border-sky-500 group relative overflow-hidden bg-white">
                  <CardHeader className="relative">
                    <div className="flex items-start justify-between mb-4">
                      <motion.div
                        className="w-14 h-14 rounded-xl bg-sky-500 flex items-center justify-center shadow-lg"
                        whileHover={{ rotate: 360 }}
                        transition={{ duration: 0.6, ease: "easeInOut" }}
                      >
                        <Icon className="w-7 h-7 text-white" />
                      </motion.div>
                      {agent.badge && (
                        <motion.div
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          transition={{ delay: 0.3 + index * 0.1, type: "spring" }}
                        >
                          <Badge className="bg-sky-500 text-white border-0">
                            {agent.badge}
                          </Badge>
                        </motion.div>
                      )}
                    </div>
                    <CardTitle className="text-xl mb-2 text-[#000080] group-hover:text-sky-500 transition-all duration-300">
                      {agent.name}
                    </CardTitle>
                  </CardHeader>
                  
                  <CardContent className="relative">
                    <CardDescription className="text-gray-600 leading-relaxed">
                      {agent.description}
                    </CardDescription>
                    
                    {/* Animated Bottom Border */}
                    <motion.div 
                      className="h-1 bg-sky-500 mt-6 rounded-full"
                      initial={{ scaleX: 0 }}
                      whileInView={{ scaleX: 1 }}
                      viewport={{ once: true }}
                      transition={{ delay: index * 0.1, duration: 0.6 }}
                    />
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Business Benefits */}
        <motion.div 
          className="mb-20"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl text-center mb-12 text-[#000080]">Business Benefits</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {businessBenefits.map((benefit, index) => (
              <motion.div
                key={benefit.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.5 }}
              >
                <Card className="h-full hover:shadow-xl transition-all duration-300 hover:-translate-y-2 border-gray-200">
                  <CardHeader>
                    <div className="text-center mb-3">
                      <motion.span 
                        className="text-5xl inline-block"
                        whileHover={{ 
                          scale: 1.2,
                          rotate: 360,
                          transition: { duration: 0.5 }
                        }}
                      >
                        {benefit.icon}
                      </motion.span>
                    </div>
                    <CardTitle className="text-center text-lg text-[#000080]">{benefit.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 text-center">{benefit.description}</p>
                    <motion.div 
                      className="h-1 bg-sky-500 mt-4 rounded-full"
                      initial={{ scaleX: 0 }}
                      whileInView={{ scaleX: 1 }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.6, delay: index * 0.05 }}
                    />
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
      
      <Footer />
    </div>
  );
}

// FileDocument icon component (since it's not in lucide-react)
function FileDocument({ className }: { className?: string }) {
  return (
    <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
    </svg>
  );
}