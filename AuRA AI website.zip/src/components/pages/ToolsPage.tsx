import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Footer } from '../Footer';
import { motion } from 'motion/react';
import { 
  Wrench, Brain, Workflow, Database, LineChart, 
  FileText, MessageSquare, Shield, Zap, Target,
  Network, Code, Cpu, Cloud, GitBranch
} from 'lucide-react';

export function ToolsPage() {
  const tools = [
    {
      icon: Brain,
      name: 'AI Decision Engine',
      description: 'Autonomous decision-making tool that analyzes complex scenarios and recommends optimal actions.',
      category: 'Intelligence',
      gradient: 'from-blue-500 to-cyan-500'
    },
    {
      icon: Workflow,
      name: 'Workflow Optimizer',
      description: 'Automatically analyzes and optimizes your business workflows for maximum efficiency.',
      category: 'Automation',
      gradient: 'from-purple-500 to-pink-500'
    },
    {
      icon: Database,
      name: 'Data Processor',
      description: 'Intelligent data processing that understands context and extracts meaningful insights.',
      category: 'Analytics',
      gradient: 'from-green-500 to-emerald-500'
    },
    {
      icon: LineChart,
      name: 'Predictive Analytics',
      description: 'AI-powered forecasting and trend analysis for informed business decisions.',
      category: 'Analytics',
      gradient: 'from-orange-500 to-red-500'
    },
    {
      icon: FileText,
      name: 'Document Intelligence',
      description: 'Automatically process, analyze, and extract information from documents.',
      category: 'Processing',
      gradient: 'from-indigo-500 to-purple-500'
    },
    {
      icon: MessageSquare,
      name: 'Conversational Interface',
      description: 'Natural language interface for interacting with your AI agents and systems.',
      category: 'Communication',
      gradient: 'from-pink-500 to-rose-500'
    },
    {
      icon: Shield,
      name: 'Security Monitor',
      description: 'Autonomous security monitoring with threat detection and incident response.',
      category: 'Security',
      gradient: 'from-red-500 to-rose-500'
    },
    {
      icon: Zap,
      name: 'Task Automator',
      description: 'Automate repetitive tasks with AI that learns and improves over time.',
      category: 'Automation',
      gradient: 'from-yellow-500 to-amber-500'
    },
    {
      icon: Target,
      name: 'Goal Planner',
      description: 'Break down high-level objectives into actionable tasks and track progress.',
      category: 'Planning',
      gradient: 'from-teal-500 to-cyan-500'
    },
    {
      icon: Network,
      name: 'Multi-Agent Coordinator',
      description: 'Coordinate multiple AI agents to work together on complex projects.',
      category: 'Coordination',
      gradient: 'from-blue-500 to-indigo-500'
    },
    {
      icon: Code,
      name: 'Code Assistant',
      description: 'AI-powered coding assistance with intelligent suggestions and debugging.',
      category: 'Development',
      gradient: 'from-green-500 to-teal-500'
    },
    {
      icon: Cpu,
      name: 'Model Trainer',
      description: 'Train and fine-tune AI models for your specific use cases.',
      category: 'Development',
      gradient: 'from-purple-500 to-indigo-500'
    },
    {
      icon: Cloud,
      name: 'Cloud Orchestrator',
      description: 'Manage cloud resources and deployments with intelligent automation.',
      category: 'Infrastructure',
      gradient: 'from-cyan-500 to-blue-500'
    },
    {
      icon: GitBranch,
      name: 'Version Controller',
      description: 'Intelligent version control and code management for AI projects.',
      category: 'Development',
      gradient: 'from-orange-500 to-yellow-500'
    },
    {
      icon: Wrench,
      name: 'System Optimizer',
      description: 'Continuously monitor and optimize system performance autonomously.',
      category: 'Operations',
      gradient: 'from-slate-500 to-gray-500'
    },
  ];

  const categories = ['All', 'Intelligence', 'Automation', 'Analytics', 'Processing', 'Communication', 'Security', 'Planning', 'Coordination', 'Development', 'Infrastructure', 'Operations'];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.08
      }
    }
  };

  const cardVariants = {
    hidden: { opacity: 0, scale: 0.9, y: 20 },
    visible: {
      opacity: 1,
      scale: 1,
      y: 0,
      transition: {
        duration: 0.4
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <motion.div 
          className="text-center mb-12"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="flex justify-center mb-4">
            <motion.div 
              className="w-20 h-20 rounded-2xl bg-gradient-to-r from-slate-700 to-slate-900 flex items-center justify-center"
              animate={{
                rotate: [0, 10, -10, 10, 0],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            >
              <Wrench className="w-10 h-10 text-white" />
            </motion.div>
          </div>
          <h1 className="text-4xl sm:text-5xl mb-4 text-transparent bg-clip-text bg-gradient-to-r from-slate-700 to-slate-900">
            AuRA AI Tools
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Comprehensive suite of autonomous AI-powered tools that work independently and collaboratively 
            to enhance your productivity and innovation
          </p>
        </motion.div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-2 mb-12">
          {categories.map((category) => (
            <Button
              key={category}
              variant="outline"
              className="hover:bg-slate-100"
            >
              {category}
            </Button>
          ))}
        </div>

        {/* Tools Grid */}
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {tools.map((tool) => {
            const Icon = tool.icon;
            return (
              <motion.div key={tool.name} variants={cardVariants}>
                <Card className="h-full hover:shadow-xl transition-all duration-300 hover:-translate-y-2 border-2 border-transparent hover:border-slate-200 group">
                  <CardHeader>
                    <motion.div 
                      className={`w-14 h-14 rounded-xl bg-gradient-to-br ${tool.gradient} flex items-center justify-center mb-3`}
                      whileHover={{ scale: 1.1, rotate: 5 }}
                      transition={{ duration: 0.3 }}
                    >
                      <Icon className="w-7 h-7 text-white" />
                    </motion.div>
                    <CardTitle className="text-lg">{tool.name}</CardTitle>
                    <CardDescription className="text-xs uppercase tracking-wide text-slate-500">
                      {tool.category}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-4">{tool.description}</p>
                    <Button className={`w-full bg-gradient-to-r ${tool.gradient} hover:opacity-90`}>
                      Launch Tool
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </motion.div>

        {/* CTA Section */}
        <motion.div 
          className="mt-16 bg-gradient-to-r from-slate-700 to-slate-900 rounded-2xl p-8 sm:p-12 text-white text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl mb-4">Need a Custom AI Tool?</h2>
          <p className="text-slate-300 max-w-2xl mx-auto mb-6">
            We can develop custom autonomous AI tools tailored to your specific business workflows and requirements
          </p>
          <Button className="bg-white text-slate-900 hover:bg-slate-100">
            Request Custom Tool
          </Button>
        </motion.div>
      </div>
      
      <Footer />
    </div>
  );
}
