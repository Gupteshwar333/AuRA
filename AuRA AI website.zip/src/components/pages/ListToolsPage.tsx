import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Input } from '../ui/input';
import { Footer } from '../Footer';
import { motion } from 'motion/react';
import { 
  List, Plus, Search, Filter, Wrench, 
  ExternalLink, Edit, Trash2, Lock, CheckCircle2,
  Cloud, FileText, AlertCircle, RefreshCw, Clock, FileSearch,
  Server, Activity, Layers
} from 'lucide-react';
import { useState } from 'react';

interface ListToolsPageProps {
  onNavigate: (page: string) => void;
}

export function ListToolsPage({ onNavigate }: ListToolsPageProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  // Configuration Tools - Auto-stored Available Tools
  const tools = [
    {
      id: 1,
      name: 'upload_to_blob',
      description: 'Uploads a file to Azure Blob Storage.',
      category: 'Azure Storage',
      version: '1.0.0',
      author: 'AuRA Platform',
      status: 'Active',
      url: 'https://azure.microsoft.com/blob-storage',
      hasCredentials: true,
      tags: ['azure', 'storage', 'blob', 'upload'],
      gradient: 'from-blue-500 to-cyan-500',
      icon: Cloud,
      toolType: 'Configuration'
    },
    {
      id: 2,
      name: 'search_kb',
      description: 'Fetches knowledge base articles from AI search for user queries.',
      category: 'Knowledge Base',
      version: '1.0.0',
      author: 'AuRA Platform',
      status: 'Active',
      url: 'https://azure.microsoft.com/cognitive-search',
      hasCredentials: true,
      tags: ['search', 'knowledge-base', 'ai', 'query'],
      gradient: 'from-purple-500 to-pink-500',
      icon: FileSearch,
      toolType: 'Configuration'
    },
    {
      id: 3,
      name: 'create_servicenow_incident',
      description: 'Creates a new ServiceNow incident.',
      category: 'ServiceNow',
      version: '1.0.0',
      author: 'AuRA Platform',
      status: 'Active',
      url: 'https://servicenow.com',
      hasCredentials: true,
      tags: ['servicenow', 'incident', 'create', 'ticketing'],
      gradient: 'from-red-500 to-rose-500',
      icon: AlertCircle,
      toolType: 'Configuration'
    },
    {
      id: 4,
      name: 'update_servicenow_incident',
      description: 'Updates an existing incident in ServiceNow.',
      category: 'ServiceNow',
      version: '1.0.0',
      author: 'AuRA Platform',
      status: 'Active',
      url: 'https://servicenow.com',
      hasCredentials: true,
      tags: ['servicenow', 'incident', 'update', 'ticketing'],
      gradient: 'from-orange-500 to-red-500',
      icon: RefreshCw,
      toolType: 'Configuration'
    },
    {
      id: 5,
      name: 'fetch_recent_tickets',
      description: 'Fetches the latest incidents from a ServiceNow-like API.',
      category: 'ServiceNow',
      version: '1.0.0',
      author: 'AuRA Platform',
      status: 'Active',
      url: 'https://servicenow.com',
      hasCredentials: true,
      tags: ['servicenow', 'fetch', 'tickets', 'recent'],
      gradient: 'from-green-500 to-emerald-500',
      icon: FileText,
      toolType: 'Configuration'
    },
    {
      id: 6,
      name: 'fetch_ticket_status',
      description: 'Fetches the status of a specific incident ticket from a ServiceNow-like API.',
      category: 'ServiceNow',
      version: '1.0.0',
      author: 'AuRA Platform',
      status: 'Active',
      url: 'https://servicenow.com',
      hasCredentials: true,
      tags: ['servicenow', 'status', 'ticket', 'query'],
      gradient: 'from-teal-500 to-cyan-500',
      icon: Clock,
      toolType: 'Configuration'
    },
    {
      id: 7,
      name: 'fetch_recent_service_requests',
      description: 'Fetches the latest service requests from a ServiceNow instance.',
      category: 'ServiceNow',
      version: '1.0.0',
      author: 'AuRA Platform',
      status: 'Active',
      url: 'https://servicenow.com',
      hasCredentials: true,
      tags: ['servicenow', 'service-request', 'fetch', 'recent'],
      gradient: 'from-indigo-500 to-blue-500',
      icon: Layers,
      toolType: 'Configuration'
    },
    {
      id: 8,
      name: 'fetch_service_requests_status',
      description: 'Fetches the status details for a specific Service Request from a ServiceNow API.',
      category: 'ServiceNow',
      version: '1.0.0',
      author: 'AuRA Platform',
      status: 'Active',
      url: 'https://servicenow.com',
      hasCredentials: true,
      tags: ['servicenow', 'service-request', 'status', 'query'],
      gradient: 'from-violet-500 to-purple-500',
      icon: Activity,
      toolType: 'Configuration'
    },
    {
      id: 9,
      name: 'get_dynatrace_pending_incidents',
      description: 'Fetches incidents from ServiceNow that are related to Dynatrace.',
      category: 'ServiceNow',
      version: '1.0.0',
      author: 'AuRA Platform',
      status: 'Active',
      url: 'https://servicenow.com',
      hasCredentials: true,
      tags: ['servicenow', 'dynatrace', 'incidents', 'monitoring'],
      gradient: 'from-pink-500 to-rose-500',
      icon: Server,
      toolType: 'Configuration'
    },
    {
      id: 10,
      name: 'fetch_p1p2_outage_incidents',
      description: 'Fetches P1/P2 incidents or outage incidents from a ServiceNow instance.',
      category: 'ServiceNow',
      version: '1.0.0',
      author: 'AuRA Platform',
      status: 'Active',
      url: 'https://servicenow.com',
      hasCredentials: true,
      tags: ['servicenow', 'p1', 'p2', 'outage', 'critical'],
      gradient: 'from-red-600 to-orange-600',
      icon: AlertCircle,
      toolType: 'Configuration'
    },
    {
      id: 11,
      name: 'create_child_incident',
      description: 'Creates a new child incident in ServiceNow linked to a specified parent incident.',
      category: 'ServiceNow',
      version: '1.0.0',
      author: 'AuRA Platform',
      status: 'Active',
      url: 'https://servicenow.com',
      hasCredentials: true,
      tags: ['servicenow', 'child-incident', 'create', 'linked'],
      gradient: 'from-yellow-500 to-orange-500',
      icon: Layers,
      toolType: 'Configuration'
    },
  ];

  const categories = ['All', ...Array.from(new Set(tools.map(t => t.category)))];

  const filteredTools = tools.filter(tool => {
    const matchesSearch = 
      tool.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tool.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tool.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tool.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesCategory = selectedCategory === 'All' || tool.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 via-pink-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <motion.div 
          className="text-center mb-12"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <motion.div
            className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-r from-purple-600 to-pink-600 mb-6"
            animate={{
              scale: [1, 1.05, 1],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            <List className="w-10 h-10 text-white" />
          </motion.div>
          <h1 className="text-4xl sm:text-5xl mb-4 text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-pink-600">
            Configuration Tools
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            All available tools auto-stored and ready for integration with AuRA AI Platform
          </p>
          <Badge className="mt-4 bg-gradient-to-r from-green-500 to-emerald-500 text-white border-0 px-4 py-1">
            <CheckCircle2 className="w-4 h-4 mr-2" />
            {tools.length} Tools Available
          </Badge>
        </motion.div>

        {/* Auto-Store Info Banner */}
        <motion.div
          className="bg-gradient-to-r from-blue-50 to-purple-50 border-2 border-blue-200 rounded-xl p-6 mb-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center flex-shrink-0">
              <Server className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="text-xl mb-2">Auto-Stored Tools Repository</h3>
              <p className="text-gray-700 mb-3">
                All configuration tools are automatically stored and synchronized with the AuRA AI Platform. 
                This repository includes current tools and reserves space for upcoming integrations.
              </p>
              <div className="flex flex-wrap gap-2">
                <Badge className="bg-blue-600 text-white border-0">
                  <CheckCircle2 className="w-3 h-3 mr-1" />
                  Auto-Synced
                </Badge>
                <Badge className="bg-purple-600 text-white border-0">
                  <Clock className="w-3 h-3 mr-1" />
                  Future-Ready
                </Badge>
                <Badge className="bg-green-600 text-white border-0">
                  <Lock className="w-3 h-3 mr-1" />
                  Secure
                </Badge>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Search and Actions Bar */}
        <motion.div 
          className="flex flex-col sm:flex-row gap-4 mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
        >
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search tools by name, category, or tags..."
              className="pl-10 h-12"
            />
          </div>
          <div className="flex gap-2">
            <Button 
              onClick={() => onNavigate('Add Tools')}
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 h-12"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Custom Tool
            </Button>
          </div>
        </motion.div>

        {/* Category Filter Tabs */}
        <motion.div
          className="flex flex-wrap gap-2 mb-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          {categories.map((category) => (
            <Button
              key={category}
              variant={selectedCategory === category ? "default" : "outline"}
              onClick={() => setSelectedCategory(category)}
              className={selectedCategory === category ? "bg-gradient-to-r from-purple-600 to-pink-600" : ""}
            >
              {category}
            </Button>
          ))}
        </motion.div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
          >
            <Card className="border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-white hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="text-center">
                  <div className="w-12 h-12 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Wrench className="w-6 h-6 text-white" />
                  </div>
                  <p className="text-3xl mb-1">{tools.length}</p>
                  <p className="text-sm text-gray-600">Configuration Tools</p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
          >
            <Card className="border-2 border-green-200 bg-gradient-to-br from-green-50 to-white hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="text-center">
                  <div className="w-12 h-12 bg-gradient-to-r from-green-600 to-emerald-600 rounded-full flex items-center justify-center mx-auto mb-3">
                    <CheckCircle2 className="w-6 h-6 text-white" />
                  </div>
                  <p className="text-3xl mb-1">{tools.filter(t => t.status === 'Active').length}</p>
                  <p className="text-sm text-gray-600">Active & Ready</p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
          >
            <Card className="border-2 border-blue-200 bg-gradient-to-br from-blue-50 to-white hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="text-center">
                  <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-cyan-600 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Lock className="w-6 h-6 text-white" />
                  </div>
                  <p className="text-3xl mb-1">{tools.filter(t => t.hasCredentials).length}</p>
                  <p className="text-sm text-gray-600">Secured Tools</p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8 }}
          >
            <Card className="border-2 border-orange-200 bg-gradient-to-br from-orange-50 to-white hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="text-center">
                  <div className="w-12 h-12 bg-gradient-to-r from-orange-600 to-red-600 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Layers className="w-6 h-6 text-white" />
                  </div>
                  <p className="text-3xl mb-1">{new Set(tools.map(t => t.category)).size}</p>
                  <p className="text-sm text-gray-600">Categories</p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Tools Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {filteredTools.map((tool, index) => {
            const ToolIcon = tool.icon || Wrench;
            return (
              <motion.div
                key={tool.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.05 * index }}
              >
                <Card className="h-full hover:shadow-2xl transition-all duration-300 hover:-translate-y-1 group border-2 hover:border-purple-200">
                  <CardHeader>
                    <div className="flex items-start justify-between mb-3">
                      <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${tool.gradient} flex items-center justify-center shadow-lg`}>
                        <ToolIcon className="w-7 h-7 text-white" />
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="default" className="bg-green-100 text-green-700 border-0">
                          <CheckCircle2 className="w-3 h-3 mr-1" />
                          {tool.status}
                        </Badge>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <CardTitle className="text-lg font-mono">{tool.name}</CardTitle>
                      <Badge variant="outline" className="text-xs">
                        {tool.toolType}
                      </Badge>
                    </div>
                    <CardDescription className="text-sm mt-3 leading-relaxed">
                      {tool.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg p-3 space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">Category:</span>
                        <Badge className="bg-purple-600 text-white border-0">{tool.category}</Badge>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">Version:</span>
                        <span className="text-gray-800">{tool.version}</span>
                      </div>
                      {tool.hasCredentials && (
                        <div className="flex items-center gap-2 text-xs text-green-700 mt-2">
                          <Lock className="w-3 h-3" />
                          <span>Credentials configured</span>
                        </div>
                      )}
                    </div>
                    
                    <div className="flex flex-wrap gap-1">
                      {tool.tags.map((tag) => (
                        <Badge key={tag} variant="secondary" className="text-xs">
                          #{tag}
                        </Badge>
                      ))}
                    </div>

                    <div className="flex gap-2 pt-2">
                      <Button variant="outline" size="sm" className="flex-1 hover:bg-purple-50">
                        <Edit className="w-3 h-3 mr-1" />
                        Configure
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="flex-1 hover:bg-blue-50"
                        onClick={() => window.open(tool.url, '_blank')}
                      >
                        <ExternalLink className="w-3 h-3 mr-1" />
                        Docs
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {filteredTools.length === 0 && (
          <motion.div 
            className="text-center py-12"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            <p className="text-xl text-gray-600 mb-4">No tools found matching your search</p>
            <Button onClick={() => setSearchQuery('')} variant="outline">
              Clear Search
            </Button>
          </motion.div>
        )}

        {/* Info Banner */}
        <motion.div 
          className="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 rounded-2xl p-8 sm:p-12 text-white text-center shadow-2xl mb-8"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <div className="flex items-center justify-center gap-3 mb-4">
            <CheckCircle2 className="w-12 h-12" />
            <h2 className="text-3xl sm:text-4xl">Auto-Stored Configuration Tools</h2>
          </div>
          <p className="text-lg text-purple-100 max-w-3xl mx-auto mb-6">
            All ServiceNow and Azure integration tools are automatically available and ready to use. 
            These tools are pre-configured for seamless integration with AuRA AI Platform.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <div className="bg-white/20 backdrop-blur-sm rounded-lg px-6 py-3">
              <p className="text-2xl">{tools.filter(t => t.category === 'ServiceNow').length}</p>
              <p className="text-sm text-purple-100">ServiceNow Tools</p>
            </div>
            <div className="bg-white/20 backdrop-blur-sm rounded-lg px-6 py-3">
              <p className="text-2xl">{tools.filter(t => t.category === 'Azure Storage').length}</p>
              <p className="text-sm text-purple-100">Azure Tools</p>
            </div>
            <div className="bg-white/20 backdrop-blur-sm rounded-lg px-6 py-3">
              <p className="text-2xl">{tools.filter(t => t.category === 'Knowledge Base').length}</p>
              <p className="text-sm text-purple-100">Knowledge Base Tools</p>
            </div>
          </div>
        </motion.div>

        {/* CTA Section */}
        <motion.div 
          className="bg-gradient-to-r from-green-600 to-emerald-600 rounded-2xl p-8 sm:p-12 text-white text-center shadow-2xl"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <Plus className="w-12 h-12 mx-auto mb-4" />
          <h2 className="text-3xl sm:text-4xl mb-4">Ready for More?</h2>
          <p className="text-lg text-green-100 max-w-2xl mx-auto mb-6">
            Extend AuRA's capabilities by adding your own custom tools with specific logic and integrations
          </p>
          <Button 
            onClick={() => onNavigate('Add Tools')}
            className="bg-white text-green-600 hover:bg-green-50 px-8 py-3"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Custom Tool
          </Button>
        </motion.div>
      </div>
      
      <Footer />
    </div>
  );
}
