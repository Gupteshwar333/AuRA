import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Footer } from '../Footer';
import { motion } from 'motion/react';
import { 
  Brain, Target, Zap, Network, LineChart, 
  Users, TrendingUp, Shield, Clock, Sparkles 
} from 'lucide-react';

interface AboutUsPageProps {
  onNavigate: (page: string) => void;
}

export function AboutUsPage({ onNavigate }: AboutUsPageProps) {
  const keyFeatures = [
    {
      icon: '🧠',
      title: 'Autonomy',
      description: 'AI agents operate independently, making decisions without constant human oversight.',
      gradient: 'from-blue-500 to-cyan-500'
    },
    {
      icon: '🎯',
      title: 'Goal-Oriented Behavior',
      description: 'Break down complex objectives into actionable sub-tasks and execute with precision.',
      gradient: 'from-purple-500 to-pink-500'
    },
    {
      icon: '🔄',
      title: 'Adaptability',
      description: 'Dynamically adjust to changing conditions and environments in real-time.',
      gradient: 'from-green-500 to-emerald-500'
    },
    {
      icon: '💬',
      title: 'Natural Language Processing',
      description: 'Understand and communicate in natural language for seamless human interaction.',
      gradient: 'from-orange-500 to-red-500'
    },
    {
      icon: '🤝',
      title: 'Collaboration',
      description: 'Work alongside other AI agents and humans to achieve shared objectives.',
      gradient: 'from-yellow-500 to-orange-500'
    },
    {
      icon: '📊',
      title: 'Reasoning & Planning',
      description: 'Analyze complex scenarios and develop optimal strategies for task execution.',
      gradient: 'from-indigo-500 to-purple-500'
    },
    {
      icon: '📚',
      title: 'Continuous Learning',
      description: 'Learn from every interaction and experience to improve future performance.',
      gradient: 'from-pink-500 to-rose-500'
    },
    {
      icon: '⚡',
      title: 'Proactive Action',
      description: 'Anticipate needs and take initiative rather than waiting for commands.',
      gradient: 'from-teal-500 to-cyan-500'
    },
  ];

  const businessBenefits = [
    {
      icon: '⚡',
      title: 'Efficiency',
      description: 'Automate end-to-end workflows and eliminate manual intervention',
      gradient: 'from-blue-500 to-cyan-500'
    },
    {
      icon: '🎯',
      title: 'Decision-Making',
      description: 'Enhanced decision quality through data-driven, autonomous analysis',
      gradient: 'from-purple-500 to-pink-500'
    },
    {
      icon: '📈',
      title: 'Scalability',
      description: 'Scale operations without proportional increase in resources',
      gradient: 'from-green-500 to-emerald-500'
    },
    {
      icon: '💡',
      title: 'Innovation',
      description: 'Unlock new possibilities with AI-driven insights and automation',
      gradient: 'from-orange-500 to-red-500'
    },
    {
      icon: '💰',
      title: 'Cost Reduction',
      description: 'Reduce operational costs through intelligent automation',
      gradient: 'from-yellow-500 to-orange-500'
    },
    {
      icon: '🚀',
      title: 'Speed',
      description: 'Accelerate processes with 24/7 autonomous operations',
      gradient: 'from-indigo-500 to-purple-500'
    },
    {
      icon: '🎨',
      title: 'Flexibility',
      description: 'Adapt quickly to market changes and new opportunities',
      gradient: 'from-pink-500 to-rose-500'
    },
    {
      icon: '🛡️',
      title: 'Reliability',
      description: 'Consistent performance with continuous learning and improvement',
      gradient: 'from-teal-500 to-cyan-500'
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.08
      }
    }
  };

  const cardVariants = {
    hidden: { opacity: 0, scale: 0.9, y: 20 },
    visible: {
      opacity: 1,
      scale: 1,
      y: 0,
      transition: {
        duration: 0.4
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-indigo-50 via-purple-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <motion.div
            className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-r from-indigo-600 to-purple-600 mb-6"
            animate={{
              rotate: [0, 360],
            }}
            transition={{
              duration: 20,
              repeat: Infinity,
              ease: "linear"
            }}
          >
            <Sparkles className="w-10 h-10 text-white" />
          </motion.div>
          <h1 className="text-4xl sm:text-5xl mb-6 text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600">
            About AuRA AI Platform
          </h1>
          <p className="text-xl text-gray-700 max-w-4xl mx-auto leading-relaxed mb-4">
            AuRA AI Platform represents the <span className="font-semibold">next evolution in artificial intelligence</span>, 
            moving beyond reactive tools to proactive, autonomous systems capable of understanding, reasoning, planning, 
            and executing complex tasks with minimal human intervention.
          </p>
          <p className="text-lg text-gray-600 max-w-4xl mx-auto leading-relaxed">
            Our agentic AI systems are goal-oriented, breaking down high-level objectives into sub-tasks, 
            making independent decisions, adapting to changing conditions, learning from experiences, 
            and collaborating with other AI agents and humans to achieve desired outcomes.
          </p>
        </motion.div>

        {/* Key Features */}
        <div className="mb-12">
          <motion.h2 
            className="text-3xl text-center mb-12 text-gray-800"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            Key Features
          </motion.h2>
          <motion.div 
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            {keyFeatures.map((feature) => (
              <motion.div key={feature.title} variants={cardVariants}>
                <Card className="h-full hover:shadow-2xl transition-all duration-300 hover:-translate-y-3 group overflow-hidden relative">
                  <div className={`absolute inset-0 bg-gradient-to-br ${feature.gradient} opacity-0 group-hover:opacity-10 transition-opacity duration-300`} />
                  <CardHeader className="relative">
                    <div className="text-center mb-3">
                      <motion.span 
                        className="text-5xl inline-block"
                        whileHover={{ 
                          scale: 1.2,
                          rotate: 360,
                          transition: { duration: 0.5 }
                        }}
                      >
                        {feature.icon}
                      </motion.span>
                    </div>
                    <CardTitle className="text-center text-lg">{feature.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="relative">
                    <p className="text-sm text-gray-600 text-center">{feature.description}</p>
                    <motion.div 
                      className={`h-1 bg-gradient-to-r ${feature.gradient} mt-4 rounded-full`}
                      initial={{ scaleX: 0 }}
                      whileInView={{ scaleX: 1 }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.6 }}
                    />
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>

        {/* Business Benefits */}
        <div className="mb-12">
          <motion.h2 
            className="text-3xl text-center mb-12 text-gray-800"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            Business Benefits
          </motion.h2>
          <motion.div 
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            {businessBenefits.map((benefit, index) => (
              <motion.div key={benefit.title} variants={cardVariants}>
                <Card className="h-full hover:shadow-2xl transition-all duration-300 hover:-translate-y-3 group overflow-hidden relative">
                  <div className={`absolute inset-0 bg-gradient-to-br ${benefit.gradient} opacity-0 group-hover:opacity-10 transition-opacity duration-300`} />
                  <CardHeader className="relative">
                    <div className="text-center mb-3">
                      <motion.span 
                        className="text-5xl inline-block"
                        whileHover={{ 
                          scale: 1.2,
                          rotate: 360,
                          transition: { duration: 0.5 }
                        }}
                      >
                        {benefit.icon}
                      </motion.span>
                    </div>
                    <CardTitle className="text-center text-lg">{benefit.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="relative">
                    <p className="text-sm text-gray-600 text-center">{benefit.description}</p>
                    <motion.div 
                      className={`h-1 bg-gradient-to-r ${benefit.gradient} mt-4 rounded-full`}
                      initial={{ scaleX: 0 }}
                      whileInView={{ scaleX: 1 }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.6, delay: index * 0.05 }}
                    />
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>

        {/* Call to Action */}
        <motion.div 
          className="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 rounded-2xl text-white p-8 sm:p-12 text-center shadow-2xl"
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl sm:text-4xl mb-4">Ready to Unlock Unprecedented Efficiency?</h2>
          <p className="text-lg text-indigo-100 max-w-2xl mx-auto mb-6">
            Join thousands of organizations leveraging AuRA AI's autonomous agents to automate workflows, 
            enhance decision-making, and drive innovation
          </p>
          <motion.button
            onClick={() => onNavigate('Get Started')}
            className="bg-white text-indigo-600 px-8 py-3 rounded-lg hover:shadow-xl transition-shadow"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Get Started Today
          </motion.button>
        </motion.div>
      </div>
      
      <Footer />
    </div>
  );
}
