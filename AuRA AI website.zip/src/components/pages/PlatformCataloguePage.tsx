import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Database, Cloud, Code, Cpu, Globe, Lock, Zap, Box } from 'lucide-react';

export function PlatformCataloguePage() {
  const platforms = [
    {
      icon: Database,
      name: 'DataHub Pro',
      category: 'Data Management',
      description: 'Comprehensive data management and analytics platform with real-time insights.',
      features: ['Real-time Analytics', 'Data Visualization', 'Cloud Storage'],
      color: 'from-blue-500 to-cyan-500',
      badge: 'Popular'
    },
    {
      icon: Cloud,
      name: 'CloudSync',
      category: 'Cloud Services',
      description: 'Seamless cloud synchronization and storage solution for enterprise needs.',
      features: ['Auto Backup', 'File Sharing', 'Team Collaboration'],
      color: 'from-purple-500 to-pink-500',
      badge: 'New'
    },
    {
      icon: Code,
      name: 'DevKit Studio',
      category: 'Development',
      description: 'Complete development toolkit with CI/CD integration and code management.',
      features: ['Version Control', 'CI/CD Pipeline', 'Code Review'],
      color: 'from-green-500 to-emerald-500',
      badge: null
    },
    {
      icon: Cpu,
      name: 'AI Engine',
      category: 'Artificial Intelligence',
      description: 'Advanced AI and machine learning platform for intelligent automation.',
      features: ['ML Models', 'NLP Processing', 'Computer Vision'],
      color: 'from-orange-500 to-red-500',
      badge: 'Premium'
    },
    {
      icon: Globe,
      name: 'WebFlow Manager',
      category: 'Web Services',
      description: 'Complete web application management with monitoring and optimization.',
      features: ['Performance Monitoring', 'SEO Tools', 'Analytics'],
      color: 'from-indigo-500 to-blue-500',
      badge: null
    },
    {
      icon: Lock,
      name: 'SecureVault',
      category: 'Security',
      description: 'Enterprise security platform with advanced threat detection and prevention.',
      features: ['Threat Detection', 'Encryption', '2FA Support'],
      color: 'from-red-500 to-rose-500',
      badge: 'Enterprise'
    },
    {
      icon: Zap,
      name: 'AutoFlow',
      category: 'Automation',
      description: 'Workflow automation platform to streamline your business processes.',
      features: ['Task Automation', 'Workflow Builder', 'API Integration'],
      color: 'from-yellow-500 to-orange-500',
      badge: 'Popular'
    },
    {
      icon: Box,
      name: 'StorageMax',
      category: 'Storage',
      description: 'Scalable storage solution with unlimited capacity and high availability.',
      features: ['Unlimited Storage', 'CDN Integration', 'Backup'],
      color: 'from-teal-500 to-cyan-500',
      badge: null
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl sm:text-5xl mb-4 text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-pink-600">
            Platform Catalogue
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Explore our comprehensive suite of platforms designed to accelerate your business
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {platforms.map((platform) => {
            const Icon = platform.icon;
            return (
              <Card key={platform.name} className="hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
                <CardHeader>
                  <div className="flex items-start justify-between mb-4">
                    <div className={`w-12 h-12 rounded-lg bg-gradient-to-r ${platform.color} flex items-center justify-center`}>
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    {platform.badge && (
                      <Badge variant="secondary">{platform.badge}</Badge>
                    )}
                  </div>
                  <CardTitle>{platform.name}</CardTitle>
                  <CardDescription>{platform.category}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-gray-600">{platform.description}</p>
                  <div className="space-y-2">
                    {platform.features.map((feature) => (
                      <div key={feature} className="flex items-center gap-2 text-sm">
                        <div className="w-1.5 h-1.5 rounded-full bg-gradient-to-r from-purple-600 to-pink-600" />
                        <span className="text-gray-700">{feature}</span>
                      </div>
                    ))}
                  </div>
                  <Button className={`w-full bg-gradient-to-r ${platform.color} hover:opacity-90`}>
                    Explore
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}
