import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Footer } from '../Footer';
import { motion } from 'motion/react';
import { Plus, Save, RotateCcw, Lock, Wrench, CheckCircle2, Eye, EyeOff, Search, Edit, Trash2, Users, Code, Brain, LayoutDashboard, UserPlus, PlusCircle, ArrowLeft, X } from 'lucide-react';
import { useState } from 'react';

interface AddToolsPageProps {
  onNavigate: (page: string) => void;
}

interface Persona {
  id: string;
  name: string;
  description: string;
  systemPrompt: string;
  toolIds: string[];
  createdAt: string;
}

interface Tool {
  id: string;
  name: string;
  description: string;
  inputDetails: string;
  logic: string;
  createdAt: string;
}

export function AddToolsPage({ onNavigate }: AddToolsPageProps) {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'create-persona' | 'create-tool' | 'persona-detail' | 'tool-management'>('dashboard');
  const [showPassword, setShowPassword] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPersona, setSelectedPersona] = useState<Persona | null>(null);
  
  // Mock data for personas
  const [personas, setPersonas] = useState<Persona[]>([
    {
      id: '1',
      name: 'Customer Support Agent',
      description: 'AI agent specialized in handling customer inquiries and support tickets',
      systemPrompt: 'You are a helpful customer support assistant. Be empathetic, professional, and solution-oriented.',
      toolIds: ['1', '2'],
      createdAt: '2024-03-15'
    },
    {
      id: '2',
      name: 'Data Analyst',
      description: 'AI agent for data analysis and insights generation',
      systemPrompt: 'You are a data analyst. Analyze data, identify patterns, and provide actionable insights.',
      toolIds: ['3'],
      createdAt: '2024-03-16'
    }
  ]);

  // Mock data for tools
  const [tools, setTools] = useState<Tool[]>([
    {
      id: '1',
      name: 'Email Sender',
      description: 'Send emails to customers',
      inputDetails: 'recipient: string, subject: string, body: string',
      logic: 'function sendEmail(recipient, subject, body) { /* email logic */ }',
      createdAt: '2024-03-15'
    },
    {
      id: '2',
      name: 'Ticket Manager',
      description: 'Create and update support tickets',
      inputDetails: 'ticketId: string, status: string, priority: string',
      logic: 'function manageTicket(ticketId, status, priority) { /* ticket logic */ }',
      createdAt: '2024-03-15'
    },
    {
      id: '3',
      name: 'Data Query',
      description: 'Query database for analytics',
      inputDetails: 'query: string, filters: object',
      logic: 'function queryData(query, filters) { /* query logic */ }',
      createdAt: '2024-03-16'
    }
  ]);

  // Form states
  const [personaForm, setPersonaForm] = useState({
    name: '',
    description: '',
    systemPrompt: ''
  });

  const [toolForm, setToolForm] = useState({
    name: '',
    description: '',
    inputDetails: '',
    logic: ''
  });

  const handlePersonaChange = (field: string, value: string) => {
    setPersonaForm(prev => ({ ...prev, [field]: value }));
  };

  const handleToolChange = (field: string, value: string) => {
    setToolForm(prev => ({ ...prev, [field]: value }));
  };

  const handlePersonaReset = () => {
    setPersonaForm({
      name: '',
      description: '',
      systemPrompt: ''
    });
  };

  const handleToolReset = () => {
    setToolForm({
      name: '',
      description: '',
      inputDetails: '',
      logic: ''
    });
  };

  const handlePersonaSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newPersona: Persona = {
      id: (personas.length + 1).toString(),
      name: personaForm.name,
      description: personaForm.description,
      systemPrompt: personaForm.systemPrompt,
      toolIds: [],
      createdAt: new Date().toISOString().split('T')[0]
    };
    setPersonas([...personas, newPersona]);
    alert('Persona added successfully!');
    handlePersonaReset();
  };

  const handleToolSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newTool: Tool = {
      id: (tools.length + 1).toString(),
      name: toolForm.name,
      description: toolForm.description,
      inputDetails: toolForm.inputDetails,
      logic: toolForm.logic,
      createdAt: new Date().toISOString().split('T')[0]
    };
    setTools([...tools, newTool]);
    alert('Tool added successfully!');
    handleToolReset();
  };

  const handlePersonaDelete = (id: string) => {
    setPersonas(personas.filter(persona => persona.id !== id));
    alert('Persona deleted successfully!');
  };

  const handleToolDelete = (id: string) => {
    setTools(tools.filter(tool => tool.id !== id));
    alert('Tool deleted successfully!');
  };

  const handlePersonaSelect = (persona: Persona) => {
    setSelectedPersona(persona);
    setActiveTab('persona-detail');
  };

  const handleToolSelect = (tool: Tool) => {
    setToolForm({
      name: tool.name,
      description: tool.description,
      inputDetails: tool.inputDetails,
      logic: tool.logic
    });
    setActiveTab('create-tool');
  };

  const handlePersonaEdit = (persona: Persona) => {
    setPersonaForm({
      name: persona.name,
      description: persona.description,
      systemPrompt: persona.systemPrompt
    });
    setActiveTab('create-persona');
  };

  const handleToolEdit = (tool: Tool) => {
    setToolForm({
      name: tool.name,
      description: tool.description,
      inputDetails: tool.inputDetails,
      logic: tool.logic
    });
    setActiveTab('create-tool');
  };

  const handlePersonaUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedPersona) {
      const updatedPersona: Persona = {
        id: selectedPersona.id,
        name: personaForm.name,
        description: personaForm.description,
        systemPrompt: personaForm.systemPrompt,
        toolIds: selectedPersona.toolIds,
        createdAt: selectedPersona.createdAt
      };
      setPersonas(personas.map(persona => persona.id === selectedPersona.id ? updatedPersona : persona));
      alert('Persona updated successfully!');
      handlePersonaReset();
      setActiveTab('dashboard');
    }
  };

  const handleToolUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    const updatedTool: Tool = {
      id: toolForm.name,
      name: toolForm.name,
      description: toolForm.description,
      inputDetails: toolForm.inputDetails,
      logic: toolForm.logic,
      createdAt: new Date().toISOString().split('T')[0]
    };
    setTools(tools.map(tool => tool.id === toolForm.name ? updatedTool : tool));
    alert('Tool updated successfully!');
    handleToolReset();
    setActiveTab('dashboard');
  };

  const handlePersonaSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };

  const filteredPersonas = personas.filter(persona => persona.name.toLowerCase().includes(searchTerm.toLowerCase()));

  return (
    <div className="min-h-screen bg-gradient-to-b from-indigo-50 via-purple-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <motion.div 
          className="text-center mb-12"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <motion.div
            className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-r from-indigo-600 to-purple-600 mb-6"
            animate={{
              rotate: [0, 360],
            }}
            transition={{
              duration: 20,
              repeat: Infinity,
              ease: "linear"
            }}
          >
            <Plus className="w-10 h-10 text-white" />
          </motion.div>
          <h1 className="text-4xl sm:text-5xl mb-4 text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600">
            Add Tools & Credentials
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Configure your AI tools and securely store credentials for seamless integration with AuRA AI Platform
          </p>
          <Button 
            onClick={() => onNavigate('List Tools')}
            variant="outline"
            className="mt-4"
          >
            View Tools List
          </Button>
        </motion.div>

        {/* Tab Navigation - Full Width Buttons */}
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <Button
            onClick={() => setActiveTab('dashboard')}
            className={`h-14 text-lg font-semibold transition-all duration-300 ${
              activeTab === 'dashboard' 
                ? 'bg-gradient-to-r from-indigo-600 to-indigo-700 text-white shadow-lg scale-105' 
                : 'bg-white text-indigo-600 border-2 border-indigo-300 hover:border-indigo-500 hover:shadow-md'
            }`}
          >
            <LayoutDashboard className="w-5 h-5 mr-2" />
            Dashboard
          </Button>
          <Button
            onClick={() => setActiveTab('create-persona')}
            className={`h-14 text-lg font-semibold transition-all duration-300 ${
              activeTab === 'create-persona' 
                ? 'bg-gradient-to-r from-purple-600 to-purple-700 text-white shadow-lg scale-105' 
                : 'bg-white text-purple-600 border-2 border-purple-300 hover:border-purple-500 hover:shadow-md'
            }`}
          >
            <UserPlus className="w-5 h-5 mr-2" />
            Create Persona
          </Button>
          <Button
            onClick={() => setActiveTab('create-tool')}
            className={`h-14 text-lg font-semibold transition-all duration-300 ${
              activeTab === 'create-tool' 
                ? 'bg-gradient-to-r from-pink-600 to-pink-700 text-white shadow-lg scale-105' 
                : 'bg-white text-pink-600 border-2 border-pink-300 hover:border-pink-500 hover:shadow-md'
            }`}
          >
            <PlusCircle className="w-5 h-5 mr-2" />
            Create Tool
          </Button>
        </motion.div>

        {/* Dashboard */}
        {activeTab === 'dashboard' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Persona List */}
            <Card className="shadow-2xl border-2 border-indigo-200 h-full">
              <CardHeader className="bg-gradient-to-r from-indigo-600 to-indigo-700 text-white">
                <CardTitle className="text-2xl flex items-center gap-2">
                  <Users className="w-6 h-6" />
                  Personas
                </CardTitle>
                <CardDescription className="text-indigo-100">
                  Manage AI personas for different roles
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between mb-4">
                  <Input
                    type="text"
                    value={searchTerm}
                    onChange={handlePersonaSearch}
                    placeholder="Search personas..."
                    className="h-11"
                  />
                </div>
                <div className="space-y-4">
                  {filteredPersonas.map(persona => (
                    <div key={persona.id} className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-bold text-gray-800">{persona.name}</p>
                        <p className="text-xs text-gray-500">{persona.description}</p>
                      </div>
                      <div className="flex items-center">
                        <Button
                          onClick={() => handlePersonaSelect(persona)}
                          variant="outline"
                          className="mr-2"
                        >
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button
                          onClick={() => handlePersonaEdit(persona)}
                          variant="outline"
                          className="mr-2"
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          onClick={() => handlePersonaDelete(persona.id)}
                          variant="outline"
                          className="mr-2"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Tool List */}
            <Card className="shadow-2xl border-2 border-purple-200 h-full">
              <CardHeader className="bg-gradient-to-r from-purple-600 to-purple-700 text-white">
                <CardTitle className="text-2xl flex items-center gap-2">
                  <Wrench className="w-6 h-6" />
                  Tools
                </CardTitle>
                <CardDescription className="text-purple-100">
                  Manage AI tools for different operations
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-6">
                <div className="space-y-4">
                  {tools.map(tool => (
                    <div key={tool.id} className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-bold text-gray-800">{tool.name}</p>
                        <p className="text-xs text-gray-500">{tool.description}</p>
                      </div>
                      <div className="flex items-center">
                        <Button
                          onClick={() => handleToolSelect(tool)}
                          variant="outline"
                          className="mr-2"
                        >
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button
                          onClick={() => handleToolEdit(tool)}
                          variant="outline"
                          className="mr-2"
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          onClick={() => handleToolDelete(tool.id)}
                          variant="outline"
                          className="mr-2"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Create Persona */}
        {activeTab === 'create-persona' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <Card className="shadow-2xl border-2 border-indigo-200 h-full">
                <CardHeader className="bg-gradient-to-r from-indigo-600 to-indigo-700 text-white">
                  <CardTitle className="text-2xl flex items-center gap-2">
                    <Lock className="w-6 h-6" />
                    Add New Persona
                  </CardTitle>
                  <CardDescription className="text-indigo-100">
                    Define a new AI persona for specific roles
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-6">
                  <form onSubmit={handlePersonaSubmit} className="space-y-5">
                    <div className="space-y-2">
                      <Label htmlFor="persona-name" className="text-base">
                        Persona Name *
                      </Label>
                      <Input
                        id="persona-name"
                        value={personaForm.name}
                        onChange={(e) => handlePersonaChange('name', e.target.value)}
                        placeholder="Enter persona name..."
                        required
                        className="h-11"
                      />
                      <p className="text-xs text-gray-500">Choose a descriptive name for your persona</p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="persona-description" className="text-base">
                        Description *
                      </Label>
                      <Textarea
                        id="persona-description"
                        value={personaForm.description}
                        onChange={(e) => handlePersonaChange('description', e.target.value)}
                        placeholder="Enter persona description..."
                        required
                        rows={4}
                        className="font-mono text-sm"
                      />
                      <p className="text-xs text-gray-500">Enter a description for your persona</p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="persona-systemPrompt" className="text-base">
                        System Prompt *
                      </Label>
                      <Textarea
                        id="persona-systemPrompt"
                        value={personaForm.systemPrompt}
                        onChange={(e) => handlePersonaChange('systemPrompt', e.target.value)}
                        placeholder="Enter system prompt..."
                        required
                        rows={4}
                        className="font-mono text-sm"
                      />
                      <p className="text-xs text-gray-500">Enter a system prompt for your persona</p>
                    </div>

                    <div className="flex gap-3 pt-4">
                      <Button 
                        type="button"
                        onClick={handlePersonaReset}
                        variant="outline"
                        className="flex-1 h-11"
                      >
                        <RotateCcw className="w-4 h-4 mr-2" />
                        Reset
                      </Button>
                      <Button 
                        type="submit"
                        className="flex-1 bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-700 hover:to-indigo-800 h-11"
                      >
                        <Save className="w-4 h-4 mr-2" />
                        Save Persona
                      </Button>
                    </div>
                  </form>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        )}

        {/* Create Tool */}
        {activeTab === 'create-tool' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <Card className="shadow-2xl border-2 border-purple-200 h-full">
                <CardHeader className="bg-gradient-to-r from-purple-600 to-purple-700 text-white">
                  <CardTitle className="text-2xl flex items-center gap-2">
                    <Wrench className="w-6 h-6" />
                    Add New Tool
                  </CardTitle>
                  <CardDescription className="text-purple-100">
                    Register a new tool to the AuRA AI Platform
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-6">
                  <form onSubmit={handleToolSubmit} className="space-y-5">
                    <div className="space-y-2">
                      <Label htmlFor="tool-name" className="text-base">
                        Tool Name *
                      </Label>
                      <Input
                        id="tool-name"
                        value={toolForm.name}
                        onChange={(e) => handleToolChange('name', e.target.value)}
                        placeholder="Enter tool name..."
                        required
                        className="h-11"
                      />
                      <p className="text-xs text-gray-500">Choose a descriptive name for your tool</p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="tool-description" className="text-base">
                        Description *
                      </Label>
                      <Textarea
                        id="tool-description"
                        value={toolForm.description}
                        onChange={(e) => handleToolChange('description', e.target.value)}
                        placeholder="Enter tool description..."
                        required
                        rows={4}
                        className="font-mono text-sm"
                      />
                      <p className="text-xs text-gray-500">Enter a description for your tool</p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="tool-inputDetails" className="text-base">
                        Input Details *
                      </Label>
                      <Textarea
                        id="tool-inputDetails"
                        value={toolForm.inputDetails}
                        onChange={(e) => handleToolChange('inputDetails', e.target.value)}
                        placeholder="Enter input details..."
                        required
                        rows={4}
                        className="font-mono text-sm"
                      />
                      <p className="text-xs text-gray-500">Enter input details for your tool</p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="tool-logic" className="text-base">
                        Tool Logic *
                      </Label>
                      <Textarea
                        id="tool-logic"
                        value={toolForm.logic}
                        onChange={(e) => handleToolChange('logic', e.target.value)}
                        placeholder={`from config import mcp\n\n@mcp.tool()\ndef add_numbers(num1: float, num2: float) -> dict:\n    """\n    Adds two numbers and returns their sum.\n    \n    Args:\n        num1 (float): The first number.\n        num2 (float): The second number.\n    \n    Returns:\n        dict: A dictionary containing the sum, or an error message if the operation fails.\n    """\n    try:\n        result = num1 + num2\n        return {"sum": result, "message": f"Successfully added {num1} and {num2}."}\n    except TypeError:\n        return {"error": "Invalid input: Please provide two numbers."}\n    except Exception as e:\n        return {"error": f"An unexpected error occurred: {str(e)}"}`}
                        required
                        rows={18}
                        className="font-mono text-sm"
                      />
                      <p className="text-xs text-gray-500">Enter Tool Logic of your tool</p>
                    </div>

                    <div className="flex gap-3 pt-4">
                      <Button 
                        type="button"
                        onClick={handleToolReset}
                        variant="outline"
                        className="flex-1 h-11"
                      >
                        <RotateCcw className="w-4 h-4 mr-2" />
                        Reset
                      </Button>
                      <Button 
                        type="submit"
                        className="flex-1 bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 h-11"
                      >
                        <CheckCircle2 className="w-4 h-4 mr-2" />
                        Add Tool
                      </Button>
                    </div>
                  </form>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        )}

        {/* Persona Detail */}
        {activeTab === 'persona-detail' && selectedPersona && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <Card className="shadow-2xl border-2 border-indigo-200 h-full">
                <CardHeader className="bg-gradient-to-r from-indigo-600 to-indigo-700 text-white">
                  <CardTitle className="text-2xl flex items-center gap-2">
                    <Lock className="w-6 h-6" />
                    Persona Detail
                  </CardTitle>
                  <CardDescription className="text-indigo-100">
                    View and manage details of a persona
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-6">
                  <form onSubmit={handlePersonaUpdate} className="space-y-5">
                    <div className="space-y-2">
                      <Label htmlFor="persona-name" className="text-base">
                        Persona Name *
                      </Label>
                      <Input
                        id="persona-name"
                        value={personaForm.name}
                        onChange={(e) => handlePersonaChange('name', e.target.value)}
                        placeholder="Enter persona name..."
                        required
                        className="h-11"
                      />
                      <p className="text-xs text-gray-500">Choose a descriptive name for your persona</p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="persona-description" className="text-base">
                        Description *
                      </Label>
                      <Textarea
                        id="persona-description"
                        value={personaForm.description}
                        onChange={(e) => handlePersonaChange('description', e.target.value)}
                        placeholder="Enter persona description..."
                        required
                        rows={4}
                        className="font-mono text-sm"
                      />
                      <p className="text-xs text-gray-500">Enter a description for your persona</p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="persona-systemPrompt" className="text-base">
                        System Prompt *
                      </Label>
                      <Textarea
                        id="persona-systemPrompt"
                        value={personaForm.systemPrompt}
                        onChange={(e) => handlePersonaChange('systemPrompt', e.target.value)}
                        placeholder="Enter system prompt..."
                        required
                        rows={4}
                        className="font-mono text-sm"
                      />
                      <p className="text-xs text-gray-500">Enter a system prompt for your persona</p>
                    </div>

                    <div className="flex gap-3 pt-4">
                      <Button 
                        type="button"
                        onClick={handlePersonaReset}
                        variant="outline"
                        className="flex-1 h-11"
                      >
                        <RotateCcw className="w-4 h-4 mr-2" />
                        Reset
                      </Button>
                      <Button 
                        type="submit"
                        className="flex-1 bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-700 hover:to-indigo-800 h-11"
                      >
                        <Save className="w-4 h-4 mr-2" />
                        Update Persona
                      </Button>
                    </div>
                  </form>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        )}

        {/* Tool Management */}
        {activeTab === 'tool-management' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <Card className="shadow-2xl border-2 border-purple-200 h-full">
                <CardHeader className="bg-gradient-to-r from-purple-600 to-purple-700 text-white">
                  <CardTitle className="text-2xl flex items-center gap-2">
                    <Wrench className="w-6 h-6" />
                    Tool Management
                  </CardTitle>
                  <CardDescription className="text-purple-100">
                    Manage and update AI tools
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-6">
                  <form onSubmit={handleToolUpdate} className="space-y-5">
                    <div className="space-y-2">
                      <Label htmlFor="tool-name" className="text-base">
                        Tool Name *
                      </Label>
                      <Input
                        id="tool-name"
                        value={toolForm.name}
                        onChange={(e) => handleToolChange('name', e.target.value)}
                        placeholder="Enter tool name..."
                        required
                        className="h-11"
                      />
                      <p className="text-xs text-gray-500">Choose a descriptive name for your tool</p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="tool-description" className="text-base">
                        Description *
                      </Label>
                      <Textarea
                        id="tool-description"
                        value={toolForm.description}
                        onChange={(e) => handleToolChange('description', e.target.value)}
                        placeholder="Enter tool description..."
                        required
                        rows={4}
                        className="font-mono text-sm"
                      />
                      <p className="text-xs text-gray-500">Enter a description for your tool</p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="tool-inputDetails" className="text-base">
                        Input Details *
                      </Label>
                      <Textarea
                        id="tool-inputDetails"
                        value={toolForm.inputDetails}
                        onChange={(e) => handleToolChange('inputDetails', e.target.value)}
                        placeholder="Enter input details..."
                        required
                        rows={4}
                        className="font-mono text-sm"
                      />
                      <p className="text-xs text-gray-500">Enter input details for your tool</p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="tool-logic" className="text-base">
                        Tool Logic *
                      </Label>
                      <Textarea
                        id="tool-logic"
                        value={toolForm.logic}
                        onChange={(e) => handleToolChange('logic', e.target.value)}
                        placeholder={`from config import mcp\n\n@mcp.tool()\ndef add_numbers(num1: float, num2: float) -> dict:\n    """\n    Adds two numbers and returns their sum.\n    \n    Args:\n        num1 (float): The first number.\n        num2 (float): The second number.\n    \n    Returns:\n        dict: A dictionary containing the sum, or an error message if the operation fails.\n    """\n    try:\n        result = num1 + num2\n        return {"sum": result, "message": f"Successfully added {num1} and {num2}."}\n    except TypeError:\n        return {"error": "Invalid input: Please provide two numbers."}\n    except Exception as e:\n        return {"error": f"An unexpected error occurred: {str(e)}"}`}
                        required
                        rows={18}
                        className="font-mono text-sm"
                      />
                      <p className="text-xs text-gray-500">Enter Tool Logic of your tool</p>
                    </div>

                    <div className="flex gap-3 pt-4">
                      <Button 
                        type="button"
                        onClick={handleToolReset}
                        variant="outline"
                        className="flex-1 h-11"
                      >
                        <RotateCcw className="w-4 h-4 mr-2" />
                        Reset
                      </Button>
                      <Button 
                        type="submit"
                        className="flex-1 bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 h-11"
                      >
                        <CheckCircle2 className="w-4 h-4 mr-2" />
                        Update Tool
                      </Button>
                    </div>
                  </form>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        )}
      </div>
      
      <Footer />
    </div>
  );
}