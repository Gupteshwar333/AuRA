import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Footer } from '../Footer';
import { motion } from 'motion/react';
import { CheckCircle2, Rocket, Users, Zap, Shield, Star, Brain } from 'lucide-react';
import { useState } from 'react';

interface GetStartedPageProps {
  onNavigate: (page: string) => void;
}

export function GetStartedPage({ onNavigate }: GetStartedPageProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    phone: ''
  });

  const steps = [
    {
      icon: Users,
      title: 'Create Your Account',
      description: 'Sign up and configure your AuRA AI environment in minutes.',
      gradient: 'from-blue-500 to-cyan-500'
    },
    {
      icon: Brain,
      title: 'Deploy AI Agents',
      description: 'Choose and deploy autonomous agents that fit your business needs.',
      gradient: 'from-purple-500 to-pink-500'
    },
    {
      icon: Rocket,
      title: 'Automate & Scale',
      description: 'Watch as AI agents autonomously handle complex tasks and workflows.',
      gradient: 'from-green-500 to-emerald-500'
    },
  ];

  const features = [
    '14-day free trial with full platform access',
    'Deploy unlimited autonomous AI agents',
    'Dedicated onboarding and training',
    'Seamless integration with existing systems',
    'Enterprise-grade security and compliance',
    'Cancel anytime, no long-term commitment'
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 via-purple-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <motion.div
            className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-r from-blue-600 to-purple-600 mb-6"
            animate={{
              scale: [1, 1.1, 1],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            <Rocket className="w-10 h-10 text-white" />
          </motion.div>
          <h1 className="text-4xl sm:text-5xl mb-4 text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600">
            Get Started with AuRA AI
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Join thousands of organizations deploying autonomous AI agents to automate workflows, 
            enhance decision-making, and unlock unprecedented efficiency
          </p>
        </motion.div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
          {/* Left Side - Form */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <Card className="shadow-2xl border-2 border-blue-100">
              <CardHeader>
                <CardTitle className="text-2xl">Start Your Free Trial</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name *</Label>
                    <Input
                      id="name"
                      placeholder="John Doe"
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Work Email *</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="john@company.com"
                      value={formData.email}
                      onChange={(e) => setFormData({...formData, email: e.target.value})}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="company">Company Name *</Label>
                    <Input
                      id="company"
                      placeholder="Your Company"
                      value={formData.company}
                      onChange={(e) => setFormData({...formData, company: e.target.value})}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input
                      id="phone"
                      type="tel"
                      placeholder="+1 (555) 000-0000"
                      value={formData.phone}
                      onChange={(e) => setFormData({...formData, phone: e.target.value})}
                    />
                  </div>
                  <Button 
                    type="submit" 
                    className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 h-12 text-lg"
                  >
                    <Rocket className="w-5 h-5 mr-2" />
                    Deploy Your First AI Agent
                  </Button>
                  <p className="text-xs text-center text-gray-500">
                    By signing up, you agree to our Terms of Service and Privacy Policy
                  </p>
                </form>

                {/* Features List */}
                <div className="mt-8 space-y-3">
                  {features.map((feature) => (
                    <div key={feature} className="flex items-start gap-3">
                      <CheckCircle2 className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
                      <span className="text-sm text-gray-700">{feature}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Right Side - Steps & Benefits */}
          <motion.div
            className="space-y-8"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <div>
              <h2 className="text-3xl mb-6">How It Works</h2>
              <div className="space-y-6">
                {steps.map((step, index) => {
                  const Icon = step.icon;
                  return (
                    <motion.div
                      key={step.title}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.6 + index * 0.2 }}
                    >
                      <Card className="hover:shadow-lg transition-shadow">
                        <CardHeader>
                          <div className="flex items-start gap-4">
                            <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${step.gradient} flex items-center justify-center flex-shrink-0`}>
                              <Icon className="w-6 h-6 text-white" />
                            </div>
                            <div>
                              <div className="flex items-center gap-2 mb-2">
                                <span className={`text-sm px-2 py-1 rounded-full bg-gradient-to-r ${step.gradient} text-white`}>
                                  Step {index + 1}
                                </span>
                              </div>
                              <CardTitle className="text-lg">{step.title}</CardTitle>
                              <p className="text-sm text-gray-600 mt-2">{step.description}</p>
                            </div>
                          </div>
                        </CardHeader>
                      </Card>
                    </motion.div>
                  );
                })}
              </div>
            </div>

            {/* Trust Indicators */}
            <Card className="bg-gradient-to-r from-blue-600 to-purple-600 text-white border-0">
              <CardContent className="pt-6">
                <div className="flex items-center justify-center gap-2 mb-4">
                  <Star className="w-6 h-6 fill-yellow-400 text-yellow-400" />
                  <Star className="w-6 h-6 fill-yellow-400 text-yellow-400" />
                  <Star className="w-6 h-6 fill-yellow-400 text-yellow-400" />
                  <Star className="w-6 h-6 fill-yellow-400 text-yellow-400" />
                  <Star className="w-6 h-6 fill-yellow-400 text-yellow-400" />
                </div>
                <p className="text-center text-lg mb-2">Trusted by 10,000+ Organizations</p>
                <p className="text-center text-blue-100 text-sm">
                  "AuRA AI's autonomous agents have transformed our operations. They make intelligent decisions 
                  24/7, continuously learning and improving. The efficiency gains have been remarkable!"
                </p>
                <p className="text-center text-sm text-blue-200 mt-4">
                  — Sarah Chen, CTO at TechForward Inc.
                </p>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
      
      <Footer />
    </div>
  );
}
