import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Footer } from '../Footer';
import { motion } from 'motion/react';
import { Brain, Target, Zap, Users, ArrowRight, Sparkles, Network, Cpu, TrendingUp, Shield, Award, Plus, List } from 'lucide-react';
import { ImageWithFallback } from '../figma/ImageWithFallback';

interface HomePageProps {
  onNavigate: (page: string) => void;
}

export function HomePage({ onNavigate }: HomePageProps) {
  const features = [
    {
      icon: Brain,
      title: 'Autonomous Intelligence',
      description: 'Proactive AI systems that understand, reason, and plan with minimal human intervention.',
    },
    {
      icon: Target,
      title: 'Goal-Oriented',
      description: 'Break down complex objectives into sub-tasks and execute with precision and adaptability.',
    },
    {
      icon: Network,
      title: 'Collaborative AI',
      description: 'Seamlessly collaborate with other AI agents and humans to achieve desired outcomes.',
    },
    {
      icon: Zap,
      title: 'End-to-End Automation',
      description: 'Automate complete workflows from start to finish, unlocking unprecedented efficiency.',
    },
  ];

  const keyFeatures = [
    {
      icon: '🧠',
      title: 'Autonomy',
      description: 'AI agents operate independently, making decisions without constant human oversight.',
    },
    {
      icon: '🎯',
      title: 'Goal-Oriented Behavior',
      description: 'Break down complex objectives into actionable sub-tasks and execute with precision.',
    },
    {
      icon: '🔄',
      title: 'Adaptability',
      description: 'Dynamically adjust to changing conditions and environments in real-time.',
    },
    {
      icon: '💬',
      title: 'Natural Language Processing',
      description: 'Understand and communicate in natural language for seamless human interaction.',
    },
    {
      icon: '🤝',
      title: 'Collaboration',
      description: 'Work alongside other AI agents and humans to achieve shared objectives.',
    },
    {
      icon: '📊',
      title: 'Reasoning & Planning',
      description: 'Analyze complex scenarios and develop optimal strategies for task execution.',
    },
    {
      icon: '📚',
      title: 'Continuous Learning',
      description: 'Learn from every interaction and experience to improve future performance.',
    },
    {
      icon: '⚡',
      title: 'Proactive Action',
      description: 'Anticipate needs and take initiative rather than waiting for commands.',
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.08
      }
    }
  };

  const cardVariants = {
    hidden: { opacity: 0, scale: 0.9, y: 20 },
    visible: {
      opacity: 1,
      scale: 1,
      y: 0,
      transition: {
        duration: 0.4
      }
    }
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <div className="bg-gradient-to-b from-gray-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-20">
          <div className="text-center space-y-6">
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-4xl sm:text-5xl md:text-6xl text-[#000080]"
            >
              Welcome to <span className="text-sky-500">TCS AuRA</span>
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed"
            >
              Moving beyond reactive tools to proactive, autonomous systems capable of understanding, 
              reasoning, planning, and executing complex tasks with minimal human intervention
            </motion.p>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.6 }}
              className="flex flex-wrap justify-center gap-4 pt-4"
            >
              <button 
                onClick={() => onNavigate('Add Tools')}
                className="px-8 py-3 bg-white text-[#000080] border border-[#000080] rounded-full hover:bg-[#000080] hover:text-white transition-all duration-300"
              >
                <span className="flex items-center gap-2">
                  <Plus className="w-4 h-4" />
                  Add tool
                </span>
              </button>
              <button 
                onClick={() => onNavigate('List Tools')}
                className="px-8 py-3 bg-white text-[#000080] border border-[#000080] rounded-full hover:bg-[#000080] hover:text-white transition-all duration-300"
              >
                <span className="flex items-center gap-2">
                  <List className="w-4 h-4" />
                  List tool
                </span>
              </button>
            </motion.div>
          </div>
        </div>
      </div>

      {/* Core Features */}
      <div className="bg-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1, duration: 0.5 }}
                >
                  <Card className="hover:shadow-xl transition-shadow duration-300 h-full border-gray-200">
                    <CardHeader>
                      <div className="w-12 h-12 rounded-lg bg-sky-50 flex items-center justify-center mb-4">
                        <Icon className="w-6 h-6 text-sky-500" />
                      </div>
                      <CardTitle className="text-[#000080]">{feature.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <CardDescription className="text-gray-600">{feature.description}</CardDescription>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>

      {/* About AuRA AI Platform */}
      <div className="bg-black text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            className="text-center mb-12"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl sm:text-4xl mb-6">About AuRA AI Platform</h2>
            <p className="text-lg text-gray-300 max-w-4xl mx-auto leading-relaxed">
              AuRA AI Platform represents the next evolution in artificial intelligence, moving beyond reactive tools 
              to proactive, autonomous systems capable of understanding, reasoning, planning, and executing complex tasks 
              with minimal human intervention.
            </p>
            <p className="text-lg text-gray-300 max-w-4xl mx-auto leading-relaxed mt-4">
              Our agentic AI systems are goal-oriented. They can break down high-level objectives into sub-tasks, 
              make independent decisions, adapt to changing conditions, learn from their experiences, and even collaborate 
              with other AI agents and humans to achieve desired outcomes. This empowers organizations to automate end-to-end 
              workflows, enhance decision-making, and unlock unprecedented levels of efficiency and innovation.
            </p>
          </motion.div>
        </div>
      </div>

      {/* Key Features */}
      <div className="bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.h2 
            className="text-3xl text-center mb-12 text-[#000080]"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            Key Features
          </motion.h2>
          <motion.div 
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            {keyFeatures.map((feature) => (
              <motion.div key={feature.title} variants={cardVariants}>
                <Card className="h-full hover:shadow-xl transition-all duration-300 hover:-translate-y-2 group overflow-hidden relative bg-white border-gray-200">
                  <CardHeader className="relative">
                    <div className="text-center mb-3">
                      <motion.span 
                        className="text-5xl inline-block"
                        whileHover={{ 
                          scale: 1.2,
                          rotate: 360,
                          transition: { duration: 0.5 }
                        }}
                      >
                        {feature.icon}
                      </motion.span>
                    </div>
                    <CardTitle className="text-center text-lg text-[#000080]">{feature.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="relative">
                    <p className="text-sm text-gray-600 text-center">{feature.description}</p>
                    <motion.div 
                      className="h-1 bg-sky-500 mt-4 rounded-full"
                      initial={{ scaleX: 0 }}
                      whileInView={{ scaleX: 1 }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.6 }}
                    />
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>

      <Footer />
    </div>
  );
}