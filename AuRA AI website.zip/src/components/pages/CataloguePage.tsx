import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Footer } from '../Footer';
import { motion } from 'motion/react';
import { Database, Cloud, Code, Cpu, Globe, Lock, Zap, Box, Brain, Network, FileText, Mic } from 'lucide-react';

interface CataloguePageProps {
  onNavigate: (page: string) => void;
}

export function CataloguePage({ onNavigate }: CataloguePageProps) {
  const aiAgents = [
    {
      icon: Brain,
      name: 'Cognitive Agent',
      category: 'Intelligence',
      description: 'Advanced reasoning and problem-solving capabilities for complex decision-making scenarios.',
      features: ['Deep Reasoning', 'Context Understanding', 'Multi-step Planning'],
      color: 'from-blue-500 to-cyan-500',
      badge: 'Enterprise'
    },
    {
      icon: Network,
      name: 'Orchestrator Agent',
      category: 'Coordination',
      description: 'Coordinates multiple AI agents and human teams to achieve complex, multi-faceted objectives.',
      features: ['Agent Management', 'Task Distribution', 'Resource Optimization'],
      color: 'from-purple-500 to-pink-500',
      badge: 'Popular'
    },
    {
      icon: Database,
      name: 'Data Intelligence Agent',
      category: 'Analytics',
      description: 'Autonomously analyzes data, identifies patterns, and generates actionable insights.',
      features: ['Pattern Recognition', 'Predictive Analysis', 'Automated Reporting'],
      color: 'from-green-500 to-emerald-500',
      badge: 'Hot'
    },
    {
      icon: Code,
      name: 'Code Assistant Agent',
      category: 'Development',
      description: 'Helps developers write, review, and optimize code with AI-powered suggestions.',
      features: ['Code Generation', 'Bug Detection', 'Optimization Tips'],
      color: 'from-orange-500 to-red-500',
      badge: null
    },
    {
      icon: Mic,
      name: 'Voice Agent',
      category: 'Communication',
      description: 'Natural voice interactions with context awareness and multi-language support.',
      features: ['Speech Recognition', 'Natural Responses', 'Multi-language'],
      color: 'from-yellow-500 to-orange-500',
      badge: 'New'
    },
    {
      icon: Lock,
      name: 'Security Agent',
      category: 'Protection',
      description: 'Monitors systems, detects threats, and responds to security incidents autonomously.',
      features: ['Threat Detection', 'Incident Response', 'Compliance Monitoring'],
      color: 'from-red-500 to-rose-500',
      badge: 'Enterprise'
    },
    {
      icon: Zap,
      name: 'Process Automation Agent',
      category: 'Automation',
      description: 'Automates repetitive tasks and workflows with intelligent decision-making.',
      features: ['Task Automation', 'Workflow Design', 'Exception Handling'],
      color: 'from-indigo-500 to-purple-500',
      badge: 'Popular'
    },
    {
      icon: FileText,
      name: 'Document Agent',
      category: 'Content',
      description: 'Intelligently processes, categorizes, and extracts information from documents.',
      features: ['Document Analysis', 'Info Extraction', 'Auto-categorization'],
      color: 'from-teal-500 to-cyan-500',
      badge: null
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <motion.div 
          className="text-center mb-12"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h1 className="text-4xl sm:text-5xl mb-4 text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-pink-600">
            AI Agent Catalogue
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Explore our comprehensive suite of autonomous AI agents, each designed to excel at specific tasks 
            while collaborating seamlessly with other agents and humans
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {aiAgents.map((agent, index) => {
            const Icon = agent.icon;
            return (
              <motion.div
                key={agent.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1, duration: 0.5 }}
              >
                <Card className="hover:shadow-xl transition-all duration-300 hover:-translate-y-1 h-full">
                  <CardHeader>
                    <div className="flex items-start justify-between mb-4">
                      <div className={`w-12 h-12 rounded-lg bg-gradient-to-r ${agent.color} flex items-center justify-center`}>
                        <Icon className="w-6 h-6 text-white" />
                      </div>
                      {agent.badge && (
                        <Badge variant="secondary">{agent.badge}</Badge>
                      )}
                    </div>
                    <CardTitle>{agent.name}</CardTitle>
                    <CardDescription>{agent.category}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-sm text-gray-600">{agent.description}</p>
                    <div className="space-y-2">
                      {agent.features.map((feature) => (
                        <div key={feature} className="flex items-center gap-2 text-sm">
                          <div className="w-1.5 h-1.5 rounded-full bg-gradient-to-r from-purple-600 to-pink-600" />
                          <span className="text-gray-700">{feature}</span>
                        </div>
                      ))}
                    </div>
                    <Button 
                      onClick={() => onNavigate('Explore')}
                      className={`w-full bg-gradient-to-r ${agent.color} hover:opacity-90`}
                    >
                      Explore Agent
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {/* CTA */}
        <motion.div
          className="mt-16 bg-gradient-to-r from-purple-600 to-pink-600 rounded-2xl p-8 sm:p-12 text-white text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl mb-4">Need a Custom AI Agent?</h2>
          <p className="text-lg text-purple-100 max-w-2xl mx-auto mb-6">
            We can develop custom autonomous agents tailored to your specific business needs and workflows
          </p>
          <Button 
            onClick={() => onNavigate('Get Started')}
            className="bg-white text-purple-600 hover:bg-purple-50"
          >
            Request Custom Agent
          </Button>
        </motion.div>
      </div>
      
      <Footer />
    </div>
  );
}
