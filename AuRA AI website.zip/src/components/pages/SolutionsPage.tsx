import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Footer } from '../Footer';
import { motion } from 'motion/react';
import { Brain, Workflow, Network, Database, Target, LineChart } from 'lucide-react';

interface SolutionsPageProps {
  onNavigate: (page: string) => void;
}

export function SolutionsPage({ onNavigate }: SolutionsPageProps) {
  const solutions = [
    {
      icon: Brain,
      title: 'Autonomous Decision-Making',
      description: 'Deploy AI agents that make independent, data-driven decisions in real-time, adapting to changing business conditions without constant human oversight.',
      features: ['Real-time Analysis', 'Adaptive Learning', 'Self-Optimization'],
      gradient: 'from-blue-500 to-cyan-500',
    },
    {
      icon: Workflow,
      title: 'End-to-End Workflow Automation',
      description: 'Automate complete business processes from initiation to completion with intelligent agents that handle exceptions and edge cases autonomously.',
      features: ['Process Orchestration', 'Exception Handling', 'Dynamic Routing'],
      gradient: 'from-purple-500 to-pink-500',
    },
    {
      icon: Network,
      title: 'Multi-Agent Collaboration',
      description: 'Enable multiple AI agents to work together seamlessly, sharing knowledge and coordinating actions to solve complex, multi-faceted challenges.',
      features: ['Agent Communication', 'Task Distribution', 'Collective Intelligence'],
      gradient: 'from-green-500 to-emerald-500',
    },
    {
      icon: Database,
      title: 'Intelligent Data Processing',
      description: 'Transform raw data into actionable insights with AI agents that understand context, identify patterns, and extract meaningful information.',
      features: ['Context Understanding', 'Pattern Recognition', 'Insight Generation'],
      gradient: 'from-orange-500 to-red-500',
    },
    {
      icon: Target,
      title: 'Goal-Oriented Execution',
      description: 'Set high-level objectives and let AI agents break them down into actionable sub-tasks, executing with precision and measuring outcomes.',
      features: ['Objective Decomposition', 'Task Planning', 'Performance Tracking'],
      gradient: 'from-yellow-500 to-orange-500',
    },
    {
      icon: LineChart,
      title: 'Continuous Improvement',
      description: 'AI agents that learn from every interaction, continuously refining their strategies and improving performance over time.',
      features: ['Experience Learning', 'Strategy Refinement', 'Performance Optimization'],
      gradient: 'from-indigo-500 to-purple-500',
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5
      }
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h1 className="text-4xl sm:text-5xl mb-4 text-transparent bg-clip-text bg-gradient-to-r from-orange-600 to-red-600">
            AuRA AI Solutions
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Unlock unprecedented levels of efficiency and innovation with autonomous AI systems 
            that understand, reason, plan, and execute complex tasks with minimal human intervention
          </p>
        </motion.div>

        {/* Solutions Grid */}
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {solutions.map((solution) => {
            const Icon = solution.icon;
            return (
              <motion.div key={solution.title} variants={cardVariants}>
                <Card className="h-full hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 border-2 border-transparent hover:border-orange-200 group overflow-hidden relative">
                  <div className={`absolute inset-0 bg-gradient-to-br ${solution.gradient} opacity-0 group-hover:opacity-5 transition-opacity duration-300`} />
                  <CardHeader className="relative">
                    <motion.div 
                      className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${solution.gradient} flex items-center justify-center mb-4`}
                      whileHover={{ rotate: 360, scale: 1.1 }}
                      transition={{ duration: 0.6 }}
                    >
                      <Icon className="w-8 h-8 text-white" />
                    </motion.div>
                    <CardTitle className="text-xl">{solution.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="relative space-y-4">
                    <p className="text-gray-600">{solution.description}</p>
                    <div className="space-y-2">
                      {solution.features.map((feature) => (
                        <div key={feature} className="flex items-center gap-2 text-sm">
                          <div className={`w-2 h-2 rounded-full bg-gradient-to-r ${solution.gradient}`} />
                          <span className="text-gray-700">{feature}</span>
                        </div>
                      ))}
                    </div>
                    <Button 
                      onClick={() => onNavigate('Learn More')}
                      className={`w-full bg-gradient-to-r ${solution.gradient} hover:opacity-90 mt-4`}
                    >
                      Learn More
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </motion.div>

        {/* CTA Section */}
        <motion.div 
          className="bg-gradient-to-r from-orange-600 to-red-600 rounded-2xl text-white p-8 sm:p-12 text-center shadow-2xl"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl sm:text-4xl mb-4">Ready to Transform Your Operations?</h2>
          <p className="text-lg text-orange-100 max-w-2xl mx-auto mb-6">
            Discover how AuRA AI's autonomous agents can enhance decision-making and unlock new levels of efficiency for your organization
          </p>
          <motion.button
            onClick={() => onNavigate('Get Started')}
            className="bg-white text-orange-600 px-8 py-3 rounded-lg hover:shadow-xl transition-shadow"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Get Started Today
          </motion.button>
        </motion.div>
      </div>
      
      <Footer />
    </div>
  );
}
