import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Footer } from '../Footer';
import { motion } from 'motion/react';
import { 
  MessageSquare, Brain, Mic, Languages, Users, 
  Zap, Clock, CheckCircle2, ArrowRight, Sparkles, Bot
} from 'lucide-react';

interface ConversationAIPageProps {
  onNavigate: (page: string) => void;
}

export function ConversationAIPage({ onNavigate }: ConversationAIPageProps) {
  const features = [
    {
      icon: Brain,
      title: 'Natural Language Understanding',
      description: 'Advanced NLP that understands context, intent, and sentiment in human language with high accuracy.',
      capabilities: ['Intent Recognition', 'Entity Extraction', 'Sentiment Analysis', 'Context Preservation'],
      gradient: 'from-blue-500 to-cyan-500'
    },
    {
      icon: MessageSquare,
      title: 'Multi-Turn Conversations',
      description: 'Maintain context across multiple exchanges, creating natural, flowing conversations that feel human.',
      capabilities: ['Context Awareness', 'Conversation Memory', 'Topic Tracking', 'Personalization'],
      gradient: 'from-purple-500 to-pink-500'
    },
    {
      icon: Languages,
      title: 'Multilingual Support',
      description: 'Communicate in 100+ languages with native-level fluency and cultural awareness.',
      capabilities: ['100+ Languages', 'Auto-Detection', 'Cultural Adaptation', 'Real-time Translation'],
      gradient: 'from-green-500 to-emerald-500'
    },
    {
      icon: Mic,
      title: 'Voice Integration',
      description: 'Natural voice interactions with advanced speech recognition and text-to-speech capabilities.',
      capabilities: ['Speech Recognition', 'Voice Synthesis', 'Accent Adaptation', 'Noise Cancellation'],
      gradient: 'from-orange-500 to-red-500'
    },
  ];

  const useCases = [
    {
      title: 'Customer Support',
      description: '24/7 automated support that handles inquiries, resolves issues, and escalates when needed',
      icon: Users,
      stats: ['90% First Contact Resolution', '24/7 Availability', '5s Avg Response Time'],
      gradient: 'from-blue-500 to-cyan-500'
    },
    {
      title: 'Virtual Assistants',
      description: 'AI assistants that help users navigate platforms, complete tasks, and find information',
      icon: Bot,
      stats: ['Natural Interactions', 'Task Automation', 'Contextual Help'],
      gradient: 'from-purple-500 to-pink-500'
    },
    {
      title: 'Sales & Marketing',
      description: 'Engage prospects, qualify leads, and provide personalized product recommendations',
      icon: Zap,
      stats: ['Lead Qualification', 'Personalization', 'Product Recommendations'],
      gradient: 'from-green-500 to-emerald-500'
    },
    {
      title: 'Internal Operations',
      description: 'Help employees with HR queries, IT support, and internal process navigation',
      icon: Clock,
      stats: ['Employee Self-Service', 'Process Guidance', 'Knowledge Access'],
      gradient: 'from-orange-500 to-red-500'
    },
  ];

  const capabilities = [
    'Natural language understanding',
    'Multi-turn conversations',
    'Sentiment analysis',
    'Intent recognition',
    'Entity extraction',
    'Context preservation',
    '100+ languages',
    'Voice integration',
    'Customizable personas',
    'Integration APIs',
    'Analytics & insights',
    'Continuous learning'
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 via-teal-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <motion.div
            className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-r from-green-600 to-teal-600 mb-6"
            animate={{
              scale: [1, 1.05, 1],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            <MessageSquare className="w-10 h-10 text-white" />
          </motion.div>
          <h1 className="text-4xl sm:text-5xl mb-4 text-transparent bg-clip-text bg-gradient-to-r from-green-600 to-teal-600">
            Conversational AI
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Build natural, intelligent conversations with AI that understands context, intent, and sentiment. 
            Engage users across text and voice channels with human-like interactions.
          </p>
        </motion.div>

        {/* Core Features */}
        <div className="mb-16">
          <h2 className="text-3xl text-center mb-12 text-gray-800">Core Features</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="h-full hover:shadow-2xl transition-all duration-300 hover:-translate-y-2">
                    <CardHeader>
                      <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${feature.gradient} flex items-center justify-center mb-4`}>
                        <Icon className="w-7 h-7 text-white" />
                      </div>
                      <CardTitle className="text-xl mb-2">{feature.title}</CardTitle>
                      <CardDescription>{feature.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 gap-2">
                        {feature.capabilities.map((capability) => (
                          <div key={capability} className="flex items-start gap-1 text-sm">
                            <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                            <span className="text-gray-700">{capability}</span>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Use Cases */}
        <div className="mb-16">
          <h2 className="text-3xl text-center mb-12 text-gray-800">Use Cases</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {useCases.map((useCase, index) => {
              const Icon = useCase.icon;
              return (
                <motion.div
                  key={useCase.title}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="h-full hover:shadow-xl transition-shadow">
                    <CardHeader>
                      <div className="flex items-start justify-between mb-4">
                        <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${useCase.gradient} flex items-center justify-center`}>
                          <Icon className="w-6 h-6 text-white" />
                        </div>
                      </div>
                      <CardTitle className="text-xl mb-2">{useCase.title}</CardTitle>
                      <CardDescription>{useCase.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        {useCase.stats.map((stat) => (
                          <Badge key={stat} variant="secondary" className="mr-2">
                            {stat}
                          </Badge>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Capabilities Grid */}
        <div className="mb-16">
          <h2 className="text-3xl text-center mb-12 text-gray-800">Full Capabilities</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {capabilities.map((capability, index) => (
              <motion.div
                key={capability}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <Card className="text-center hover:shadow-lg transition-shadow p-4">
                  <CheckCircle2 className="w-6 h-6 text-green-600 mx-auto mb-2" />
                  <p className="text-sm text-gray-700">{capability}</p>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Try Ella Bot Section */}
        <motion.div
          className="bg-gradient-to-r from-pink-50 to-purple-50 rounded-2xl p-8 mb-16 border-2 border-pink-200"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
        >
          <div className="flex flex-col md:flex-row items-center gap-8">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-4">
                <Bot className="w-8 h-8 text-pink-600" />
                <h3 className="text-2xl">Meet Ella Bot</h3>
              </div>
              <p className="text-gray-700 mb-4">
                Experience our Conversational AI in action! Ella Bot is powered by the same technology 
                and can answer questions about AuRA AI Platform, help you navigate features, and provide 
                instant support.
              </p>
              <Button 
                onClick={() => onNavigate('Ella Bot')}
                className="bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-700 hover:to-purple-700"
              >
                <Sparkles className="w-4 h-4 mr-2" />
                Chat with Ella Bot
              </Button>
            </div>
            <div className="bg-white rounded-lg p-6 shadow-lg max-w-sm">
              <div className="flex items-start gap-3 mb-4">
                <div className="w-10 h-10 rounded-full bg-gradient-to-r from-pink-600 to-purple-600 flex items-center justify-center flex-shrink-0">
                  <Bot className="w-6 h-6 text-white" />
                </div>
                <div className="bg-gray-100 rounded-2xl rounded-tl-none p-3 flex-1">
                  <p className="text-sm text-gray-800">
                    Hi! I'm Ella Bot. I can help you with information about our AI agents, 
                    pricing, integrations, and more. What would you like to know?
                  </p>
                </div>
              </div>
              <div className="text-right">
                <div className="inline-block bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-2xl rounded-tr-none p-3">
                  <p className="text-sm">Tell me about AI Agents</p>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
      
      <Footer />
    </div>
  );
}