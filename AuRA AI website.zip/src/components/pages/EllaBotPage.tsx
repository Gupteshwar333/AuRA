import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Send, 
  Bot, 
  User, 
  Plus, 
  Menu, 
  Search, 
  MoreVertical, 
  Copy, 
  ThumbsUp, 
  ThumbsDown, 
  RotateCw,
  Star,
  Trash2,
  Edit2,
  X,
  Paperclip,
  Zap,
  Settings,
  MessageSquare,
  Sparkles,
  FileText,
  ChevronLeft,
  ChevronRight,
  Moon,
  Sun,
  Home,
  LayoutDashboard,
  Mic,
  History,
  BookOpen,
  HelpCircle,
  LogOut,
  Clock
} from 'lucide-react';

interface Message {
  id: string;
  type: 'user' | 'bot';
  content: string;
  timestamp: Date;
  isThinking?: boolean;
}

interface Conversation {
  id: string;
  title: string;
  lastMessage: string;
  timestamp: Date;
  isPinned?: boolean;
  isStarred?: boolean;
}

export function EllaBotPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'bot',
      content: "Hello! I'm Ella, your AI assistant for TCS AuRA. I can help you with information about our AI agents, tools, and services. How can I assist you today?",
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isThinking, setIsThinking] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [conversations, setConversations] = useState<Conversation[]>([
    {
      id: '1',
      title: 'Getting Started with AuRA AI',
      lastMessage: 'Tell me about AI Agents',
      timestamp: new Date(Date.now() - 3600000),
      isPinned: true
    },
    {
      id: '2',
      title: 'Platform Integration',
      lastMessage: 'How do I integrate with my systems?',
      timestamp: new Date(Date.now() - 7200000),
    },
    {
      id: '3',
      title: 'Pricing and Plans',
      lastMessage: 'What are the pricing options?',
      timestamp: new Date(Date.now() - 86400000),
      isStarred: true
    }
  ]);
  const [currentConversationId, setCurrentConversationId] = useState('1');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isRightPanelOpen, setIsRightPanelOpen] = useState(false);
  const [hoveredMessageId, setHoveredMessageId] = useState<string | null>(null);
  const [selectedTool, setSelectedTool] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isLeftMenuOpen, setIsLeftMenuOpen] = useState(false);
  const [activeNavItem, setActiveNavItem] = useState('Chat');

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping, isThinking]);

  // Auto-close sidebar on mobile
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 768) {
        setIsSidebarOpen(false);
        setIsRightPanelOpen(false);
        setIsLeftMenuOpen(false);
      } else {
        setIsSidebarOpen(true);
      }
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const examplePrompts = [
    { icon: Sparkles, text: "What is AuRA AI Platform?", category: "Platform" },
    { icon: Bot, text: "Tell me about AI Agents", category: "Agents" },
    { icon: FileText, text: "Show me integration options", category: "Integration" },
    { icon: Zap, text: "Explain autonomous intelligence", category: "Features" }
  ];

  const tools = [
    { id: 'add-tool', name: 'Add Tool', icon: Plus },
    { id: 'list-tool', name: 'List Tool', icon: FileText },
    { id: 'analyze', name: 'Analyze Data', icon: Zap },
    { id: 'docs', name: 'Documentation', icon: FileText }
  ];

  const navItems = [
    { id: 'home', name: 'Home', icon: Home },
    { id: 'dashboard', name: 'Dashboard', icon: LayoutDashboard },
    { id: 'chat', name: 'Chat', icon: MessageSquare },
    { id: 'voice', name: 'Voice', icon: Mic },
    { id: 'ella-bot', name: 'Ella bot', icon: Bot }
  ];

  const leftMenuItems = [
    { id: 'new-chat', name: 'New Chat', icon: Plus, action: 'primary' },
    { id: 'history', name: 'Chat History', icon: History, section: 'main' },
    { id: 'favorites', name: 'Favorites', icon: Star, section: 'main' },
    { id: 'recent', name: 'Recent Chats', icon: Clock, section: 'main' },
    { id: 'divider-1', type: 'divider' },
    { id: 'tools', name: 'AI Tools', icon: Zap, section: 'tools' },
    { id: 'docs', name: 'Documentation', icon: BookOpen, section: 'tools' },
    { id: 'divider-2', type: 'divider' },
    { id: 'settings', name: 'Settings', icon: Settings, section: 'bottom' },
    { id: 'help', name: 'Help & Support', icon: HelpCircle, section: 'bottom' }
  ];

  const getBotResponse = (userMessage: string): string => {
    const lowerMessage = userMessage.toLowerCase();
    
    if (lowerMessage.includes('aura') || lowerMessage.includes('platform')) {
      return "AuRA AI Platform represents the next evolution in artificial intelligence. It's a proactive, autonomous system capable of understanding, reasoning, planning, and executing complex tasks with minimal human intervention. Our goal-oriented AI agents can break down objectives into sub-tasks, make independent decisions, and collaborate with other AI agents and humans.";
    }
    
    if (lowerMessage.includes('agent') || lowerMessage.includes('ai agent')) {
      return "We offer 7 specialized AI Agents:\n\n1. **Transition Agent** - Manages complex state transitions\n2. **SOP Agent** - Automates standard operating procedures\n3. **Conversational Agent** - Natural dialogue interactions\n4. **RAG Agent** - Retrieval-Augmented Generation\n5. **Workflow Builder** - Designs optimal workflows\n6. **DevOps Agent** - Manages deployments and infrastructure\n7. **Analytics Agent** - Autonomous data analysis\n\nEach agent is autonomous, adaptive, and continuously learning!";
    }
    
    if (lowerMessage.includes('benefit') || lowerMessage.includes('advantage')) {
      return "Key Business Benefits:\n\n⚡ **Efficiency** - Automate end-to-end workflows\n🎯 **Decision-Making** - Data-driven autonomous analysis\n📈 **Scalability** - Scale without proportional resource increase\n💡 **Innovation** - AI-driven insights and automation\n💰 **Cost Reduction** - Intelligent automation reduces costs\n🚀 **Speed** - 24/7 autonomous operations\n🎨 **Flexibility** - Adapt quickly to changes\n🛡️ **Reliability** - Continuous learning and improvement";
    }
    
    if (lowerMessage.includes('price') || lowerMessage.includes('cost') || lowerMessage.includes('pricing')) {
      return "We offer flexible pricing plans:\n\n• **Free Trial** - 14 days with full access\n• **Starter** - Perfect for small teams\n• **Professional** - For growing businesses\n• **Enterprise** - Custom solutions for large organizations\n\nAll plans include autonomous AI agents, 24/7 support, and continuous learning capabilities. Contact us for detailed pricing!";
    }
    
    if (lowerMessage.includes('integration') || lowerMessage.includes('integrate')) {
      return "AuRA AI integrates seamlessly with 100+ platforms:\n\n✓ Cloud platforms (AWS, Azure, GCP)\n✓ CRM systems (Salesforce, HubSpot)\n✓ Communication tools (Slack, Teams)\n✓ Databases (PostgreSQL, MongoDB)\n✓ Analytics platforms (Tableau, PowerBI)\n✓ Custom APIs and webhooks\n\nOur agents can collaborate with your existing tools to create intelligent, automated workflows!";
    }
    
    if (lowerMessage.includes('autonomous') || lowerMessage.includes('intelligence')) {
      return "Autonomous Intelligence means our AI agents:\n\n🧠 **Understand Context** - Comprehend complex scenarios\n💭 **Reason & Plan** - Develop optimal strategies\n⚡ **Make Decisions** - Act independently with confidence\n🔄 **Adapt** - Adjust to changing conditions in real-time\n📚 **Learn Continuously** - Improve from every interaction\n🤝 **Collaborate** - Work with other agents and humans\n\nThey don't just react - they proactively solve problems!";
    }
    
    if (lowerMessage.includes('help') || lowerMessage.includes('support')) {
      return "I'm here to help! You can ask me about:\n\n• AuRA AI Platform features\n• AI Agent capabilities\n• Business benefits and use cases\n• Pricing and plans\n• Integration options\n• Technical documentation\n• Getting started guide\n\nJust type your question, and I'll provide detailed information!";
    }
    
    if (lowerMessage.includes('thank') || lowerMessage.includes('thanks')) {
      return "You're welcome! 😊 I'm always here to help you explore the power of autonomous AI. Feel free to ask anything else about AuRA AI Platform!";
    }
    
    return "That's a great question! Let me help you with that. AuRA AI Platform offers autonomous, goal-oriented AI agents that can transform your workflows. Could you be more specific about what aspect you'd like to know more about? For example, you can ask about our AI agents, business benefits, pricing, or integration options.";
  };

  const handleSend = () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    
    // Close mobile menu after sending
    if (window.innerWidth < 768) {
      setIsMobileMenuOpen(false);
    }
    
    setIsThinking(true);
    
    setTimeout(() => {
      setIsThinking(false);
      setIsTyping(true);
      
      setTimeout(() => {
        const botResponse: Message = {
          id: (Date.now() + 1).toString(),
          type: 'bot',
          content: getBotResponse(userMessage.content),
          timestamp: new Date()
        };
        setMessages(prev => [...prev, botResponse]);
        setIsTyping(false);
      }, 1500);
    }, 2000);
  };

  const handleExamplePrompt = (text: string) => {
    setInput(text);
    setTimeout(() => handleSend(), 100);
  };

  const copyMessage = (content: string) => {
    navigator.clipboard.writeText(content);
  };

  const regenerateResponse = () => {
    if (messages.length > 0) {
      const lastUserMessage = [...messages].reverse().find(m => m.type === 'user');
      if (lastUserMessage) {
        setInput(lastUserMessage.content);
        setTimeout(() => handleSend(), 100);
      }
    }
  };

  const renderMessageContent = (content: string) => {
    const lines = content.split('\n');
    return lines.map((line, i) => {
      if (line.startsWith('**') && line.includes('**')) {
        const boldText = line.match(/\*\*(.*?)\*\*/g);
        if (boldText) {
          let processedLine = line;
          boldText.forEach(bold => {
            const text = bold.replace(/\*\*/g, '');
            processedLine = processedLine.replace(bold, `<strong class="font-semibold">${text}</strong>`);
          });
          return <p key={i} className="mb-2" dangerouslySetInnerHTML={{ __html: processedLine }} />;
        }
      }
      if (line.match(/^[•✓⚡🎯📈💡💰🚀🎨🛡️🧠💭🔄📚🤝]/)) {
        return <p key={i} className="mb-2 pl-2">{line}</p>;
      }
      if (line.match(/^\d+\./)) {
        return <p key={i} className="mb-2 pl-2">{line}</p>;
      }
      return line ? <p key={i} className="mb-2">{line}</p> : <br key={i} />;
    });
  };

  return (
    <div className={`h-screen flex flex-col overflow-hidden ${isDarkMode ? 'bg-gray-900' : 'bg-white'}`}>
      {/* Top Navigation Bar */}
      <div className={`h-16 ${isDarkMode ? 'bg-gray-950 border-gray-800' : 'bg-white border-gray-200'} border-b flex items-center px-4 md:px-6 sticky top-0 z-30`}>
        <div className="flex items-center justify-between w-full">
          {/* Left: Logo & Menu Toggle */}
          <div className="flex items-center gap-4">
            <button
              onClick={() => setIsLeftMenuOpen(!isLeftMenuOpen)}
              className={`p-2 ${isDarkMode ? 'hover:bg-gray-800' : 'hover:bg-gray-100'} rounded-lg transition-colors`}
            >
              <Menu className={`w-5 h-5 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`} />
            </button>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-sky-500 to-blue-600 rounded-lg flex items-center justify-center">
                <Bot className="w-5 h-5 text-white" />
              </div>
              <span className={`text-lg font-semibold ${isDarkMode ? 'text-white' : 'text-[#000080]'} hidden sm:inline`}>
                Ella Bot
              </span>
            </div>
          </div>

          {/* Center: Navigation Items */}
          <div className="hidden md:flex items-center gap-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeNavItem === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveNavItem(item.id)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-all flex items-center gap-2 ${
                    isActive
                      ? isDarkMode
                        ? 'bg-sky-500/20 text-sky-400'
                        : 'bg-sky-50 text-sky-600'
                      : isDarkMode
                      ? 'text-gray-400 hover:bg-gray-800 hover:text-gray-200'
                      : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.name}</span>
                </button>
              );
            })}
          </div>

          {/* Right: Theme Toggle */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsDarkMode(!isDarkMode)}
              className={`p-2 ${isDarkMode ? 'hover:bg-gray-800 text-yellow-400' : 'hover:bg-gray-100 text-gray-700'} rounded-lg transition-colors`}
            >
              {isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Main Container */}
      <div className="flex flex-1 overflow-hidden relative">
        {/* Left Vertical Slide Menu */}
        <AnimatePresence>
          {isLeftMenuOpen && (
            <>
              {/* Overlay for mobile */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setIsLeftMenuOpen(false)}
                className="fixed inset-0 bg-black/50 z-40 md:hidden"
              />
              
              {/* Menu */}
              <motion.div
                initial={{ x: -300, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                exit={{ x: -300, opacity: 0 }}
                transition={{ duration: 0.3, ease: "easeInOut" }}
                className={`fixed md:sticky left-0 top-16 bottom-0 w-[280px] ${
                  isDarkMode ? 'bg-gray-950 border-gray-800' : 'bg-gray-50 border-gray-200'
                } border-r z-50 flex flex-col`}
              >
                {/* Menu Header */}
                <div className={`p-4 ${isDarkMode ? 'border-gray-800' : 'border-gray-200'} border-b`}>
                  <h3 className={`text-xs font-semibold ${isDarkMode ? 'text-gray-500' : 'text-gray-500'} uppercase tracking-wide mb-3`}>
                    Quick Actions
                  </h3>
                  <button
                    onClick={() => {
                      setMessages([{
                        id: Date.now().toString(),
                        type: 'bot',
                        content: "Hello! I'm Ella, your AI assistant for AuRA AI Platform. How can I assist you today?",
                        timestamp: new Date()
                      }]);
                      setIsLeftMenuOpen(false);
                    }}
                    className={`w-full px-4 py-3 ${
                      isDarkMode ? 'bg-sky-500 hover:bg-sky-600' : 'bg-sky-500 hover:bg-sky-600'
                    } text-white rounded-lg transition-colors flex items-center justify-center gap-2 text-sm font-medium shadow-lg shadow-sky-500/20`}
                  >
                    <Plus className="w-4 h-4" />
                    New Chat
                  </button>
                </div>

                {/* Menu Items */}
                <div className="flex-1 overflow-y-auto py-2">
                  <div className="px-3 space-y-1">
                    {leftMenuItems.map((item) => {
                      if (item.type === 'divider') {
                        return (
                          <div
                            key={item.id}
                            className={`my-2 border-t ${isDarkMode ? 'border-gray-800' : 'border-gray-200'}`}
                          />
                        );
                      }

                      if (item.action === 'primary') return null; // Already rendered in header

                      const Icon = item.icon;
                      return (
                        <button
                          key={item.id}
                          onClick={() => setIsLeftMenuOpen(false)}
                          className={`w-full px-3 py-2.5 rounded-lg text-sm ${
                            isDarkMode
                              ? 'text-gray-300 hover:bg-gray-800'
                              : 'text-gray-700 hover:bg-white'
                          } transition-colors flex items-center gap-3 group`}
                        >
                          <Icon className={`w-4 h-4 ${isDarkMode ? 'text-gray-500 group-hover:text-sky-400' : 'text-gray-400 group-hover:text-sky-500'} transition-colors`} />
                          <span>{item.name}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Menu Footer */}
                <div className={`p-4 ${isDarkMode ? 'border-gray-800' : 'border-gray-200'} border-t`}>
                  <div className={`px-3 py-2 rounded-lg ${isDarkMode ? 'bg-gray-900/50' : 'bg-white'} text-xs`}>
                    <p className={`${isDarkMode ? 'text-gray-400' : 'text-gray-600'} mb-1`}>
                      Ella Bot AI Assistant
                    </p>
                    <p className={`${isDarkMode ? 'text-gray-600' : 'text-gray-400'}`}>
                      Version 2.0
                    </p>
                  </div>
                </div>
              </motion.div>
            </>
          )}
        </AnimatePresence>

        {/* Conversations Sidebar - Desktop */}
        <AnimatePresence>
          {isSidebarOpen && (
            <motion.div
              initial={{ x: -280, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -280, opacity: 0 }}
              transition={{ duration: 0.2 }}
              className={`hidden md:flex w-[280px] ${isDarkMode ? 'bg-gray-900 border-gray-800' : 'bg-white border-gray-200'} border-r flex-col`}
            >
              {/* Sidebar Header */}
              <div className={`p-4 ${isDarkMode ? 'border-gray-800' : 'border-gray-200'} border-b`}>
                <button
                  onClick={() => {
                    setMessages([{
                      id: Date.now().toString(),
                      type: 'bot',
                      content: "Hello! I'm Ella, your AI assistant for AuRA AI Platform. How can I assist you today?",
                      timestamp: new Date()
                    }]);
                  }}
                  className={`w-full px-4 py-3 ${isDarkMode ? 'bg-white text-black hover:bg-gray-100' : 'bg-black text-white hover:bg-gray-800'} rounded-lg transition-colors flex items-center justify-center gap-2 text-sm font-medium`}
                >
                  <Plus className="w-4 h-4" />
                  New Chat
                </button>
              </div>

              {/* Search */}
              <div className={`px-4 py-3 ${isDarkMode ? 'border-gray-800' : 'border-gray-200'} border-b`}>
                <div className="relative">
                  <Search className={`absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 ${isDarkMode ? 'text-gray-500' : 'text-gray-400'}`} />
                  <input
                    type="text"
                    placeholder="Search conversations..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className={`w-full pl-9 pr-3 py-2 ${isDarkMode ? 'bg-gray-800 border-gray-700 text-white placeholder:text-gray-500' : 'bg-gray-50 border-gray-200 text-black placeholder:text-gray-400'} border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-transparent`}
                  />
                </div>
              </div>

              {/* Conversations List */}
              <div className="flex-1 overflow-y-auto">
                {/* Pinned Section */}
                <div className="p-2">
                  <div className={`px-3 py-2 text-xs font-semibold ${isDarkMode ? 'text-gray-500' : 'text-gray-500'} uppercase tracking-wide`}>
                    Pinned
                  </div>
                  {conversations.filter(c => c.isPinned).map(conv => (
                    <button
                      key={conv.id}
                      onClick={() => setCurrentConversationId(conv.id)}
                      className={`w-full text-left px-3 py-3 rounded-lg mb-1 group transition-colors ${
                        currentConversationId === conv.id 
                          ? isDarkMode ? 'bg-gray-800' : 'bg-gray-100'
                          : isDarkMode ? 'hover:bg-gray-800' : 'hover:bg-gray-50'
                      }`}
                    >
                      <div className="flex items-start gap-2">
                        <MessageSquare className={`w-4 h-4 ${isDarkMode ? 'text-gray-500' : 'text-gray-400'} mt-0.5 flex-shrink-0`} />
                        <div className="flex-1 min-w-0">
                          <div className={`text-sm font-medium ${isDarkMode ? 'text-white' : 'text-black'} truncate`}>
                            {conv.title}
                          </div>
                          <div className={`text-xs ${isDarkMode ? 'text-gray-500' : 'text-gray-500'} truncate mt-0.5`}>
                            {conv.lastMessage}
                          </div>
                        </div>
                        <Star className="w-3 h-3 text-sky-500 fill-sky-500 flex-shrink-0" />
                      </div>
                    </button>
                  ))}
                </div>

                {/* Recent Section */}
                <div className="p-2">
                  <div className={`px-3 py-2 text-xs font-semibold ${isDarkMode ? 'text-gray-500' : 'text-gray-500'} uppercase tracking-wide`}>
                    Recent
                  </div>
                  {conversations.filter(c => !c.isPinned).map(conv => (
                    <button
                      key={conv.id}
                      onClick={() => setCurrentConversationId(conv.id)}
                      className={`w-full text-left px-3 py-3 rounded-lg mb-1 group transition-colors ${
                        currentConversationId === conv.id 
                          ? isDarkMode ? 'bg-gray-800' : 'bg-gray-100'
                          : isDarkMode ? 'hover:bg-gray-800' : 'hover:bg-gray-50'
                      }`}
                    >
                      <div className="flex items-start gap-2">
                        <MessageSquare className={`w-4 h-4 ${isDarkMode ? 'text-gray-500' : 'text-gray-400'} mt-0.5 flex-shrink-0`} />
                        <div className="flex-1 min-w-0">
                          <div className={`text-sm font-medium ${isDarkMode ? 'text-white' : 'text-black'} truncate`}>
                            {conv.title}
                          </div>
                          <div className={`text-xs ${isDarkMode ? 'text-gray-500' : 'text-gray-500'} truncate mt-0.5`}>
                            {conv.lastMessage}
                          </div>
                        </div>
                        {conv.isStarred && (
                          <Star className="w-3 h-3 text-sky-500 flex-shrink-0" />
                        )}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Sidebar Footer */}
              <div className={`p-4 ${isDarkMode ? 'border-gray-800' : 'border-gray-200'} border-t`}>
                <button className={`w-full px-3 py-2 text-sm ${isDarkMode ? 'text-gray-400 hover:bg-gray-800' : 'text-gray-600 hover:bg-gray-50'} rounded-lg transition-colors flex items-center gap-2`}>
                  <Settings className="w-4 h-4" />
                  Settings
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Mobile Sidebar Overlay */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <>
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setIsMobileMenuOpen(false)}
                className="fixed inset-0 bg-black/50 z-40 md:hidden"
              />
              <motion.div
                initial={{ x: -280 }}
                animate={{ x: 0 }}
                exit={{ x: -280 }}
                transition={{ duration: 0.2 }}
                className={`fixed left-0 top-16 bottom-0 w-[280px] ${isDarkMode ? 'bg-gray-900' : 'bg-white'} z-50 flex flex-col md:hidden`}
              >
                {/* Mobile Sidebar Header */}
                <div className={`p-4 ${isDarkMode ? 'border-gray-800' : 'border-gray-200'} border-b flex items-center justify-between`}>
                  <h2 className={`text-lg font-semibold ${isDarkMode ? 'text-white' : 'text-black'}`}>Conversations</h2>
                  <button
                    onClick={() => setIsMobileMenuOpen(false)}
                    className={`p-2 ${isDarkMode ? 'hover:bg-gray-800' : 'hover:bg-gray-100'} rounded-lg transition-colors`}
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* New Chat Button */}
                <div className="p-4">
                  <button
                    onClick={() => {
                      setMessages([{
                        id: Date.now().toString(),
                        type: 'bot',
                        content: "Hello! I'm Ella, your AI assistant for AuRA AI Platform. How can I assist you today?",
                        timestamp: new Date()
                      }]);
                      setIsMobileMenuOpen(false);
                    }}
                    className={`w-full px-4 py-3 ${isDarkMode ? 'bg-white text-black' : 'bg-black text-white'} rounded-lg transition-colors flex items-center justify-center gap-2 text-sm font-medium`}
                  >
                    <Plus className="w-4 h-4" />
                    New Chat
                  </button>
                </div>

                {/* Search */}
                <div className={`px-4 pb-3 ${isDarkMode ? 'border-gray-800' : 'border-gray-200'} border-b`}>
                  <div className="relative">
                    <Search className={`absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 ${isDarkMode ? 'text-gray-500' : 'text-gray-400'}`} />
                    <input
                      type="text"
                      placeholder="Search..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className={`w-full pl-9 pr-3 py-2 ${isDarkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-gray-50 border-gray-200'} border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-sky-500`}
                    />
                  </div>
                </div>

                {/* Conversations List */}
                <div className="flex-1 overflow-y-auto p-2">
                  {conversations.map(conv => (
                    <button
                      key={conv.id}
                      onClick={() => {
                        setCurrentConversationId(conv.id);
                        setIsMobileMenuOpen(false);
                      }}
                      className={`w-full text-left px-3 py-3 rounded-lg mb-1 transition-colors ${
                        currentConversationId === conv.id 
                          ? isDarkMode ? 'bg-gray-800' : 'bg-gray-100'
                          : isDarkMode ? 'hover:bg-gray-800' : 'hover:bg-gray-50'
                      }`}
                    >
                      <div className="flex items-start gap-2">
                        <MessageSquare className={`w-4 h-4 ${isDarkMode ? 'text-gray-500' : 'text-gray-400'} mt-0.5`} />
                        <div className="flex-1 min-w-0">
                          <div className={`text-sm font-medium ${isDarkMode ? 'text-white' : 'text-black'} truncate`}>
                            {conv.title}
                          </div>
                          <div className={`text-xs ${isDarkMode ? 'text-gray-500' : 'text-gray-500'} truncate mt-0.5`}>
                            {conv.lastMessage}
                          </div>
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              </motion.div>
            </>
          )}
        </AnimatePresence>

        {/* Main Chat Area */}
        <div className={`flex-1 flex flex-col ${isDarkMode ? 'bg-gray-900' : 'bg-white'}`}>
          {/* Chat Header */}
          <div className={`h-16 ${isDarkMode ? 'border-gray-800' : 'border-gray-200'} border-b flex items-center justify-between px-4 md:px-6`}>
            <div className="flex items-center gap-3">
              {/* Mobile Menu Button */}
              <button
                onClick={() => setIsMobileMenuOpen(true)}
                className={`md:hidden p-2 ${isDarkMode ? 'hover:bg-gray-800' : 'hover:bg-gray-100'} rounded-lg transition-colors`}
              >
                <Menu className="w-5 h-5" />
              </button>
              
              {/* Desktop Sidebar Toggle */}
              {!isSidebarOpen && (
                <button
                  onClick={() => setIsSidebarOpen(true)}
                  className={`hidden md:block p-2 ${isDarkMode ? 'hover:bg-gray-800' : 'hover:bg-gray-100'} rounded-lg transition-colors`}
                >
                  <Menu className={`w-5 h-5 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`} />
                </button>
              )}
              {isSidebarOpen && (
                <button
                  onClick={() => setIsSidebarOpen(false)}
                  className={`hidden md:block p-2 ${isDarkMode ? 'hover:bg-gray-800' : 'hover:bg-gray-100'} rounded-lg transition-colors`}
                >
                  <ChevronLeft className={`w-5 h-5 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`} />
                </button>
              )}
              
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-sky-500 rounded-full flex items-center justify-center">
                  <Bot className="w-5 h-5 text-white" />
                </div>
                <div className="hidden sm:block">
                  <h2 className={`text-sm font-semibold ${isDarkMode ? 'text-white' : 'text-black'}`}>Ella Bot</h2>
                  <p className={`text-xs ${isDarkMode ? 'text-gray-500' : 'text-gray-500'}`}>AI Assistant</p>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {/* Right Panel Toggle - Desktop Only */}
              <button
                onClick={() => setIsRightPanelOpen(!isRightPanelOpen)}
                className={`hidden md:block p-2 ${isDarkMode ? 'hover:bg-gray-800' : 'hover:bg-gray-100'} rounded-lg transition-colors`}
              >
                <ChevronRight className={`w-5 h-5 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'} transition-transform ${isRightPanelOpen ? 'rotate-180' : ''}`} />
              </button>
            </div>
          </div>

          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto">
            {messages.length === 1 ? (
              /* Empty State */
              <div className="h-full flex flex-col items-center justify-center px-4 pb-32">
                <motion.div
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ duration: 0.5 }}
                  className="text-center max-w-2xl w-full"
                >
                  <div className="text-6xl mb-6">🤖</div>
                  <h1 className={`text-2xl md:text-3xl font-semibold ${isDarkMode ? 'text-white' : 'text-black'} mb-3`}>
                    Welcome to Ella Bot
                  </h1>
                  <p className={`${isDarkMode ? 'text-gray-400' : 'text-gray-600'} mb-8 text-sm md:text-base`}>
                    Your intelligent AI assistant for AuRA AI Platform. Start a conversation by selecting an example or typing your question.
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-8">
                    {examplePrompts.map((prompt, idx) => (
                      <motion.button
                        key={idx}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: idx * 0.1 }}
                        onClick={() => handleExamplePrompt(prompt.text)}
                        className={`p-4 ${isDarkMode ? 'bg-gray-800 border-gray-700 hover:border-sky-500' : 'bg-white border-gray-200 hover:border-sky-500'} border rounded-xl hover:shadow-md transition-all text-left group`}
                      >
                        <div className="flex items-start gap-3">
                          <div className={`w-8 h-8 ${isDarkMode ? 'bg-gray-700 group-hover:bg-gray-600' : 'bg-sky-50 group-hover:bg-sky-100'} rounded-lg flex items-center justify-center transition-colors`}>
                            <prompt.icon className="w-4 h-4 text-sky-500" />
                          </div>
                          <div className="flex-1">
                            <div className={`text-sm font-medium ${isDarkMode ? 'text-white' : 'text-black'} mb-1`}>
                              {prompt.text}
                            </div>
                            <div className={`text-xs ${isDarkMode ? 'text-gray-500' : 'text-gray-500'}`}>
                              {prompt.category}
                            </div>
                          </div>
                        </div>
                      </motion.button>
                    ))}
                  </div>
                </motion.div>
              </div>
            ) : (
              /* Messages */
              <div className="max-w-3xl mx-auto px-4 py-6 space-y-6">
                <AnimatePresence>
                  {messages.slice(1).map((message) => (
                    <motion.div
                      key={message.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      transition={{ duration: 0.3 }}
                      className={`flex gap-3 md:gap-4 ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                      onMouseEnter={() => setHoveredMessageId(message.id)}
                      onMouseLeave={() => setHoveredMessageId(null)}
                    >
                      <div className={`flex gap-3 max-w-[85%] md:max-w-[80%] ${message.type === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                        {/* Avatar */}
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                          message.type === 'user' 
                            ? 'bg-black' 
                            : 'bg-sky-500'
                        }`}>
                          {message.type === 'user' ? (
                            <User className="w-5 h-5 text-white" />
                          ) : (
                            <Bot className="w-5 h-5 text-white" />
                          )}
                        </div>

                        {/* Message Content */}
                        <div className="flex-1">
                          <div className={`rounded-xl px-4 py-3 ${
                            message.type === 'user'
                              ? 'bg-black text-white'
                              : isDarkMode
                              ? 'bg-gray-800 text-gray-100 border border-gray-700'
                              : 'bg-gray-50 text-gray-800 border border-gray-200'
                          }`}>
                            <div className="text-sm leading-relaxed">
                              {message.type === 'bot' ? renderMessageContent(message.content) : message.content}
                            </div>
                            <div className={`text-xs mt-2 ${
                              message.type === 'user' 
                                ? 'text-gray-400' 
                                : isDarkMode ? 'text-gray-500' : 'text-gray-500'
                            }`}>
                              {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </div>
                          </div>

                          {/* Message Actions */}
                          {message.type === 'bot' && hoveredMessageId === message.id && (
                            <motion.div
                              initial={{ opacity: 0, y: -10 }}
                              animate={{ opacity: 1, y: 0 }}
                              className="flex items-center gap-1 mt-2"
                            >
                              <button
                                onClick={() => copyMessage(message.content)}
                                className={`p-1.5 rounded-lg ${isDarkMode ? 'hover:bg-gray-800 text-gray-500' : 'hover:bg-gray-100 text-gray-600'} transition-colors`}
                                title="Copy"
                              >
                                <Copy className="w-4 h-4" />
                              </button>
                              <button
                                className={`p-1.5 rounded-lg ${isDarkMode ? 'hover:bg-gray-800 text-gray-500' : 'hover:bg-gray-100 text-gray-600'} transition-colors`}
                                title="Like"
                              >
                                <ThumbsUp className="w-4 h-4" />
                              </button>
                              <button
                                className={`p-1.5 rounded-lg ${isDarkMode ? 'hover:bg-gray-800 text-gray-500' : 'hover:bg-gray-100 text-gray-600'} transition-colors`}
                                title="Dislike"
                              >
                                <ThumbsDown className="w-4 h-4" />
                              </button>
                              <button
                                onClick={regenerateResponse}
                                className={`p-1.5 rounded-lg ${isDarkMode ? 'hover:bg-gray-800 text-gray-500' : 'hover:bg-gray-100 text-gray-600'} transition-colors`}
                                title="Regenerate"
                              >
                                <RotateCw className="w-4 h-4" />
                              </button>
                            </motion.div>
                          )}
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>

                {/* Thinking Animation */}
                {isThinking && (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex gap-3"
                  >
                    <div className="w-8 h-8 bg-sky-500 rounded-full flex items-center justify-center flex-shrink-0">
                      <Bot className="w-5 h-5 text-white" />
                    </div>
                    <div className={`${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'} border rounded-xl px-4 py-3`}>
                      <div className="flex items-center gap-2">
                        <div className={`w-2 h-2 rounded-full ${isDarkMode ? 'bg-sky-400' : 'bg-sky-500'} animate-pulse`} />
                        <div className={`w-2 h-2 rounded-full ${isDarkMode ? 'bg-sky-400' : 'bg-sky-500'} animate-pulse`} style={{ animationDelay: '0.2s' }} />
                        <div className={`w-2 h-2 rounded-full ${isDarkMode ? 'bg-sky-400' : 'bg-sky-500'} animate-pulse`} style={{ animationDelay: '0.4s' }} />
                        <span className={`ml-2 text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>Thinking...</span>
                      </div>
                    </div>
                  </motion.div>
                )}

                {/* Typing Animation */}
                {isTyping && (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex gap-3"
                  >
                    <div className="w-8 h-8 bg-sky-500 rounded-full flex items-center justify-center flex-shrink-0">
                      <Bot className="w-5 h-5 text-white" />
                    </div>
                    <div className={`${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'} border rounded-xl px-4 py-3`}>
                      <div className="flex items-center gap-1">
                        <div className={`w-2 h-2 rounded-full ${isDarkMode ? 'bg-sky-400' : 'bg-sky-500'} animate-bounce`} />
                        <div className={`w-2 h-2 rounded-full ${isDarkMode ? 'bg-sky-400' : 'bg-sky-500'} animate-bounce`} style={{ animationDelay: '0.1s' }} />
                        <div className={`w-2 h-2 rounded-full ${isDarkMode ? 'bg-sky-400' : 'bg-sky-500'} animate-bounce`} style={{ animationDelay: '0.2s' }} />
                      </div>
                    </div>
                  </motion.div>
                )}
                <div ref={messagesEndRef} />
              </div>
            )}
          </div>

          {/* Input Area */}
          <div className={`${isDarkMode ? 'bg-gray-900 border-gray-800' : 'bg-white border-gray-200'} border-t p-4`}>
            <div className="max-w-3xl mx-auto">
              <div className="flex gap-3 items-end">
                <button
                  className={`p-3 ${isDarkMode ? 'hover:bg-gray-800 text-gray-400' : 'hover:bg-gray-100 text-gray-600'} rounded-lg transition-colors`}
                  title="Attach file"
                >
                  <Paperclip className="w-5 h-5" />
                </button>
                <div className="flex-1">
                  <textarea
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyPress={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        handleSend();
                      }
                    }}
                    placeholder="Message Ella Bot..."
                    rows={1}
                    className={`w-full px-4 py-3 ${isDarkMode ? 'bg-gray-800 border-gray-700 text-white placeholder:text-gray-500' : 'bg-gray-50 border-gray-200 text-black placeholder:text-gray-400'} border rounded-xl resize-none focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-transparent transition-all`}
                    style={{ minHeight: '48px', maxHeight: '120px' }}
                  />
                </div>
                <button
                  onClick={handleSend}
                  disabled={!input.trim() || isTyping || isThinking}
                  className={`p-3 rounded-xl ${
                    !input.trim() || isTyping || isThinking
                      ? isDarkMode ? 'bg-gray-800 text-gray-600' : 'bg-gray-100 text-gray-400'
                      : 'bg-sky-500 text-white hover:bg-sky-600'
                  } transition-all disabled:cursor-not-allowed`}
                >
                  <Send className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Right Panel - Tools & Options */}
        <AnimatePresence>
          {isRightPanelOpen && (
            <motion.div
              initial={{ x: 280, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: 280, opacity: 0 }}
              transition={{ duration: 0.2 }}
              className={`hidden md:flex w-[280px] ${isDarkMode ? 'bg-gray-900 border-gray-800' : 'bg-white border-gray-200'} border-l flex-col`}
            >
              {/* Right Panel Header */}
              <div className={`p-4 ${isDarkMode ? 'border-gray-800' : 'border-gray-200'} border-b`}>
                <h3 className={`text-sm font-semibold ${isDarkMode ? 'text-white' : 'text-black'} mb-1`}>
                  AI Tools
                </h3>
                <p className={`text-xs ${isDarkMode ? 'text-gray-500' : 'text-gray-500'}`}>
                  Enhance your conversation
                </p>
              </div>

              {/* Tools List */}
              <div className="flex-1 overflow-y-auto p-4 space-y-2">
                {tools.map((tool) => {
                  const Icon = tool.icon;
                  return (
                    <button
                      key={tool.id}
                      onClick={() => setSelectedTool(tool.id)}
                      className={`w-full p-3 rounded-lg text-left transition-colors ${
                        selectedTool === tool.id
                          ? isDarkMode ? 'bg-sky-500/20 border-sky-500/50' : 'bg-sky-50 border-sky-200'
                          : isDarkMode ? 'bg-gray-800 border-gray-700 hover:bg-gray-750' : 'bg-gray-50 border-gray-200 hover:bg-gray-100'
                      } border`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                          selectedTool === tool.id
                            ? 'bg-sky-500 text-white'
                            : isDarkMode ? 'bg-gray-700 text-gray-400' : 'bg-white text-gray-600'
                        }`}>
                          <Icon className="w-4 h-4" />
                        </div>
                        <span className={`text-sm font-medium ${
                          selectedTool === tool.id
                            ? 'text-sky-500'
                            : isDarkMode ? 'text-white' : 'text-black'
                        }`}>
                          {tool.name}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}