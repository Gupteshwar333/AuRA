import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { RadioGroup, RadioGroupItem } from '../ui/radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Calendar } from '../ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '../ui/popover';
import { Footer } from '../Footer';
import { motion } from 'motion/react';
import { Bot, GitBranch, MessageSquare, Database, Workflow, Server, BarChart3, Sparkles, CheckCircle2, ArrowRight, Calendar as CalendarIcon, RotateCcw } from 'lucide-react';
import { useState } from 'react';
import { format } from 'date-fns';

interface AIAgentPageProps {
  onNavigate: (page: string) => void;
}

export function AIAgentPage({ onNavigate }: AIAgentPageProps) {
  const [showTransitionForm, setShowTransitionForm] = useState(false);
  const [formData, setFormData] = useState({
    rfpStage: '',
    rfpName: '',
    projectName: '',
    clientHeadquarters: '',
    region: '',
    segment: '',
    newLogo: '',
    customerType: '',
    projectType: '',
    sizeOfSupport: '',
    durationOfContract: '',
    tcvDealSize: '',
    businessGroup: '',
    isuGroup: '',
    firstTimeOutsourcing: '',
    competitors: '',
    coverage: '',
    regionOfScope: '',
    ddConduct: '',
    transitionType: '',
    transitionDuration: '',
    currentIncumbent: '',
    incumbentName: '',
    incumbentLocation: '',
    towersOrTech: '',
    bidOwner: '',
    presalesArchitect: '',
    deliveryHead: '',
    sdm: ''
  });

  const [contractStartDate, setContractStartDate] = useState<Date>();
  const [transitionStartDate, setTransitionStartDate] = useState<Date>();
  const [goLiveDate, setGoLiveDate] = useState<Date>();

  const agents = [
    {
      icon: GitBranch,
      name: 'Transition Agent',
      description: 'Intelligently manages complex state transitions and orchestrates multi-step processes. Adapts to changing conditions and ensures smooth workflow progression across systems.',
      capabilities: ['State Management', 'Process Orchestration', 'Adaptive Routing', 'Error Recovery'],
      useCases: ['Workflow automation', 'Multi-system coordination', 'Process optimization'],
      gradient: 'from-blue-500 to-cyan-500',
      badge: 'Popular',
      hasForm: true
    },
    {
      icon: FileDocument,
      name: 'SOP Agent',
      description: 'Automates standard operating procedures with context-aware execution. Learns from variations and exceptions to continuously improve process adherence and efficiency.',
      capabilities: ['Procedure Automation', 'Compliance Monitoring', 'Exception Learning', 'Process Documentation'],
      useCases: ['SOP enforcement', 'Compliance automation', 'Process standardization'],
      gradient: 'from-purple-500 to-pink-500',
      badge: 'New',
      hasForm: false
    },
    {
      icon: MessageSquare,
      name: 'Conversational Agent',
      description: 'Engages in natural, context-rich dialogues with users. Understands intent, maintains conversation history, and provides intelligent, goal-oriented responses.',
      capabilities: ['Natural Language Understanding', 'Context Awareness', 'Intent Recognition', 'Multi-turn Dialogue'],
      useCases: ['Customer support', 'Virtual assistance', 'Interactive guidance'],
      gradient: 'from-green-500 to-emerald-500',
      badge: null,
      hasForm: false
    },
    {
      icon: Database,
      name: 'RAG Agent',
      description: 'Retrieval-Augmented Generation agent that combines your knowledge base with generative AI. Delivers accurate, contextual answers grounded in your organization\'s data.',
      capabilities: ['Knowledge Retrieval', 'Context Generation', 'Source Citation', 'Accuracy Validation'],
      useCases: ['Knowledge management', 'Q&A systems', 'Documentation assistance'],
      gradient: 'from-orange-500 to-red-500',
      badge: 'Hot',
      hasForm: false
    },
    {
      icon: Workflow,
      name: 'Workflow Builder',
      description: 'Autonomously designs and optimizes workflows based on objectives. Breaks down complex goals into executable tasks and adapts workflows based on real-time feedback.',
      capabilities: ['Workflow Design', 'Task Decomposition', 'Dynamic Optimization', 'Performance Monitoring'],
      useCases: ['Process automation', 'Task management', 'Workflow optimization'],
      gradient: 'from-yellow-500 to-orange-500',
      badge: null,
      hasForm: false
    },
    {
      icon: Server,
      name: 'DevOps Agent',
      description: 'Manages deployment pipelines, infrastructure provisioning, and system monitoring. Makes intelligent decisions about scaling, optimization, and incident response.',
      capabilities: ['CI/CD Management', 'Infrastructure Automation', 'Incident Response', 'Performance Optimization'],
      useCases: ['DevOps automation', 'Infrastructure management', 'Deployment orchestration'],
      gradient: 'from-indigo-500 to-purple-500',
      badge: null,
      hasForm: false
    },
    {
      icon: BarChart3,
      name: 'Analytics Agent',
      description: 'Autonomously analyzes data patterns, generates insights, and recommends actions. Continuously learns which metrics matter most and adapts reporting accordingly.',
      capabilities: ['Pattern Recognition', 'Predictive Analytics', 'Automated Reporting', 'Insight Generation'],
      useCases: ['Business intelligence', 'Data analysis', 'Performance tracking'],
      gradient: 'from-pink-500 to-rose-500',
      badge: 'New',
      hasForm: false
    },
  ];

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleReset = () => {
    setFormData({
      rfpStage: '',
      rfpName: '',
      projectName: '',
      clientHeadquarters: '',
      region: '',
      segment: '',
      newLogo: '',
      customerType: '',
      projectType: '',
      sizeOfSupport: '',
      durationOfContract: '',
      tcvDealSize: '',
      businessGroup: '',
      isuGroup: '',
      firstTimeOutsourcing: '',
      competitors: '',
      coverage: '',
      regionOfScope: '',
      ddConduct: '',
      transitionType: '',
      transitionDuration: '',
      currentIncumbent: '',
      incumbentName: '',
      incumbentLocation: '',
      towersOrTech: '',
      bidOwner: '',
      presalesArchitect: '',
      deliveryHead: '',
      sdm: ''
    });
    setContractStartDate(undefined);
    setTransitionStartDate(undefined);
    setGoLiveDate(undefined);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form Data:', {
      ...formData,
      contractStartDate: contractStartDate ? format(contractStartDate, 'MM/dd/yyyy') : '',
      transitionStartDate: transitionStartDate ? format(transitionStartDate, 'MM/dd/yyyy') : '',
      goLiveDate: goLiveDate ? format(goLiveDate, 'MM/dd/yyyy') : ''
    });
    alert('Customer Onboarding Details Submitted Successfully!');
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-indigo-50 via-purple-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <motion.div
            className="inline-flex items-center justify-center mb-6"
            animate={{
              scale: [1, 1.05, 1],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            <div className="w-20 h-20 rounded-full bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 flex items-center justify-center shadow-2xl">
              <Bot className="w-10 h-10 text-white" />
            </div>
          </motion.div>

          <h1 className="text-4xl sm:text-5xl md:text-6xl mb-4 text-transparent bg-clip-text bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600">
            AI Agent Portfolio
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Autonomous agents that understand context, reason through problems, and execute complex tasks. 
            Each agent is goal-oriented, adaptive, and capable of collaborating with humans and other AI systems.
          </p>
        </motion.div>

        {/* Agents Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
          {agents.map((agent, index) => {
            const Icon = agent.icon;
            return (
              <motion.div
                key={agent.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="h-full hover:shadow-2xl transition-all duration-300 border-2 border-transparent hover:border-purple-200 group">
                  <CardHeader>
                    <div className="flex items-start justify-between mb-4">
                      <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${agent.gradient} flex items-center justify-center shadow-lg`}>
                        <Icon className="w-7 h-7 text-white" />
                      </div>
                      {agent.badge && (
                        <Badge className={`bg-gradient-to-r ${agent.gradient} text-white border-0`}>
                          {agent.badge}
                        </Badge>
                      )}
                    </div>
                    <CardTitle className="text-2xl mb-2">{agent.name}</CardTitle>
                    <CardDescription className="text-base">{agent.description}</CardDescription>
                  </CardHeader>
                  
                  <CardContent className="space-y-4">
                    <div>
                      <h4 className="text-sm uppercase tracking-wide text-gray-500 mb-2">Key Capabilities</h4>
                      <div className="grid grid-cols-2 gap-2">
                        {agent.capabilities.map((capability) => (
                          <div key={capability} className="flex items-start gap-1 text-sm">
                            <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                            <span className="text-gray-700">{capability}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    <div>
                      <h4 className="text-sm uppercase tracking-wide text-gray-500 mb-2">Use Cases</h4>
                      <div className="flex flex-wrap gap-2">
                        {agent.useCases.map((useCase) => (
                          <Badge key={useCase} variant="secondary" className="text-xs">
                            {useCase}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    {agent.hasForm ? (
                      <Button 
                        onClick={() => setShowTransitionForm(!showTransitionForm)}
                        className={`w-full bg-gradient-to-r ${agent.gradient} hover:opacity-90`}
                      >
                        {showTransitionForm ? 'Hide Onboarding Form' : 'Customer Onboarding Form'}
                        <ArrowRight className="w-4 h-4 ml-2" />
                      </Button>
                    ) : (
                      <Button 
                        onClick={() => onNavigate('Get Started')}
                        className={`w-full bg-gradient-to-r ${agent.gradient} hover:opacity-90`}
                      >
                        Deploy Agent
                        <ArrowRight className="w-4 h-4 ml-2" />
                      </Button>
                    )}
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {/* Customer Onboarding Form */}
        {showTransitionForm && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 0.5 }}
            className="mb-16"
          >
            <Card className="shadow-2xl border-2 border-blue-200 overflow-hidden">
              <CardHeader className="bg-gradient-to-r from-blue-600 to-cyan-600 text-white">
                <CardTitle className="text-3xl flex items-center gap-3">
                  <GitBranch className="w-8 h-8" />
                  Customer Onboarding Details - Transition Agent
                </CardTitle>
                <CardDescription className="text-blue-100">
                  Complete the form below to initiate the transition process
                </CardDescription>
              </CardHeader>
              <CardContent className="p-8 bg-gradient-to-b from-blue-50 to-white">
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Section 1: RFP & Project Details */}
                  <div className="bg-white p-6 rounded-lg shadow-sm border border-blue-100">
                    <h3 className="text-xl mb-4 text-blue-900 flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-sm">1</div>
                      RFP & Project Information
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="rfpStage">RFP Stage *</Label>
                        <Select value={formData.rfpStage} onValueChange={(value) => handleInputChange('rfpStage', value)}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select stage" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="discovery">Discovery</SelectItem>
                            <SelectItem value="proposal">Proposal</SelectItem>
                            <SelectItem value="negotiation">Negotiation</SelectItem>
                            <SelectItem value="awarded">Awarded</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="rfpName">RFP Name *</Label>
                        <Input
                          id="rfpName"
                          value={formData.rfpName}
                          onChange={(e) => handleInputChange('rfpName', e.target.value)}
                          placeholder="Enter RFP name"
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="projectName">Project Name *</Label>
                        <Input
                          id="projectName"
                          value={formData.projectName}
                          onChange={(e) => handleInputChange('projectName', e.target.value)}
                          placeholder="Enter project name"
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="clientHeadquarters">Client Headquarters *</Label>
                        <Input
                          id="clientHeadquarters"
                          value={formData.clientHeadquarters}
                          onChange={(e) => handleInputChange('clientHeadquarters', e.target.value)}
                          placeholder="Enter location"
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="region">Region *</Label>
                        <Select value={formData.region} onValueChange={(value) => handleInputChange('region', value)}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select region" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="north-america">North America</SelectItem>
                            <SelectItem value="europe">Europe</SelectItem>
                            <SelectItem value="asia-pacific">Asia Pacific</SelectItem>
                            <SelectItem value="latin-america">Latin America</SelectItem>
                            <SelectItem value="middle-east">Middle East</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="segment">Segment *</Label>
                        <Select value={formData.segment} onValueChange={(value) => handleInputChange('segment', value)}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select segment" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="enterprise">Enterprise</SelectItem>
                            <SelectItem value="mid-market">Mid-Market</SelectItem>
                            <SelectItem value="smb">SMB</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>

                  {/* Section 2: Customer & Deal Details */}
                  <div className="bg-white p-6 rounded-lg shadow-sm border border-blue-100">
                    <h3 className="text-xl mb-4 text-blue-900 flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-sm">2</div>
                      Customer & Deal Details
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      <div className="space-y-2">
                        <Label>New Logo *</Label>
                        <RadioGroup value={formData.newLogo} onValueChange={(value) => handleInputChange('newLogo', value)}>
                          <div className="flex items-center space-x-4">
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="yes" id="newLogo-yes" />
                              <Label htmlFor="newLogo-yes" className="cursor-pointer">Yes</Label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="no" id="newLogo-no" />
                              <Label htmlFor="newLogo-no" className="cursor-pointer">No</Label>
                            </div>
                          </div>
                        </RadioGroup>
                      </div>

                      <div className="space-y-2">
                        <Label>Customer Type *</Label>
                        <RadioGroup value={formData.customerType} onValueChange={(value) => handleInputChange('customerType', value)}>
                          <div className="flex items-center space-x-4">
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="existing" id="customerType-existing" />
                              <Label htmlFor="customerType-existing" className="cursor-pointer">Existing</Label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="new" id="customerType-new" />
                              <Label htmlFor="customerType-new" className="cursor-pointer">New</Label>
                            </div>
                          </div>
                        </RadioGroup>
                      </div>

                      <div className="space-y-2">
                        <Label>Project Type *</Label>
                        <RadioGroup value={formData.projectType} onValueChange={(value) => handleInputChange('projectType', value)}>
                          <div className="flex items-center space-x-4">
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="fixed" id="projectType-fixed" />
                              <Label htmlFor="projectType-fixed" className="cursor-pointer">Fixed</Label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="t&m" id="projectType-tm" />
                              <Label htmlFor="projectType-tm" className="cursor-pointer">T & M</Label>
                            </div>
                          </div>
                        </RadioGroup>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="sizeOfSupport">Size of Support (FTE) *</Label>
                        <Input
                          id="sizeOfSupport"
                          type="number"
                          value={formData.sizeOfSupport}
                          onChange={(e) => handleInputChange('sizeOfSupport', e.target.value)}
                          placeholder="Enter FTE count"
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="durationOfContract">Duration of Contract (Years) *</Label>
                        <Input
                          id="durationOfContract"
                          type="number"
                          step="0.5"
                          value={formData.durationOfContract}
                          onChange={(e) => handleInputChange('durationOfContract', e.target.value)}
                          placeholder="Enter duration"
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="tcvDealSize">TCV - Deal Size (USD) *</Label>
                        <Input
                          id="tcvDealSize"
                          type="number"
                          value={formData.tcvDealSize}
                          onChange={(e) => handleInputChange('tcvDealSize', e.target.value)}
                          placeholder="Enter amount"
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="businessGroup">Business Group *</Label>
                        <Input
                          id="businessGroup"
                          value={formData.businessGroup}
                          onChange={(e) => handleInputChange('businessGroup', e.target.value)}
                          placeholder="Enter business group"
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="isuGroup">ISU Group *</Label>
                        <Input
                          id="isuGroup"
                          value={formData.isuGroup}
                          onChange={(e) => handleInputChange('isuGroup', e.target.value)}
                          placeholder="Enter ISU group"
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <Label>Is customer 1st time Outsourcing *</Label>
                        <RadioGroup value={formData.firstTimeOutsourcing} onValueChange={(value) => handleInputChange('firstTimeOutsourcing', value)}>
                          <div className="flex items-center space-x-4">
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="yes" id="outsourcing-yes" />
                              <Label htmlFor="outsourcing-yes" className="cursor-pointer">Yes</Label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="no" id="outsourcing-no" />
                              <Label htmlFor="outsourcing-no" className="cursor-pointer">No</Label>
                            </div>
                          </div>
                        </RadioGroup>
                      </div>
                    </div>
                  </div>

                  {/* Section 3: Contract & Competitive Details */}
                  <div className="bg-white p-6 rounded-lg shadow-sm border border-blue-100">
                    <h3 className="text-xl mb-4 text-blue-900 flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-sm">3</div>
                      Contract & Competitive Details
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label>Contract Start Date *</Label>
                        <Popover>
                          <PopoverTrigger asChild>
                            <Button
                              variant="outline"
                              className={`w-full justify-start text-left font-normal ${!contractStartDate && 'text-muted-foreground'}`}
                            >
                              <CalendarIcon className="mr-2 h-4 w-4" />
                              {contractStartDate ? format(contractStartDate, 'MM/dd/yyyy') : 'mm/dd/yyyy'}
                            </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0">
                            <Calendar
                              mode="single"
                              selected={contractStartDate}
                              onSelect={setContractStartDate}
                              initialFocus
                            />
                          </PopoverContent>
                        </Popover>
                      </div>

                      <div className="space-y-2 md:col-span-2">
                        <Label htmlFor="competitors">Competitors bidding for RFP</Label>
                        <Input
                          id="competitors"
                          value={formData.competitors}
                          onChange={(e) => handleInputChange('competitors', e.target.value)}
                          placeholder="Enter competitors"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label>Coverage *</Label>
                        <RadioGroup value={formData.coverage} onValueChange={(value) => handleInputChange('coverage', value)}>
                          <div className="flex items-center space-x-4">
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="global" id="coverage-global" />
                              <Label htmlFor="coverage-global" className="cursor-pointer">Global</Label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="regional" id="coverage-regional" />
                              <Label htmlFor="coverage-regional" className="cursor-pointer">Region of scope</Label>
                            </div>
                          </div>
                        </RadioGroup>
                      </div>

                      <div className="space-y-2">
                        <Label>DD conduct *</Label>
                        <RadioGroup value={formData.ddConduct} onValueChange={(value) => handleInputChange('ddConduct', value)}>
                          <div className="flex flex-wrap gap-4">
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="pre-contract" id="dd-pre" />
                              <Label htmlFor="dd-pre" className="cursor-pointer">Pre-Contract</Label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="post-contract" id="dd-post" />
                              <Label htmlFor="dd-post" className="cursor-pointer">Post-Contract</Label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="not-done" id="dd-not" />
                              <Label htmlFor="dd-not" className="cursor-pointer">Not-Done</Label>
                            </div>
                          </div>
                        </RadioGroup>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="regionOfScope">Region of Scope</Label>
                        <Input
                          id="regionOfScope"
                          value={formData.regionOfScope}
                          onChange={(e) => handleInputChange('regionOfScope', e.target.value)}
                          placeholder="Enter region"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Section 4: Transition Details */}
                  <div className="bg-white p-6 rounded-lg shadow-sm border border-blue-100">
                    <h3 className="text-xl mb-4 text-blue-900 flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-sm">4</div>
                      Transition Details
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label>Transition Type *</Label>
                        <RadioGroup value={formData.transitionType} onValueChange={(value) => handleInputChange('transitionType', value)}>
                          <div className="flex flex-wrap gap-4">
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="transformation-led" id="trans-transform" />
                              <Label htmlFor="trans-transform" className="cursor-pointer">Transformation Led</Label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="transition" id="trans-transition" />
                              <Label htmlFor="trans-transition" className="cursor-pointer">Transition</Label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="as-is" id="trans-asis" />
                              <Label htmlFor="trans-asis" className="cursor-pointer">As-is Transition</Label>
                            </div>
                          </div>
                        </RadioGroup>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="transitionDuration">Transition Duration (Months) *</Label>
                        <Input
                          id="transitionDuration"
                          type="number"
                          value={formData.transitionDuration}
                          onChange={(e) => handleInputChange('transitionDuration', e.target.value)}
                          placeholder="Enter duration"
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <Label>Transition Start Date *</Label>
                        <Popover>
                          <PopoverTrigger asChild>
                            <Button
                              variant="outline"
                              className={`w-full justify-start text-left font-normal ${!transitionStartDate && 'text-muted-foreground'}`}
                            >
                              <CalendarIcon className="mr-2 h-4 w-4" />
                              {transitionStartDate ? format(transitionStartDate, 'MM/dd/yyyy') : 'mm/dd/yyyy'}
                            </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0">
                            <Calendar
                              mode="single"
                              selected={transitionStartDate}
                              onSelect={setTransitionStartDate}
                              initialFocus
                            />
                          </PopoverContent>
                        </Popover>
                      </div>

                      <div className="space-y-2">
                        <Label>Go-Live Date *</Label>
                        <Popover>
                          <PopoverTrigger asChild>
                            <Button
                              variant="outline"
                              className={`w-full justify-start text-left font-normal ${!goLiveDate && 'text-muted-foreground'}`}
                            >
                              <CalendarIcon className="mr-2 h-4 w-4" />
                              {goLiveDate ? format(goLiveDate, 'MM/dd/yyyy') : 'mm/dd/yyyy'}
                            </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0">
                            <Calendar
                              mode="single"
                              selected={goLiveDate}
                              onSelect={setGoLiveDate}
                              initialFocus
                            />
                          </PopoverContent>
                        </Popover>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="currentIncumbent">Current Incumbent (If Any)</Label>
                        <Input
                          id="currentIncumbent"
                          value={formData.currentIncumbent}
                          onChange={(e) => handleInputChange('currentIncumbent', e.target.value)}
                          placeholder="Enter text"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="incumbentName">Incumbent Name</Label>
                        <Input
                          id="incumbentName"
                          value={formData.incumbentName}
                          onChange={(e) => handleInputChange('incumbentName', e.target.value)}
                          placeholder="Enter name"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="incumbentLocation">Incumbent Support Location</Label>
                        <Input
                          id="incumbentLocation"
                          value={formData.incumbentLocation}
                          onChange={(e) => handleInputChange('incumbentLocation', e.target.value)}
                          placeholder="Enter location"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="towersOrTech">Name of Towers / Tech</Label>
                        <Input
                          id="towersOrTech"
                          value={formData.towersOrTech}
                          onChange={(e) => handleInputChange('towersOrTech', e.target.value)}
                          placeholder="Enter towers/tech"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Section 5: Team Details */}
                  <div className="bg-white p-6 rounded-lg shadow-sm border border-blue-100">
                    <h3 className="text-xl mb-4 text-blue-900 flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-sm">5</div>
                      Team Details
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="bidOwner">Bid Owner *</Label>
                        <Input
                          id="bidOwner"
                          value={formData.bidOwner}
                          onChange={(e) => handleInputChange('bidOwner', e.target.value)}
                          placeholder="Enter bid owner name"
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="presalesArchitect">Pre-sales Architect *</Label>
                        <Input
                          id="presalesArchitect"
                          value={formData.presalesArchitect}
                          onChange={(e) => handleInputChange('presalesArchitect', e.target.value)}
                          placeholder="Enter architect name"
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="deliveryHead">Delivery Head *</Label>
                        <Input
                          id="deliveryHead"
                          value={formData.deliveryHead}
                          onChange={(e) => handleInputChange('deliveryHead', e.target.value)}
                          placeholder="Enter delivery head name"
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="sdm">SDM *</Label>
                        <Input
                          id="sdm"
                          value={formData.sdm}
                          onChange={(e) => handleInputChange('sdm', e.target.value)}
                          placeholder="Enter SDM name"
                          required
                        />
                      </div>
                    </div>
                  </div>

                  {/* Form Actions */}
                  <div className="flex flex-col sm:flex-row justify-end gap-4 pt-6 border-t border-blue-200">
                    <Button 
                      type="button"
                      onClick={handleReset}
                      variant="outline"
                      className="sm:w-auto w-full border-2 border-gray-300 hover:bg-gray-100"
                    >
                      <RotateCcw className="w-4 h-4 mr-2" />
                      Reset
                    </Button>
                    <Button 
                      type="submit"
                      className="sm:w-auto w-full bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700"
                    >
                      <CheckCircle2 className="w-4 h-4 mr-2" />
                      Submit
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </div>
      
      <Footer />
    </div>
  );
}

// FileDocument icon component
function FileDocument({ className }: { className?: string }) {
  return (
    <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
    </svg>
  );
}