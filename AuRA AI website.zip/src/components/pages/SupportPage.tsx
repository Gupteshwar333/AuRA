import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { Footer } from '../Footer';
import { motion } from 'motion/react';
import { 
  HelpCircle, MessageSquare, Book, Video, Mail, 
  Phone, Clock, CheckCircle2, Sparkles
} from 'lucide-react';
import { useState } from 'react';

interface SupportPageProps {
  onNavigate: (page: string) => void;
}

export function SupportPage({ onNavigate }: SupportPageProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });

  const supportChannels = [
    {
      icon: MessageSquare,
      title: 'Chat with Ella Bot',
      description: 'Get instant answers from our AI assistant 24/7',
      action: 'Start Chat',
      gradient: 'from-pink-500 to-rose-500',
      onClick: () => onNavigate('Ella Bot')
    },
    {
      icon: Mail,
      title: 'Email Support',
      description: 'Send us an email and we\'ll respond within 24 hours',
      action: 'Send Email',
      gradient: 'from-blue-500 to-cyan-500',
      onClick: () => {}
    },
    {
      icon: Phone,
      title: 'Phone Support',
      description: 'Talk to our experts Mon-Fri, 9AM-5PM PST',
      action: 'Call Now',
      gradient: 'from-green-500 to-emerald-500',
      onClick: () => {}
    },
    {
      icon: Book,
      title: 'Documentation',
      description: 'Browse our comprehensive guides and tutorials',
      action: 'View Docs',
      gradient: 'from-purple-500 to-indigo-500',
      onClick: () => onNavigate('Learn More')
    },
  ];

  const faqs = [
    {
      question: 'How do I get started with AuRA AI?',
      answer: 'Sign up for a free trial, configure your environment, deploy AI agents that fit your needs, and start automating workflows. Our onboarding team will guide you through the process.'
    },
    {
      question: 'What types of AI agents are available?',
      answer: 'We offer 7 specialized agents: Transition Agent, SOP Agent, Conversational Agent, RAG Agent, Workflow Builder, DevOps Agent, and Analytics Agent. Each is autonomous and continuously learning.'
    },
    {
      question: 'How secure is my data?',
      answer: 'We use enterprise-grade encryption, comply with SOC 2 and GDPR standards, and maintain industry-leading security practices. All agent actions are logged and auditable.'
    },
    {
      question: 'Can I integrate with my existing tools?',
      answer: 'Yes! AuRA AI integrates with 100+ platforms including cloud services, CRMs, communication tools, databases, and custom APIs. Our agents work seamlessly with your existing stack.'
    },
    {
      question: 'What kind of support do you offer?',
      answer: '24/7 AI assistant support (Ella Bot), email support with 24-hour response time, phone support during business hours, comprehensive documentation, and dedicated account managers for Enterprise customers.'
    },
    {
      question: 'How does pricing work?',
      answer: 'We offer flexible plans: Free Trial (14 days), Starter, Professional, and Enterprise. All plans include autonomous AI agents, 24/7 support, and continuous learning capabilities. Contact us for detailed pricing.'
    },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Support form submitted:', formData);
    alert('Thank you for contacting support! We\'ll get back to you within 24 hours.');
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <motion.div
            className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-r from-blue-600 to-cyan-600 mb-6"
            animate={{
              scale: [1, 1.05, 1],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            <HelpCircle className="w-10 h-10 text-white" />
          </motion.div>
          <h1 className="text-4xl sm:text-5xl mb-4 text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-cyan-600">
            Support Center
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We're here to help you get the most out of AuRA AI Platform. Choose your preferred support channel or browse our resources.
          </p>
        </motion.div>

        {/* Support Channels */}
        <div className="mb-16">
          <h2 className="text-3xl text-center mb-8 text-gray-800">How Can We Help?</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {supportChannels.map((channel, index) => {
              const Icon = channel.icon;
              return (
                <motion.div
                  key={channel.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="h-full hover:shadow-xl transition-all duration-300 hover:-translate-y-2">
                    <CardHeader>
                      <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${channel.gradient} flex items-center justify-center mb-4`}>
                        <Icon className="w-7 h-7 text-white" />
                      </div>
                      <CardTitle className="text-lg">{channel.title}</CardTitle>
                      <CardDescription>{channel.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Button 
                        onClick={channel.onClick}
                        className={`w-full bg-gradient-to-r ${channel.gradient} hover:opacity-90`}
                      >
                        {channel.action}
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Contact Form */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <Card className="shadow-xl">
              <CardHeader>
                <CardTitle className="text-2xl">Send Us a Message</CardTitle>
                <CardDescription>Fill out the form and we'll get back to you within 24 hours</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Name *</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email *</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({...formData, email: e.target.value})}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="subject">Subject *</Label>
                    <Input
                      id="subject"
                      value={formData.subject}
                      onChange={(e) => setFormData({...formData, subject: e.target.value})}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="message">Message *</Label>
                    <Textarea
                      id="message"
                      rows={5}
                      value={formData.message}
                      onChange={(e) => setFormData({...formData, message: e.target.value})}
                      required
                    />
                  </div>
                  <Button 
                    type="submit"
                    className="w-full bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700"
                  >
                    Send Message
                  </Button>
                </form>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="space-y-6"
          >
            <Card className="bg-gradient-to-r from-blue-600 to-cyan-600 text-white">
              <CardContent className="pt-6">
                <Clock className="w-12 h-12 mb-4" />
                <h3 className="text-2xl mb-2">Support Hours</h3>
                <div className="space-y-2">
                  <p className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5" />
                    Ella Bot: 24/7 Instant Support
                  </p>
                  <p className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5" />
                    Email: 24 hour response time
                  </p>
                  <p className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5" />
                    Phone: Mon-Fri, 9AM-5PM PST
                  </p>
                  <p className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5" />
                    Enterprise: Dedicated 24/7 support
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-pink-600" />
                  Quick Tip
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  For the fastest response, try chatting with Ella Bot! Our AI assistant can answer most questions instantly 
                  and help you with platform navigation, feature explanations, and troubleshooting.
                </p>
                <Button 
                  onClick={() => onNavigate('Ella Bot')}
                  className="w-full mt-4 bg-gradient-to-r from-pink-600 to-rose-600"
                >
                  Chat with Ella Bot
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* FAQs */}
        <div>
          <h2 className="text-3xl text-center mb-8 text-gray-800">Frequently Asked Questions</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {faqs.map((faq, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="hover:shadow-lg transition-shadow h-full">
                  <CardHeader>
                    <CardTitle className="text-lg flex items-start gap-2">
                      <HelpCircle className="w-5 h-5 text-blue-600 mt-1 flex-shrink-0" />
                      {faq.question}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 text-sm">{faq.answer}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
      
      <Footer />
    </div>
  );
}
