import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Footer } from '../Footer';
import { motion } from 'motion/react';
import { 
  BarChart3, LineChart, PieChart, TrendingUp, 
  Brain, Target, Zap, Eye, CheckCircle2, ArrowRight, Sparkles
} from 'lucide-react';

interface AIAnalyticsPageProps {
  onNavigate: (page: string) => void;
}

export function AIAnalyticsPage({ onNavigate }: AIAnalyticsPageProps) {
  const features = [
    {
      icon: Brain,
      title: 'Intelligent Pattern Recognition',
      description: 'AI-powered algorithms automatically detect patterns, anomalies, and trends in your data without manual configuration.',
      capabilities: ['Anomaly Detection', 'Trend Analysis', 'Pattern Discovery', 'Correlation Mapping'],
      gradient: 'from-blue-500 to-cyan-500'
    },
    {
      icon: Target,
      title: 'Predictive Analytics',
      description: 'Forecast future outcomes with machine learning models that continuously learn from historical data and adapt to changing patterns.',
      capabilities: ['Forecasting', 'Risk Assessment', 'Opportunity Identification', 'Scenario Planning'],
      gradient: 'from-purple-500 to-pink-500'
    },
    {
      icon: Eye,
      title: 'Automated Insights',
      description: 'Generate actionable insights automatically. The AI identifies what matters most and presents findings in clear, understandable formats.',
      capabilities: ['Auto-generated Reports', 'Key Metric Identification', 'Insight Prioritization', 'Recommendation Engine'],
      gradient: 'from-green-500 to-emerald-500'
    },
    {
      icon: Zap,
      title: 'Real-Time Analysis',
      description: 'Process and analyze data streams in real-time, enabling immediate decision-making and rapid response to changing conditions.',
      capabilities: ['Stream Processing', 'Instant Alerts', 'Live Dashboards', 'Continuous Monitoring'],
      gradient: 'from-orange-500 to-red-500'
    },
  ];

  const analyticsTypes = [
    {
      icon: BarChart3,
      title: 'Descriptive Analytics',
      description: 'Understand what happened in your business with comprehensive historical analysis',
      examples: ['Sales performance', 'Customer behavior', 'Operational metrics']
    },
    {
      icon: LineChart,
      title: 'Diagnostic Analytics',
      description: 'Discover why things happened by identifying root causes and correlations',
      examples: ['Performance drivers', 'Issue root cause', 'Factor correlation']
    },
    {
      icon: TrendingUp,
      title: 'Predictive Analytics',
      description: 'Forecast what will happen with AI-powered predictive models',
      examples: ['Demand forecasting', 'Risk prediction', 'Trend projection']
    },
    {
      icon: PieChart,
      title: 'Prescriptive Analytics',
      description: 'Get recommendations on what actions to take for optimal outcomes',
      examples: ['Optimization suggestions', 'Decision support', 'Action planning']
    },
  ];

  const benefits = [
    'Data-driven decision making',
    'Real-time business insights',
    'Predictive forecasting',
    'Automated reporting',
    'Custom dashboards',
    'Multi-source integration',
    'Anomaly detection',
    'Performance optimization'
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 via-purple-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <motion.div
            className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-r from-blue-600 to-purple-600 mb-6"
            animate={{
              rotate: [0, 360],
            }}
            transition={{
              duration: 20,
              repeat: Infinity,
              ease: "linear"
            }}
          >
            <BarChart3 className="w-10 h-10 text-white" />
          </motion.div>
          <h1 className="text-4xl sm:text-5xl mb-4 text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600">
            AI-Powered Analytics
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Transform raw data into actionable insights with autonomous AI analytics that continuously learn, 
            adapt, and provide intelligent recommendations for your business
          </p>
        </motion.div>

        {/* Key Features */}
        <div className="mb-16">
          <h2 className="text-3xl text-center mb-12 text-gray-800">Core Capabilities</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="h-full hover:shadow-2xl transition-all duration-300 hover:-translate-y-2">
                    <CardHeader>
                      <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${feature.gradient} flex items-center justify-center mb-4`}>
                        <Icon className="w-7 h-7 text-white" />
                      </div>
                      <CardTitle className="text-xl mb-2">{feature.title}</CardTitle>
                      <CardDescription>{feature.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 gap-2">
                        {feature.capabilities.map((capability) => (
                          <div key={capability} className="flex items-start gap-1 text-sm">
                            <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                            <span className="text-gray-700">{capability}</span>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Analytics Types */}
        <div className="mb-16">
          <h2 className="text-3xl text-center mb-12 text-gray-800">Types of Analytics</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {analyticsTypes.map((type, index) => {
              const Icon = type.icon;
              return (
                <motion.div
                  key={type.title}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="h-full hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <Icon className="w-10 h-10 text-blue-600 mb-3" />
                      <CardTitle className="text-lg">{type.title}</CardTitle>
                      <CardDescription className="text-sm">{type.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-1">
                        {type.examples.map((example) => (
                          <li key={example} className="text-sm text-gray-600 flex items-start gap-1">
                            <span className="text-blue-600 mt-1">•</span>
                            {example}
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Benefits Grid */}
        <div className="mb-16">
          <h2 className="text-3xl text-center mb-12 text-gray-800">Key Benefits</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {benefits.map((benefit, index) => (
              <motion.div
                key={benefit}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <Card className="text-center hover:shadow-lg transition-shadow p-4">
                  <CheckCircle2 className="w-6 h-6 text-green-600 mx-auto mb-2" />
                  <p className="text-sm text-gray-700">{benefit}</p>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Demo Section */}
        <motion.div
          className="bg-gray-50 rounded-2xl p-8 mb-16"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl text-center mb-8 text-gray-800">See It In Action</h2>
          <div className="bg-white rounded-lg p-6 shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl">Sample Analytics Dashboard</h3>
              <Button variant="outline" size="sm">
                <Eye className="w-4 h-4 mr-2" />
                View Full Demo
              </Button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-gradient-to-r from-blue-50 to-cyan-50 p-4 rounded-lg">
                <p className="text-sm text-gray-600 mb-1">Total Revenue</p>
                <p className="text-3xl mb-2">$2.4M</p>
                <p className="text-sm text-green-600 flex items-center gap-1">
                  <TrendingUp className="w-4 h-4" />
                  +23.5% from last month
                </p>
              </div>
              <div className="bg-gradient-to-r from-purple-50 to-pink-50 p-4 rounded-lg">
                <p className="text-sm text-gray-600 mb-1">Active Users</p>
                <p className="text-3xl mb-2">12,847</p>
                <p className="text-sm text-green-600 flex items-center gap-1">
                  <TrendingUp className="w-4 h-4" />
                  +15.2% from last month
                </p>
              </div>
              <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-4 rounded-lg">
                <p className="text-sm text-gray-600 mb-1">Conversion Rate</p>
                <p className="text-3xl mb-2">4.8%</p>
                <p className="text-sm text-green-600 flex items-center gap-1">
                  <TrendingUp className="w-4 h-4" />
                  +2.1% from last month
                </p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
      
      <Footer />
    </div>
  );
}