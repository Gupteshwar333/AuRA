import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Footer } from '../Footer';
import { motion } from 'motion/react';
import { 
  Compass, TrendingUp, Award, Users, 
  Globe, Zap, Target, Heart, Star,
  ArrowRight, CheckCircle2, Brain, Workflow
} from 'lucide-react';

interface ExplorePageProps {
  onNavigate: (page: string) => void;
}

export function ExplorePage({ onNavigate }: ExplorePageProps) {
  const offerings = [
    {
      icon: Brain,
      category: 'Autonomous Intelligence',
      title: 'Self-Directed Decision-Making',
      description: 'AI agents that understand context, reason through complex scenarios, and make independent decisions aligned with your business objectives.',
      features: ['Context Understanding', 'Logical Reasoning', 'Adaptive Decisions'],
      gradient: 'from-blue-500 to-cyan-500',
      badge: 'Core'
    },
    {
      icon: Target,
      category: 'Goal-Oriented Systems',
      title: 'Objective Decomposition',
      description: 'Set high-level goals and watch AI agents break them into actionable sub-tasks, executing with precision and measuring outcomes.',
      features: ['Goal Planning', 'Task Breakdown', 'Progress Tracking'],
      gradient: 'from-purple-500 to-pink-500',
      badge: 'Popular'
    },
    {
      icon: Workflow,
      category: 'End-to-End Automation',
      title: 'Complete Workflow Management',
      description: 'Automate entire business processes from start to finish with agents that handle exceptions and adapt to changes autonomously.',
      features: ['Process Automation', 'Exception Handling', 'Dynamic Adaptation'],
      gradient: 'from-green-500 to-emerald-500',
      badge: 'Hot'
    },
    {
      icon: Users,
      category: 'Multi-Agent Systems',
      title: 'Collaborative Intelligence',
      description: 'Multiple AI agents working together, sharing knowledge and coordinating actions to solve complex, multi-faceted challenges.',
      features: ['Agent Coordination', 'Knowledge Sharing', 'Collective Problem-Solving'],
      gradient: 'from-orange-500 to-red-500',
      badge: null
    },
  ];

  const industries = [
    { name: 'Healthcare', icon: Heart, companies: 500, gradient: 'from-red-500 to-rose-500', description: 'Automating patient care workflows' },
    { name: 'Finance', icon: TrendingUp, companies: 750, gradient: 'from-green-500 to-emerald-500', description: 'Intelligent risk assessment' },
    { name: 'Manufacturing', icon: Globe, companies: 1200, gradient: 'from-blue-500 to-cyan-500', description: 'Supply chain optimization' },
    { name: 'Technology', icon: Award, companies: 950, gradient: 'from-purple-500 to-pink-500', description: 'DevOps automation' },
  ];

  const testimonials = [
    {
      quote: "AuRA AI's autonomous agents have transformed our operations. They make intelligent decisions 24/7, adapting to changing conditions and continuously learning. Our efficiency has increased by 60%.",
      author: "Emily Watson",
      role: "CTO, InnovateTech Solutions",
      rating: 5
    },
    {
      quote: "The ability to deploy goal-oriented agents that break down complex objectives into actionable tasks is game-changing. We've automated workflows we never thought possible.",
      author: "Michael Rodriguez",
      role: "Operations Director, Global Logistics Inc.",
      rating: 5
    },
    {
      quote: "Multi-agent collaboration is revolutionary. Our AI agents work together seamlessly, sharing insights and coordinating actions. The results have exceeded all expectations.",
      author: "Sarah Chen",
      role: "VP of Innovation, TechForward",
      rating: 5
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-emerald-50 via-teal-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <motion.div
            className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-r from-emerald-600 to-teal-600 mb-6"
            animate={{
              scale: [1, 1.05, 1],
              rotate: [0, 5, -5, 0]
            }}
            transition={{
              duration: 4,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            <Compass className="w-10 h-10 text-white" />
          </motion.div>
          <h1 className="text-4xl sm:text-5xl mb-4 text-transparent bg-clip-text bg-gradient-to-r from-emerald-600 to-teal-600">
            Explore AuRA AI Platform
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Discover how autonomous, goal-oriented AI agents can revolutionize your organization's 
            workflows, enhance decision-making, and unlock unprecedented levels of efficiency and innovation
          </p>
        </motion.div>

        {/* Main Offerings */}
        <div className="mb-20">
          <h2 className="text-3xl text-center mb-12 text-gray-800">Platform Capabilities</h2>
          <motion.div 
            className="grid grid-cols-1 md:grid-cols-2 gap-8"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            {offerings.map((offering) => {
              const Icon = offering.icon;
              return (
                <motion.div
                  key={offering.title}
                  whileHover={{ y: -5 }}
                  transition={{ duration: 0.3 }}
                >
                  <Card className="h-full hover:shadow-2xl transition-all duration-300 border-2 border-transparent hover:border-emerald-200">
                    <CardHeader>
                      <div className="flex items-start justify-between mb-4">
                        <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${offering.gradient} flex items-center justify-center`}>
                          <Icon className="w-7 h-7 text-white" />
                        </div>
                        {offering.badge && (
                          <Badge className={`bg-gradient-to-r ${offering.gradient} text-white border-0`}>
                            {offering.badge}
                          </Badge>
                        )}
                      </div>
                      <CardDescription className="text-xs uppercase tracking-wide text-gray-500 mb-2">
                        {offering.category}
                      </CardDescription>
                      <CardTitle className="text-xl mb-3">{offering.title}</CardTitle>
                      <p className="text-gray-600">{offering.description}</p>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="space-y-2">
                        {offering.features.map((feature) => (
                          <div key={feature} className="flex items-center gap-2">
                            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                            <span className="text-sm text-gray-700">{feature}</span>
                          </div>
                        ))}
                      </div>
                      <Button className={`w-full bg-gradient-to-r ${offering.gradient} hover:opacity-90`}>
                        Explore Capability
                        <ArrowRight className="w-4 h-4 ml-2" />
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </motion.div>
        </div>

        {/* Industries Served */}
        <div className="mb-20">
          <h2 className="text-3xl text-center mb-12 text-gray-800">Industries We Empower</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {industries.map((industry, index) => {
              const Icon = industry.icon;
              return (
                <motion.div
                  key={industry.name}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="text-center hover:shadow-xl transition-all duration-300 hover:-translate-y-2">
                    <CardContent className="pt-6">
                      <div className={`w-16 h-16 mx-auto rounded-full bg-gradient-to-br ${industry.gradient} flex items-center justify-center mb-4`}>
                        <Icon className="w-8 h-8 text-white" />
                      </div>
                      <h3 className="mb-2">{industry.name}</h3>
                      <p className="text-xs text-gray-500 mb-2">{industry.description}</p>
                      <p className="text-sm text-emerald-600">{industry.companies}+ organizations</p>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Testimonials */}
        <div className="mb-16">
          <h2 className="text-3xl text-center mb-12 text-gray-800">Success Stories</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={testimonial.author}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 + index * 0.2 }}
              >
                <Card className="h-full hover:shadow-xl transition-shadow">
                  <CardContent className="pt-6">
                    <div className="flex gap-1 mb-4">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                      ))}
                    </div>
                    <p className="text-gray-700 mb-4 italic">"{testimonial.quote}"</p>
                    <div>
                      <p className="text-sm">{testimonial.author}</p>
                      <p className="text-xs text-gray-500">{testimonial.role}</p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <motion.div 
          className="bg-gradient-to-r from-emerald-600 to-teal-600 rounded-2xl p-8 sm:p-12 text-white text-center shadow-2xl"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl sm:text-4xl mb-4">Ready to Deploy Autonomous AI?</h2>
          <p className="text-lg text-emerald-100 max-w-2xl mx-auto mb-8">
            Join thousands of organizations leveraging AuRA AI's autonomous agents to automate workflows, 
            make intelligent decisions, and achieve unprecedented efficiency
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button className="bg-white text-emerald-600 hover:bg-emerald-50 px-8 py-6 text-lg">
              Start Free Trial
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
            <Button variant="outline" className="border-2 border-white text-white hover:bg-white/10 px-8 py-6 text-lg">
              Schedule a Demo
            </Button>
          </div>
        </motion.div>
      </div>
      
      <Footer />
    </div>
  );
}
