import { useState } from 'react';
import { Eye, EyeOff, Mail, ArrowRight } from 'lucide-react';
import { Label } from './ui/label';
import { Input } from './ui/input';

interface LoginFormProps {
  onLogin: (email: string, password: string) => void;
}

export function LoginForm({ onLogin }: LoginFormProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin(email, password);
  };

  return (
    <div className="min-h-screen flex">
      {/* Left Side - Black Panel */}
      <div className="hidden lg:flex lg:w-1/2 bg-[#0d1117] relative overflow-hidden">
        <div className="relative z-10 flex flex-col justify-between px-12 py-16 text-white w-full">
          {/* Top Content */}
          <div className="space-y-16">
            {/* Logo Section */}
            <div>
              <h1 className="text-lg text-white mb-1 leading-tight">TCS AuRA</h1>
              <p className="text-sky-500 text-sm leading-tight">Autonomous Intelligence</p>
            </div>
            
            {/* Next-Generation AI Section */}
            <div className="border-l-4 border-sky-500 pl-6">
              <h2 className="text-base text-white mb-3 leading-tight">Next-Generation AI</h2>
              <p className="text-gray-400 text-sm leading-relaxed">
                Experience autonomous, goal-oriented systems capable of understanding, reasoning, planning, and executing complex tasks with minimal human intervention.
              </p>
            </div>
          </div>
          
          {/* Bottom Stats Cards */}
          <div className="grid grid-cols-2 gap-6">
            <div className="bg-[#161b22] p-6 rounded-xl border border-gray-800">
              <div className="text-sky-500 text-2xl mb-2 leading-none">24/7</div>
              <div className="text-xs text-gray-400 leading-tight">Autonomous Operations</div>
            </div>
            <div className="bg-[#161b22] p-6 rounded-xl border border-gray-800">
              <div className="text-sky-500 text-2xl mb-2 leading-none">AI</div>
              <div className="text-xs text-gray-400 leading-tight">Multi-Agent System</div>
            </div>
          </div>
        </div>
      </div>

      {/* Right Side - White Form Panel */}
      <div className="flex-1 flex items-center justify-center bg-white p-8">
        <div className="w-full max-w-md">
          {/* Mobile Logo */}
          <div className="lg:hidden mb-8 flex items-center justify-center">
            <span className="text-lg text-[#000080]">TCS AuRA</span>
          </div>

          <div className="space-y-8">
            {/* Header */}
            <div>
              <h2 className="text-2xl text-gray-900 mb-2 leading-tight">Welcome Back</h2>
              <p className="text-gray-500 text-sm">Enter your credentials to access the platform</p>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-gray-700 text-sm font-normal">Email Address</Label>
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <Input
                    id="email"
                    type="email"
                    placeholder="you@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="pl-12 h-12 bg-white border-gray-300 focus:border-sky-500 focus:ring-sky-500 rounded-xl text-sm"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-gray-700 text-sm font-normal">Password</Label>
                <div className="relative">
                  {showPassword ? (
                    <EyeOff className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  ) : (
                    <Eye className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  )}
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pl-12 h-12 bg-white border-gray-300 focus:border-sky-500 focus:ring-sky-500 rounded-xl text-sm"
                    required
                  />
                </div>
                <button
                  type="button"
                  className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? (
                    <EyeOff className="w-5 h-5" />
                  ) : (
                    <Eye className="w-5 h-5" />
                  )}
                </button>
              </div>

              <div className="flex items-center justify-between text-sm pt-1">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" className="w-4 h-4 rounded border-gray-300 text-sky-500 focus:ring-sky-500" />
                  <span className="text-gray-600">Remember me</span>
                </label>
                <a href="#" className="text-sky-500 hover:text-sky-600 transition-colors">
                  Forgot password?
                </a>
              </div>

              <button
                type="submit"
                className="w-full h-12 bg-white text-[#000080] border border-[#000080] rounded-full flex items-center justify-center gap-2 hover:bg-[#000080] hover:text-white transition-all duration-300 mt-6"
              >
                <ArrowRight className="w-5 h-5" />
                <span>Sign In</span>
              </button>

              <div className="text-center pt-2">
                <p className="text-xs text-gray-500">
                  Demo: Use any email and password to login
                </p>
              </div>
            </form>

            {/* Footer */}
            <div className="pt-2 text-center">
              <p className="text-sm text-gray-600">
                Don't have an account?{' '}
                <a href="#" className="text-sky-500 hover:text-sky-600 transition-colors">
                  Request Access
                </a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}