import { useState } from 'react';
import { Navbar } from './components/Navbar';
import { LoginForm } from './components/LoginForm';
import { HomePage } from './components/pages/HomePage';
import { SolutionsPage } from './components/pages/SolutionsPage';
import { PlatformPage } from './components/pages/PlatformPage';
import { CataloguePage } from './components/pages/CataloguePage';
import { SupportPage } from './components/pages/SupportPage';
import { EllaBotPage } from './components/pages/EllaBotPage';
import { AIAgentPage } from './components/pages/AIAgentPage';
import { AIAnalyticsPage } from './components/pages/AIAnalyticsPage';
import { ConversationAIPage } from './components/pages/ConversationAIPage';
import { GetStartedPage } from './components/pages/GetStartedPage';
import { LearnMorePage } from './components/pages/LearnMorePage';
import { ExplorePage } from './components/pages/ExplorePage';
import { ToolsPage } from './components/pages/ToolsPage';
import { AddToolsPage } from './components/pages/AddToolsPage';
import { ListToolsPage } from './components/pages/ListToolsPage';

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentPage, setCurrentPage] = useState('Home');

  const handleLogin = (email: string, password: string) => {
    // Simple demo login - accepts any credentials
    if (email && password) {
      setIsAuthenticated(true);
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setCurrentPage('Home');
  };

  const handleNavigate = (page: string) => {
    setCurrentPage(page);
    // Scroll to top when navigating
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (!isAuthenticated) {
    return <LoginForm onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen">
      <Navbar 
        currentPage={currentPage} 
        onNavigate={handleNavigate}
        onLogout={handleLogout}
      />
      
      {currentPage === 'Home' && <HomePage onNavigate={handleNavigate} />}
      {currentPage === 'Platform' && <PlatformPage onNavigate={handleNavigate} />}
      {currentPage === 'Solutions' && <SolutionsPage onNavigate={handleNavigate} />}
      {currentPage === 'Support' && <SupportPage onNavigate={handleNavigate} />}
      {currentPage === 'Catalogue' && <CataloguePage onNavigate={handleNavigate} />}
      {currentPage === 'Ella Bot' && <EllaBotPage />}
      
      {/* Platform Submenu Pages */}
      {currentPage === 'AI Agent' && <AIAgentPage onNavigate={handleNavigate} />}
      {currentPage === 'AI Analytics' && <AIAnalyticsPage onNavigate={handleNavigate} />}
      {currentPage === 'Conversation AI' && <ConversationAIPage onNavigate={handleNavigate} />}
      
      {/* Utility Pages */}
      {currentPage === 'Get Started' && <GetStartedPage onNavigate={handleNavigate} />}
      {currentPage === 'Learn More' && <LearnMorePage onNavigate={handleNavigate} />}
      {currentPage === 'Explore' && <ExplorePage onNavigate={handleNavigate} />}
      {currentPage === 'Tools' && <ToolsPage />}
      
      {/* Tools Management Pages */}
      {currentPage === 'Add Tools' && <AddToolsPage onNavigate={handleNavigate} />}
      {currentPage === 'List Tools' && <ListToolsPage onNavigate={handleNavigate} />}
    </div>
  );
}
